/**
 *
 */
package com.dakshata.constants.instrument;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.TemporalAdjusters;

import com.dakshata.tools.date.DateUtil;

/**
 * Trading hours of an exchange segment, in IST.
 *
 * <p>
 * {@link Exchange} carries one open/close pair per exchange, but trading hours are a property of the
 * <em>segment</em>, not the exchange &mdash; NSE equity closes at 15:30 while NSE currency trades on
 * until 17:00. Resolve hours through this class whenever a broker specific exchange/segment string is
 * available (position, order or instrument), and fall back to {@link Exchange#isOpen(LocalDateTime)}
 * only when all you have is the independent exchange.
 * </p>
 *
 * <p>
 * Two moving boundaries are handled here so callers never hardcode them:
 * </p>
 * <ul>
 * <li><b>Commodity evening close follows US daylight saving</b> &mdash; 23:30 IST while US DST is in
 * effect (second Sunday of March to first Sunday of November), 23:55 IST otherwise. Hardcoding either
 * one leaves the platform 25 minutes wrong for part of the year.</li>
 * <li><b>Both equity closes move</b> from {@link #MARKET_TIMING_REVISION_DATE} (the NSE/SEBI Closing
 * Auction Session framework) &mdash; derivatives to 15:40, cash to 15:35. See below.</li>
 * </ul>
 *
 * <h2>The equity revision of 2026-08-03</h2>
 *
 * <p>
 * Equity cash is no longer one uniform session &mdash; what a stock does after 15:15 depends on
 * whether it is F&amp;O eligible:
 * </p>
 * <ul>
 * <li><b>F&amp;O eligible stocks</b> &mdash; continuous trading ends at 15:15, then a Closing Auction
 * Session runs to <b>15:35</b> and sets the official closing price. Orders are still accepted
 * throughout the auction.</li>
 * <li><b>Non F&amp;O stocks</b> &mdash; unchanged, continuous trading to <b>15:30</b>.</li>
 * <li><b>Equity derivatives</b> &mdash; extended to <b>15:40</b>, so F&amp;O outlives every cash
 * boundary.</li>
 * </ul>
 *
 * <p>
 * F&amp;O eligibility is a property of the <em>instrument</em> and cannot be read off an exchange or
 * segment string, so {@link Session#EQUITY_CASH} deliberately reports the <b>widest</b> close (15:35)
 * rather than trying to guess. That follows the same trade-off the rest of this class makes: treating
 * a closed market as open only costs a redundant check, whereas the reverse silently drops
 * protection. For the same reason the 15:15 continuous-trading cut-off is <em>not</em> modelled here
 * &mdash; it would narrow the window, and we cannot tell which stocks it applies to.
 * </p>
 *
 * <p>
 * Broker intraday (MIS) auto square-off also moved earlier under this framework (typically 15:10 for
 * auction stocks, 15:20 otherwise), but that is set by each <em>broker</em>, not the exchange, so it
 * is not represented here.
 * </p>
 *
 * <p>
 * Commodity hours use the widest (non-agri) session. MCX agri commodities close earlier (17:00, or
 * 21:00 for cotton/kapas) but that cannot be told from the exchange string alone, so the wider window
 * is used deliberately &mdash; treating a closed market as open only costs a redundant check, whereas
 * the reverse silently drops protection.
 * </p>
 *
 * @author PRITESH
 */
public final class MarketHours {

	/**
	 * Date the NSE/SEBI Closing Auction Session framework took effect: equity derivatives moved from
	 * 15:30 to 15:40, and F&amp;O eligible cash stocks gained an auction that runs to 15:35.
	 */
	public static final LocalDate MARKET_TIMING_REVISION_DATE = LocalDate.of(2026, 8, 3);

	private static final LocalTime EQUITY_OPEN = LocalTime.of(9, 15);

	/** Equity cash close before the revision, and still the close for non F&amp;O stocks. */
	private static final LocalTime EQUITY_CASH_CLOSE = LocalTime.of(15, 30);

	/** End of the Closing Auction Session — the widest equity cash close after the revision. */
	private static final LocalTime EQUITY_CASH_CLOSE_EXTENDED = LocalTime.of(15, 35);

	private static final LocalTime EQUITY_DERIVATIVES_CLOSE_EXTENDED = LocalTime.of(15, 40);

	private static final LocalTime CURRENCY_OPEN = LocalTime.of(9, 0);

	private static final LocalTime CURRENCY_CLOSE = LocalTime.of(17, 0);

	private static final LocalTime COMMODITY_OPEN = LocalTime.of(9, 0);

	private static final LocalTime NCDEX_OPEN = LocalTime.of(10, 0);

	/** Commodity evening close while US daylight saving is in effect. */
	private static final LocalTime COMMODITY_CLOSE_DST = LocalTime.of(23, 30);

	/** Commodity evening close outside US daylight saving. */
	private static final LocalTime COMMODITY_CLOSE_STANDARD = LocalTime.of(23, 55);

	private MarketHours() {
	}

	/**
	 * Trading session a broker specific exchange/segment string belongs to.
	 */
	public enum Session {

		EQUITY_CASH, EQUITY_DERIVATIVES, CURRENCY, COMMODITY, NCDEX_COMMODITY;

	}

	/**
	 * Resolves a broker specific exchange or segment string to its trading session.
	 *
	 * @param exchangeOrSegment broker exchange/segment, e.g. NSE, NFO, CDS, MCX
	 * @return the session, or null when the string is not recognised
	 */
	public static Session sessionOf(final String exchangeOrSegment) {
		if (exchangeOrSegment == null) {
			return null;
		}

		switch (exchangeOrSegment.trim().toUpperCase()) {
		case "NSE":
		case "BSE":
		case "NSECM":
		case "BSECM":
		case "NSEEQ":
		case "BSEEQ":
		case "NSE_CM":
		case "BSE_CM":
		case "CASH":
		// Our OWN canonical segment strings, produced by IndependentInstrument.calcExchangeSegment().
		// They were missing here until 2026-08-08, so every caller passing an instrument's real
		// segment fell through to default -> null -> the commodity close. See the note on
		// close(Session, LocalDate): that fallback is right for "is it open?" and catastrophic for
		// "when must I act?" — it gave an intraday bracket a 23:00 square-off.
		case "NSE_CASH":
		case "BSE_CASH":
			return Session.EQUITY_CASH;
		case "NFO":
		case "BFO":
		case "NSEFO":
		case "BSEFO":
		case "NSE_FO":
		case "BSE_FO":
		case "NSE_FNO":
		case "BSE_FNO":
			return Session.EQUITY_DERIVATIVES;
		case "CDS":
		case "CDE":
		case "NCD":
		case "BCD":
		case "NSECD":
		case "NSECDS":
		case "NSECURR":
		case "NSE-FX":
		case "CDE_FO":
		case "CUR":
			return Session.CURRENCY;
		case "NCDEX":
			return Session.NCDEX_COMMODITY;
		case "MCX":
		case "MCX-CM":
		case "MCX_CM":
		case "MCXFO":
		case "MCX_FO":
		case "MCXCOMM":
		case "NCO":
		case "BCO":
		case "COM":
			return Session.COMMODITY;
		default:
			return null;
		}
	}

	/**
	 * Opening time of the session a given exchange/segment trades in.
	 *
	 * @param exchangeOrSegment broker exchange/segment
	 * @return opening time; the earliest of any session when the string is unrecognised
	 */
	public static LocalTime open(final String exchangeOrSegment) {
		return open(sessionOf(exchangeOrSegment));
	}

	/**
	 * Opening time of a session. An unknown (null) session yields the earliest opening across all
	 * sessions, so an unrecognised instrument is never treated as closed while some market trades.
	 */
	public static LocalTime open(final Session session) {
		if (session == null) {
			return COMMODITY_OPEN;
		}

		switch (session) {
		case EQUITY_CASH:
		case EQUITY_DERIVATIVES:
			return EQUITY_OPEN;
		case CURRENCY:
			return CURRENCY_OPEN;
		case NCDEX_COMMODITY:
			return NCDEX_OPEN;
		case COMMODITY:
		default:
			return COMMODITY_OPEN;
		}
	}

	/**
	 * Closing time of the session a given exchange/segment trades in, on a given date.
	 *
	 * @param exchangeOrSegment broker exchange/segment
	 * @param on                date the close is being resolved for (drives the DST and the equity
	 *                          derivatives extension boundaries)
	 * @return closing time; the latest of any session when the string is unrecognised
	 */
	public static LocalTime close(final String exchangeOrSegment, final LocalDate on) {
		return close(sessionOf(exchangeOrSegment), on);
	}

	/**
	 * Closing time of a session on a given date. An unknown (null) session yields the latest close
	 * across all sessions &mdash; failing towards "still open" keeps protection on rather than
	 * silently dropping it for an instrument we could not classify.
	 */
	public static LocalTime close(final Session session, final LocalDate on) {
		if (session == null) {
			return commodityClose(on);
		}

		switch (session) {
		case EQUITY_CASH:
			// The widest cash close: F&O eligible stocks stay orderable through the auction until
			// 15:35, non F&O stocks stop at 15:30, and the segment string cannot tell them apart.
			return on.isBefore(MARKET_TIMING_REVISION_DATE) ? EQUITY_CASH_CLOSE : EQUITY_CASH_CLOSE_EXTENDED;
		case EQUITY_DERIVATIVES:
			return on.isBefore(MARKET_TIMING_REVISION_DATE) ? EQUITY_CASH_CLOSE
					: EQUITY_DERIVATIVES_CLOSE_EXTENDED;
		case CURRENCY:
			return CURRENCY_CLOSE;
		case COMMODITY:
		case NCDEX_COMMODITY:
		default:
			return commodityClose(on);
		}
	}

	/**
	 * Is the segment currently trading? Weekends are excluded; exchange holidays are NOT known here
	 * and must be applied by the caller.
	 *
	 * @param exchangeOrSegment broker exchange/segment
	 * @param when              instant to test, in IST
	 */
	public static boolean isOpen(final String exchangeOrSegment, final LocalDateTime when) {
		return isOpen(sessionOf(exchangeOrSegment), when);
	}

	/**
	 * Is the session currently trading? Weekends are excluded; exchange holidays are NOT known here
	 * and must be applied by the caller.
	 */
	public static boolean isOpen(final Session session, final LocalDateTime when) {
		if (DateUtil.isWeekend(when.toLocalDate())) {
			return false;
		}

		final LocalTime t = when.toLocalTime();
		return t.isAfter(open(session)) && t.isBefore(close(session, when.toLocalDate()));
	}

	/**
	 * Is <em>either</em> equity session &mdash; cash or derivatives &mdash; trading?
	 *
	 * <p>
	 * For "the equity market is live" checks that are not about one specific instrument (feed
	 * watchdogs, vendor health, socket reconnect gates). Since {@link #MARKET_TIMING_REVISION_DATE}
	 * those must stay awake through the derivatives-only window that follows the cash close,
	 * otherwise they go blind for the last minutes of F&amp;O trading. Do NOT use this to decide
	 * anything instrument specific &mdash; resolve that instrument's own segment through
	 * {@link #isOpen(String, LocalDateTime)}.
	 * </p>
	 */
	public static boolean isEquityOpen(final LocalDateTime when) {
		return isOpen(Session.EQUITY_CASH, when) || isOpen(Session.EQUITY_DERIVATIVES, when);
	}

	/**
	 * Has the session opened yet today? Says nothing about whether it has since closed.
	 */
	public static boolean hasStarted(final Session session, final LocalDateTime when) {
		return !DateUtil.isWeekend(when.toLocalDate()) && when.toLocalTime().isAfter(open(session));
	}

	/**
	 * Commodity evening close for a date: 23:30 IST during US daylight saving, 23:55 IST otherwise.
	 */
	public static LocalTime commodityClose(final LocalDate on) {
		return isUsDaylightSaving(on) ? COMMODITY_CLOSE_DST : COMMODITY_CLOSE_STANDARD;
	}

	/**
	 * Is the date inside the US daylight saving period &mdash; second Sunday of March to first Sunday
	 * of November?
	 *
	 * <p>
	 * The two boundary days themselves are treated as standard time. The exchange switches on the
	 * trading day following the changeover, so an exact match is impossible on a date alone; erring
	 * towards standard time picks the <em>later</em> close (23:55), which keeps monitoring on for an
	 * extra 25 minutes rather than ending it 25 minutes early.
	 * </p>
	 */
	public static boolean isUsDaylightSaving(final LocalDate on) {
		final LocalDate dstStart = LocalDate.of(on.getYear(), 3, 1)
				.with(TemporalAdjusters.dayOfWeekInMonth(2, DayOfWeek.SUNDAY));
		final LocalDate dstEnd = LocalDate.of(on.getYear(), 11, 1)
				.with(TemporalAdjusters.firstInMonth(DayOfWeek.SUNDAY));

		return on.isAfter(dstStart) && on.isBefore(dstEnd);
	}

}

/**
 *
 */
package com.dakshata.constants.instrument;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * Represents a stock exchange.
 *
 * @author PRITESH
 *
 */
@Getter
@AllArgsConstructor
@Slf4j
public enum Exchange {

	NSE(LocalTime.of(9, 15), LocalTime.of(15, 30), ExchSegments.NSE, (short) 0),
	BSE(LocalTime.of(9, 15), LocalTime.of(15, 30), ExchSegments.BSE, (short) 1),
	MCX(LocalTime.of(9, 0), LocalTime.of(23, 30), ExchSegments.MCX, (short) 2),
	NCDEX(LocalTime.of(10, 0), LocalTime.of(23, 30), ExchSegments.NCDEX, (short) 3);

	/**
	 * Base trading hours of the exchange's primary segment. These are indicative only &mdash; they
	 * carry neither the segment split (NSE currency trades past equity close) nor the daylight-saving
	 * shift on the commodity evening session.
	 *
	 * @deprecated resolve hours through {@link MarketHours} instead, passing the broker specific
	 *             exchange/segment string. {@link #isOpen(LocalDateTime)} already does.
	 */
	@Deprecated
	private final LocalTime startTime, endTime;

	private final Set<String> segments;

	// Index is used for serialization (so never change index for an exchange)
	private final short index;

	public static Exchange of(final int exchange) {
		final short ex = (short) exchange;
		for (final Exchange e : Exchange.values()) {
			if (ex == e.getIndex()) {
				return e;
			}
		}

		throw new RuntimeException("Invalid Exchange: " + exchange);
	}

	public static Exchange of(final String exchange) {
		final String uex = exchange.toUpperCase();
		for (final Exchange e : Exchange.values()) {
			if (e.getSegments().contains(uex)) {
				return e;
			}
		}

		throw new RuntimeException("Invalid Exchange: " + exchange);
	}

	public static final Exchange fromFyers(final int exchange) {
		switch (exchange) {
		case 10:
			return NSE;
		case 11:
			return MCX;
		case 12:
			return BSE;
		}

		log.error("SD-ERR-023: Cannot convert exchange. Raw: {}", exchange);
		throw new RuntimeException("Invalid exchange: " + exchange);
	}

	public static final Exchange fromIifl(final String exchange) {
		switch (exchange) {
		case "N":
			return NSE;
		case "M":
			return MCX;
		case "B":
			return BSE;
		}

		log.error("SD-ERR-023: Cannot convert exchange. Raw: {}", exchange);
		throw new RuntimeException("Invalid exchange: " + exchange);
	}

	public final String toIifl() {
		switch (this) {
		case NSE:
			return "N";
		case MCX:
			return "M";
		case BSE:
			return "B";
		default:
			break;
		}

		return null;
	}

	/**
	 * Is this exchange's primary segment trading? Equity exchanges answer for the cash segment, so a
	 * currency position on NSE is NOT covered by {@code NSE.isOpen(...)} &mdash; call
	 * {@link MarketHours#isOpen(String, LocalDateTime)} with the broker segment for that.
	 */
	public final boolean isOpen(final LocalDateTime when) {
		return MarketHours.isOpen(this.session(), when);
	}

	/**
	 * This only tells if exchange has started or not.
	 */
	public final boolean hasStarted(final LocalDateTime when) {
		return MarketHours.hasStarted(this.session(), when);
	}

	private MarketHours.Session session() {
		return MarketHours.sessionOf(this.name());
	}

}

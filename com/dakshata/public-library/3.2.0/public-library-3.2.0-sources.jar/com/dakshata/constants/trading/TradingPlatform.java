package com.dakshata.constants.trading;

import java.util.EnumSet;
import java.util.Set;

import com.dakshata.constants.instrument.Source;

import lombok.Getter;

/**
 * Enum representing various trading platforms.
 */
@Getter
public enum TradingPlatform {

    // @formatter:off
    ALICE_API_V2_IPV6(Source.ALICEBLUE, "AliceBlue", TradingPlatformFeature.IPV6),
    CHOICE_API_TOTP(Source.CHOICE, "Choice"),
    DHAN_V2_IPV6(Source.DHAN, "Dhan", TradingPlatformFeature.IPV6),
    DHAN_V2_AT_IPV6(Source.DHAN, "Dhan", TradingPlatformFeature.IPV6),
    FP_API_TOTP(Source.FIVE_PAISA, "5Paisa"),
    FP_API_IPV6(Source.FIVE_PAISA, "5Paisa", TradingPlatformFeature.IPV6),
    FYERS_API_IPV6(Source.FYERS, "Fyers", TradingPlatformFeature.IPV6, TradingPlatformFeature.MPP),
    GROWW_API_IPV6(Source.GROWW, "Groww", TradingPlatformFeature.IPV6),
    IIFL_MKT_API_IPV6(Source.IIFL_MARKETS, "IIFL", TradingPlatformFeature.IPV6, TradingPlatformFeature.MPP),
    KITE_IPV6(Source.ZERODHA, "Zerodha", TradingPlatformFeature.IPV6),
    KOTAK_NEO_IPV6(Source.KOTAK_NEO, "Kotak", TradingPlatformFeature.LOGIN_ID_CAPS, TradingPlatformFeature.IPV6),
    MASTERTRUST(Source.MASTERTRUST, "Mastertrust"),
    MOTILAL_API_V7(Source.MOTILAL_OSWAL, "Motilal"),
    MYNT_API_IPV4(Source.ZEBU, "Zebu", TradingPlatformFeature.KAMBALA),
    NUVAMA_RETAIL(Source.EDELWEISS, "Nuvama"),
    SAS_STOCKO_API(Source.SAS, "SAS"),
    SHAREKHAN_API(Source.SHAREKHAN, "Sharekhan"),
    SHAREKHAN_API_M(Source.SHAREKHAN, "Sharekhan", TradingPlatformFeature.OAUTH),
    SHOONYA_BETA(Source.FINVASIA, "Finvasia"),
    SMART_API(Source.ANGEL, "Angel"),
    SMART_API_M(Source.ANGEL, "Angel", TradingPlatformFeature.OAUTH),
    UPSTOX_API_AT_IPV6(Source.UPSTOX_API, "Upstox", TradingPlatformFeature.IPV6),
    ZERODHA_API_IPV6(Source.ZERODHA, "Zerodha", TradingPlatformFeature.IPV6, TradingPlatformFeature.MPP),
    ZERODHA_API_M_IPV6(Source.ZERODHA, "Zerodha", TradingPlatformFeature.OAUTH, TradingPlatformFeature.IPV6, TradingPlatformFeature.MPP),

    // XTS Platforms
    XTS_AETRAM(Source.XTS_AETRAM, "AETRAM", TradingPlatformFeature.XTS),
    XTS_AGARWAL(Source.XTS_AGARWAL, "AC Agarwal", TradingPlatformFeature.XTS),
    XTS_AMBALAL(Source.XTS_AMBALAL, "Ambalal", TradingPlatformFeature.XTS),
    XTS_ARHAM(Source.XTS_ARHAM, "ARHAM", TradingPlatformFeature.XTS),
    XTS_ANAND_RATHI(Source.ANAND_RATHI, "AnandRathi", TradingPlatformFeature.XTS),
    XTS_ATS(Source.XTS_ATS, "ATS", TradingPlatformFeature.XTS),
    XTS_AXIS(Source.XTS_AXIS, "Axis", TradingPlatformFeature.XTS),
    XTS_DBONLINE(Source.XTS_DBONLINE, "DBOnline", TradingPlatformFeature.XTS),
    XTS_EUREKA(Source.XTS_EUREKA, "Eureka", TradingPlatformFeature.XTS),
    XTS_EUREKA_PROP(Source.XTS_EUREKA, "Eureka - PROP", TradingPlatformFeature.XTS),
    XTS_FIVE_PAISA(Source.XTS_FIVE_PAISA, "5Paisa", TradingPlatformFeature.XTS),
    XTS_IIFL(Source.XTS_IIFL, "IIFL", TradingPlatformFeature.XTS),
    XTS_JAINAM(Source.XTS_JAINAM, "Jainam", TradingPlatformFeature.XTS),
    XTS_JAINAM_PROP_A(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS),
    XTS_JAINAM_PROP_B(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS),
    XTS_JAINAM_PROP_C(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS),
    XTS_JAINAM_PROP_D(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS),
    XTS_MLB(Source.XTS_MLB, "MLB", TradingPlatformFeature.XTS),
    XTS_MOTILAL(Source.XTS_MOTILAL, "Motilal", TradingPlatformFeature.XTS),
    XTS_PESB(Source.XTS_PESB, "PESB", TradingPlatformFeature.XTS),
    XTS_RELIGARE(Source.XTS_RELIGARE, "Religare", TradingPlatformFeature.XTS),
    XTS_RMONEY(Source.XTS_RMONEY, "Rmoney", TradingPlatformFeature.XTS),
    XTS_SHARE_IND(Source.XTS_SHARE_IND, "Share India", TradingPlatformFeature.XTS),
    XTS_SHARE_IND_PROP(Source.XTS_SHARE_IND, "Share India - PROP", TradingPlatformFeature.XTS),
    XTS_SHARE_IND_PROP_M(Source.XTS_SHARE_IND, "Share India - PROP", TradingPlatformFeature.XTS),
    XTS_SMC(Source.XTS_SMC, "SMC", TradingPlatformFeature.XTS),
    XTS_SW_CAPITAL(Source.XTS_SW_CAPITAL, "SW Capital", TradingPlatformFeature.XTS),
    XTS_TSWIFT(Source.XTS_TSWIFT, "Tradeswift", TradingPlatformFeature.XTS),
    XTS_WISDOM(Source.XTS_WISDOM, "WisdomCapital", TradingPlatformFeature.XTS),
    XTS_ZEBU(Source.XTS_ZEBU, "Zebu", TradingPlatformFeature.XTS),

    // KAMBALA Platforms
    KAMBALA_FLAT_IPV4(Source.KAMBALA_FLATTRADE, "Flattrade", TradingPlatformFeature.KAMBALA),
    KAMBALA_FIN_IPV4(Source.FINVASIA, "Finvasia", TradingPlatformFeature.KAMBALA),
    KAMBALA_PL_IPV4(Source.KAMBALA_PLINDIA, "Prabhudas Lilladher", TradingPlatformFeature.KAMBALA),
    KAMBALA_PROFIT_IPV4(Source.KAMBALA_PROFITMART, "Profitmart", TradingPlatformFeature.KAMBALA),
    KAMBALA_TRADEJINI(Source.KAMBALA_TRADEJINI, "Tradejini", TradingPlatformFeature.KAMBALA);
    // @formatter:on

    private final Source source;
    private final String brokerName;
    private final Set<TradingPlatformFeature> features;

    TradingPlatform(final Source source, final String brokerName, final TradingPlatformFeature... features) {
        this.source = source;
        this.brokerName = brokerName;
        this.features = features.length > 0 ? EnumSet.of(features[0], features)
                : EnumSet.noneOf(TradingPlatformFeature.class);
    }

    public boolean hasFeature(final TradingPlatformFeature feature) {
        return this.features.contains(feature);
    }

    public boolean isXts() {
        return this.features.contains(TradingPlatformFeature.XTS);
    }

    public boolean isKambala() {
        return this.features.contains(TradingPlatformFeature.KAMBALA);
    }

    public boolean isOAuth() {
        return this.features.contains(TradingPlatformFeature.OAUTH);
    }

    public boolean isLoginIdCaps() {
        return this.features.contains(TradingPlatformFeature.LOGIN_ID_CAPS);
    }

    public boolean isIpv6() {
        return this.features.contains(TradingPlatformFeature.IPV6);
    }

    /**
     * True for platforms that egress over the IPv4 (proxy) network path rather than
     * a direct IPv6 bind. This is the exact complement of {@link #isIpv6()} and
     * mirrors how {@code IpAssignmentService} routes an account: IPv6 platforms bind
     * an assigned IPv6 directly, while every other platform egresses through the
     * IPv4 proxy pool (or a user's BYOIP proxy). Those proxied platforms are the ones
     * exposed to proxy-induced arrival bunching at the broker, so the per-account
     * in-flight order cap is applied to them.
     */
    public boolean isIpv4() {
        return !this.isIpv6();
    }

    public boolean isMpp() {
        return this.features.contains(TradingPlatformFeature.MPP);
    }
}

enum TradingPlatformFeature {
    XTS, KAMBALA, OAUTH, LOGIN_ID_CAPS, IPV6, MPP
}

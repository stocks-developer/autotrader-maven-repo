/**
 *
 */
package com.dakshata.tools.number;

/**
 * Performs number checks.
 *
 * @author PRITESH
 *
 */
public final class Checks {

	private Checks() {
	}

	public static boolean nonNullBoolean(final Boolean value, final boolean defaultVal) {
		return value == null ? defaultVal : value;
	}

	public static boolean nonNullBoolean(final Boolean value) {
		return nonNullBoolean(value, false);
	}

	public static float nonNullFloat(final Float value, final float defaultVal) {
		return value == null ? defaultVal : value;
	}

	public static float nonNullFloat(final Float value) {
		return nonNullFloat(value, 0);
	}

	public static double nonNullDouble(final Double value, final float defaultVal) {
		return value == null ? defaultVal : value;
	}

	public static double nonNullDouble(final Double value) {
		return nonNullDouble(value, 0);
	}

	public static int nonNullInt(final Integer value, final int defaultVal) {
		return value == null ? defaultVal : value;
	}

	public static int nonNullInt(final Integer value) {
		return nonNullInt(value, 0);
	}

	public static long nonNullLong(final Long value, final long defaultVal) {
		return value == null ? defaultVal : value;
	}

	public static long nonNullLong(final Long value) {
		return nonNullLong(value, 0);
	}

	/**
	 * Null-preserving {@code Integer} to {@code Float} widening. Java refuses to box-and-widen in one
	 * step, so an {@code Integer} cannot be handed to a {@code Float} parameter directly.
	 */
	public static Float toFloat(final Integer value) {
		return (value == null) ? null : value.floatValue();
	}

}

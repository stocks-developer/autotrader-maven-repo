package com.dakshata.tools.number;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

/**
 * Writes a {@code Float} as a plain integer whenever it has no fractional part, and only falls back
 * to decimal notation when the value genuinely needs it — {@code 1} rather than {@code 1.0}, but
 * still {@code 0.1}.
 *
 * <p>This exists to protect published API contracts when a field has to widen from {@code Integer}
 * to {@code Float}. The position {@code multiplier} is the case it was written for: its documented
 * type is {@code int}, and it is a whole number on every equity and equity-derivative contract, but
 * a handful of commodity contracts have a genuinely fractional scale (MCX GOLDM = 0.1). Without
 * this, widening the field would rewrite {@code "multiplier":1} as {@code "multiplier":1.0} in every
 * response and break clients parsing it strictly as an integer — for no benefit, since their value
 * was never wrong. With it, only the contracts whose old value was actually wrong change shape.
 *
 * @author PRITESH
 */
public class WholeFloatSerializer extends JsonSerializer<Float> {

	@Override
	public void serialize(final Float value, final JsonGenerator gen, final SerializerProvider serializers)
			throws IOException {

		if (value == null) {
			gen.writeNull();
			return;
		}

		// Infinite/NaN have no integral form; hand them to Jackson's own float handling.
		if (value.isNaN() || value.isInfinite()) {
			gen.writeNumber(value);
			return;
		}

		if (value == Math.rint(value)) {
			gen.writeNumber(value.longValue());
		} else {
			gen.writeNumber(value);
		}
	}

}

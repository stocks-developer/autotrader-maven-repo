package com.dakshata.trading.model.trade;

import static com.dakshata.constants.data.model.ICommon.SHORT_VARCHAR_LENGTH;
import static com.dakshata.tools.string.StringUtil.isEmpty;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.*;

import com.dakshata.tools.string.StringUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.*;

@Builder
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Table(indexes = { @Index(columnList = "name,trading_acc_id", unique = true) }, schema = "trading", catalog = "trading")
@JsonIgnoreProperties(ignoreUnknown = true)
public class PseudoAccount implements IPseudoAccount, Serializable {

	private static final long serialVersionUID = 5400292038027023848L;

	private static final boolean DEFAULT_COPY_PARALLEL = true;

	private static final boolean DEFAULT_LIVE = false;

	private static final boolean DEFAULT_COPY = false;

	private static final boolean DEFAULT_COPY_CANCEL = false;

	private static final boolean DEFAULT_COPY_MODIFY = false;

	private static final boolean DEFAULT_COPY_AUTO_SPLIT_QTY = false;

	/**
	 * Don't start too early, because broker's BOD is not done then the API may
	 * return previous day's orders.
	 */
	private static final String DEFAULT_COPY_START = "09:00";

	/**
	 * To avoid too many requests, we have kept default time to NSE's end time. This tracks the NSE
	 * equity derivatives close, which moved from 15:30 to 15:40 on
	 * {@link com.dakshata.constants.instrument.MarketHours#MARKET_TIMING_REVISION_DATE} — the latest
	 * either equity segment trades, so copying covers cash and F&amp;O alike.
	 */
	private static final String DEFAULT_COPY_END = "15:40";

	private static final String DEFAULT_COPY_SEGMENTS = "NSE_CASH,NSE_FNO,BSE_CASH,BSE_FNO,MCX";

	private static final Set<String> DEFAULT_COPY_SEGMENTS_SET = Collections
			.unmodifiableSet(Stream.of(DEFAULT_COPY_SEGMENTS.split(",")).collect(Collectors.toSet()));

	@Id
	@GeneratedValue
	@EqualsAndHashCode.Include
	private Long id;

	@EqualsAndHashCode.Include
	@Column(name = "name", nullable = false, length = SHORT_VARCHAR_LENGTH)
	private String key;

	@EqualsAndHashCode.Include
	@ManyToOne
	@JoinColumn(name = "trading_acc_id")
	private TradingAccount account;

	@EqualsAndHashCode.Include
	@Column(nullable = false, length = SHORT_VARCHAR_LENGTH)
	private String username;

	/**
	 * Indicates whether a pseudo account is live & can be used for trading.
	 */
	@Column(nullable = false)
	private Boolean live;

	/**
	 * Indicates whether automatic order placement copying (from master) is enabled
	 * for this pseudo account.
	 */
	@Builder.Default
	private Boolean copy = DEFAULT_COPY;

	/**
	 * Indicates whether automatic order cancellation copying (from master) is
	 * enabled for this pseudo account.
	 */
	@Builder.Default
	private Boolean copyCancel = DEFAULT_COPY_CANCEL;

	/**
	 * Indicates whether automatic order cancellation copying (from master) is
	 * enabled for this pseudo account.
	 */
	@Builder.Default
	private Boolean copyModify = DEFAULT_COPY_MODIFY;

	@Builder.Default
	@Column(length = 5)
	private String copyStartTime = DEFAULT_COPY_START;

	@Builder.Default
	@Column(length = 5)
	private String copyEndTime = DEFAULT_COPY_END;

	@Builder.Default
	private Boolean copyParallel = DEFAULT_COPY_PARALLEL;

	@Builder.Default
	private Boolean copyAutoSplitQty = DEFAULT_COPY_AUTO_SPLIT_QTY;

	@Column
	private Boolean deleted;

	@Version
	private Integer version;

	@Column(updatable = false)
	private Timestamp createdTime;

	private Timestamp modifiedTime;

	/**
	 * This field indicates what time copying was enabled, so that orders prior to
	 * that time can be skipped.
	 */
	@Column(name = "last_cp_on_time")
	private Timestamp lastCopyEnabledTime;

	/**
	 * This field indicates what time account was marked live, so that orders prior
	 * to that time can be skipped in copy-trading.
	 */
	private Timestamp lastLiveTime;

	@Column(length = 50)
	private String copySegments;

	@Transient
	@JsonIgnore
	@ToString.Exclude
	private transient Set<String> copySegmentsSet;

	@Override
	public String toString() {
		final String accountId = Optional.ofNullable(this.account).map(TradingAccount::getLoginId).orElse("<#NA>");
		final String brokerName = Optional.ofNullable(this.account).map(TradingAccount::getBroker)
				.map(StockBroker::getId).orElse("");
		final String name = Optional.ofNullable(this.key).orElse("");

		return String.format("[%s]", Stream.of(name, brokerName, accountId).filter(p -> !StringUtil.isEmpty(p))
				.collect(Collectors.joining(" | ")));
	}

	/**
	 * Primarily used in logging to reduce logging.
	 *
	 * @return login id uppercase
	 */
	public String loginIdUppercase() {
		return Optional.ofNullable(this.account).map(TradingAccount::getLoginId).orElse("<#NA>").toUpperCase();
	}

	@Override
	@JsonIgnore
	public String activityModelId() {
		return this.getKey();
	}

	public final String getPortfolioKey() {
		return preparePortfolioKey(this.getUsername(), this.getKey());
	}

	public static final String preparePortfolioKey(final String username, final String key) {
		// Make sure key is case-insensitive
		return (username + '|' + key).toLowerCase();
	}

	@PrePersist
	void onCreate() {
		this.createdTime = new Timestamp(System.currentTimeMillis());
	}

	@PreUpdate
	void onPersist() {
		this.modifiedTime = new Timestamp(System.currentTimeMillis());
	}

	@Override
	public Boolean getCopy() {
		return (this.copy == null) ? DEFAULT_COPY : this.copy;
	}

	@Override
	public Boolean getCopyCancel() {
		return (this.copyCancel == null) ? DEFAULT_COPY_CANCEL : this.copyCancel;
	}

	@Override
	public Boolean getCopyModify() {
		return (this.copyModify == null) ? DEFAULT_COPY_MODIFY : this.copyModify;
	}

	@Override
	public String getCopyStartTime() {
		return isEmpty(this.copyStartTime) ? DEFAULT_COPY_START : this.copyStartTime;
	}

	@Override
	public String getCopyEndTime() {
		return isEmpty(this.copyEndTime) ? DEFAULT_COPY_END : this.copyEndTime;
	}

	@Override
	public Boolean getLive() {
		return (this.live == null) ? DEFAULT_LIVE : this.live;
	}

	@Override
	public Boolean getCopyParallel() {
		return (this.copyParallel == null) ? DEFAULT_COPY_PARALLEL : this.copyParallel;
	}

	public boolean getCopyAutoSplitQty() {
		return (this.copyAutoSplitQty == null) ? DEFAULT_COPY_AUTO_SPLIT_QTY : this.copyAutoSplitQty;
	}

	public String getCopySegments() {
		return StringUtil.isEmpty(this.copySegments) ? DEFAULT_COPY_SEGMENTS : this.copySegments;
	}

	// Override the setter to invalidate the transient set whenever the string
	// changes
	public void setCopySegments(final String copySegments) {
		this.copySegments = copySegments;
		this.copySegmentsSet = null; // Force lazy-rebuild on next get
	}

	// Lazy-loaded, read-only Set for high-performance processing
	public Set<String> getCopySegmentsSet() {
		if (this.copySegmentsSet == null) {
			if (StringUtil.isEmpty(this.copySegments)) {
				this.copySegmentsSet = DEFAULT_COPY_SEGMENTS_SET;
			} else {
				this.copySegmentsSet = Collections.unmodifiableSet(Stream.of(this.copySegments.split(","))
						.map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toSet()));
			}
		}
		return this.copySegmentsSet;
	}

}

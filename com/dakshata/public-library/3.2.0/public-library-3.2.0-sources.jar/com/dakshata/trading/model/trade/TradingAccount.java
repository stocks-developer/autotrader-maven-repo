/**
 *
 */
package com.dakshata.trading.model.trade;

import static com.dakshata.constants.data.model.ICommon.SHORT_VARCHAR_LENGTH;
import static com.dakshata.tools.trading.KeyBuilder.makeTradingAccKey;
import static java.util.stream.Collectors.toList;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.*;

import com.dakshata.constants.trading.TradingPlatform;
import com.dakshata.tools.jpa.EncryptionConverter;
import com.dakshata.tools.string.StringUtil;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Represents a trading account.<br>
 * We are not using constants here for schema name, as we do not want to make
 * ISchema class public to the world due to security concerns.
 *
 * @author PRITESH
 *
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Table(indexes = {
		@Index(name = "trading_account_loginid_brokerid_uk", columnList = "loginId,broker_id", unique = true),
		@Index(name = "trading_account_username_idx", columnList = "username") }, schema = "trading", catalog = "trading")
@JsonIgnoreProperties(ignoreUnknown = true)
public class TradingAccount implements ITradingAccount, Serializable {

	private static final long serialVersionUID = 4724887027232692102L;

	@Id
	@GeneratedValue
	@EqualsAndHashCode.Include
	private Long id;

	@EqualsAndHashCode.Include
	@ManyToOne(optional = false)
	private StockBroker broker;

	@EqualsAndHashCode.Include
	@Column(nullable = false, length = SHORT_VARCHAR_LENGTH)
	private String loginId;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false, length = 20)
	private TradingPlatform platform;

	/*
	 * Sensitive data is stored in encrypted form. Hence we keep a default column
	 * length (255).
	 */

	@Convert(converter = EncryptionConverter.class)
	@Column(length = 100)
	private String password;

	@Convert(converter = EncryptionConverter.class)
	@Column(length = 100)
	private String securityAnswer;

	// We do not save it as it is not used anywhere
	@Transient
	private String transactionPassword;

	@Column(nullable = false, length = SHORT_VARCHAR_LENGTH)
	private String username;

	@Version
	private Integer version;

	@Column(updatable = false)
	private Timestamp createdTime;

	@Column
	private Timestamp modifiedTime;

	@Column(length = 130)
	private String apiKey;

	@Column(length = 30)
	private String apiAppName;

	@Column(length = 30)
	private String apiUserId;

	@Column
	private Integer apiAppSource;

	@Column(length = 30)
	private String apiPassword;

	@Column(length = 100)
	private String apiEncryptionKey;

	@Column(length = SHORT_VARCHAR_LENGTH)
	private String email;

	@Column(length = 10)
	private String phone;

	@Convert(converter = EncryptionConverter.class)
	@Lob
	private String token;

	/**
	 * In the old framework platforms, this represents the IPv4 address. New
	 * framework platforms use this field for storing which IPv6 address to use for
	 * communication out of primary and secondary. The decision is taken based on
	 * which host the account is running on.
	 */
	@Transient
	private String primaryIpAddress;

	/**
	 * Proxy Host.
	 */
	@Transient
	private String proxyHost;

	/**
	 * Proxy Port.
	 */
	@Transient
	private Integer proxyPort;

	/**
	 * Proxy authentication username. Populated from user-provided IP config.
	 */
	@Transient
	private String proxyUser;

	/**
	 * Proxy authentication password. Populated from user-provided IP config.
	 */
	@Transient
	private String proxyPassword;

	@Override
	public String toString() {
		final String brokerName = Optional.ofNullable(this.broker).map(StockBroker::getId).orElse("");
		final String login = Optional.ofNullable(this.loginId).orElse("Unknown");
		return String.format("[%s]",
				Stream.of(brokerName, login).filter(p -> !StringUtil.isEmpty(p)).collect(Collectors.joining(" | ")));
	}

	@PrePersist
	void onCreate() {
		this.createdTime = new Timestamp(System.currentTimeMillis());
		this.trimCredentials();
	}

	@PreUpdate
	void onPersist() {
		this.modifiedTime = new Timestamp(System.currentTimeMillis());
		this.trimCredentials();
	}

	/**
	 * Strips leading/trailing whitespace from the broker credential identifiers.
	 * These are copy-pasted from a broker's developer portal, so a stray space rides
	 * along often enough to matter: the broker then rejects every authenticated call
	 * (e.g. Angel's AG8004 "Invalid API Key") while login itself still succeeds,
	 * which makes an unusable account look like a platform fault.
	 * <p>
	 * Deliberately limited to identifier-style fields. {@code password} and
	 * {@code securityAnswer} are left untouched - a real password may legitimately
	 * begin or end with a space, and silently changing it would lock the user out.
	 */
	private void trimCredentials() {
		// loginId is NOT NULL, so it is only trimmed - never collapsed to null.
		this.loginId = (this.loginId == null) ? null : this.loginId.trim();
		this.apiKey = trimToNull(this.apiKey);
		this.apiAppName = trimToNull(this.apiAppName);
		this.apiUserId = trimToNull(this.apiUserId);
		this.apiPassword = trimToNull(this.apiPassword);
		this.apiEncryptionKey = trimToNull(this.apiEncryptionKey);
	}

	/**
	 * @return the trimmed value, or null when it is null or blank. Blank collapses to
	 *         null so an all-whitespace paste is not stored as a "present" credential.
	 */
	private static String trimToNull(final String value) {
		if (value == null) {
			return null;
		}

		final String trimmed = value.trim();
		return trimmed.isEmpty() ? null : trimmed;
	}

	@Override
	public boolean equalsBusiness(final ITradingAccount other) {
		if (this.equals(other)) {
			return true;
		}

		if ((this.broker != null) && (other.getBroker() != null) && (this.loginId != null)
				&& (other.getLoginId() != null)) {
			return this.broker.equals(other.getBroker()) && this.loginId.equals(other.getLoginId());
		}

		return false;
	}

	@JsonIgnore
	public String loginIdUppercase() {
		return Optional.ofNullable(this.loginId).map(String::trim).map(String::toUpperCase).orElse(null);
	}

	@Override
	@JsonIgnore
	public String activityModelId() {
		return prepareActivityModelId(this.getBroker(), this.getLoginId());
	}

	@Override
	@JsonIgnore
	public String ledgerKey() {
		return prepareLedgerKey(this.getBroker(), this.getLoginId());
	}

	public PseudoAccount findMatchingPseudoAcc(final List<PseudoAccount> pas) {
		final List<PseudoAccount> matches = pas.stream()
				.filter(pa -> (pa.getAccount() != null) && pa.getAccount().getId().equals(this.id)).collect(toList());

		if (matches.isEmpty()) {
			return null;
		}

		final Optional<PseudoAccount> live = matches.stream().filter(PseudoAccount::getLive).findFirst();

		return live.isPresent() ? live.get() : matches.iterator().next();
	}

	public static final String prepareActivityModelId(final StockBroker broker, final String loginId) {
		return makeTradingAccKey(broker, loginId);
	}

	public static final String prepareLedgerKey(final StockBroker broker, final String loginId) {
		return makeTradingAccKey(broker, loginId);
	}

}

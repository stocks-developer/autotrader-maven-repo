/**
 *
 */
package com.dakshata.trading.model.platform;

import static com.dakshata.constants.data.model.ICommon.SHORT_VARCHAR_LENGTH;

import java.time.LocalDate;
import java.util.Comparator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Transient;

import com.dakshata.constants.trading.PositionDirection;
import com.dakshata.constants.trading.PositionState;
import com.dakshata.constants.trading.PositionType;
import com.dakshata.constants.trading.TradingPlatform;
import com.dakshata.tools.comparator.LiteralComparator;
import com.dakshata.tools.number.WholeFloatSerializer;
import com.dakshata.trading.model.portfolio.Position;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.opencsv.bean.CsvIgnore;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

/**
 * Represents a position record from trading platform.
 *
 * @author PRITESH
 *
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = true)
public class PlatformPosition extends Position implements IPlatformPosition {

	private static final long serialVersionUID = -2342824612058285182L;

	/**
	 * TreeMap uses compareTo() for equality check and hence we it was considering
	 * objects duplicate of their platform time matches
	 */
	@CsvIgnore
	public static final Comparator<PlatformPosition> COMPARE_BY_CAT_EX_SYB_TYPE = Comparator
			.comparing(PlatformPosition::getCategory, Comparator.nullsFirst(String::compareTo))
			.thenComparing(PlatformPosition::getIndependentExchange, Comparator.nullsFirst(String::compareTo))
			.thenComparing(PlatformPosition::getIndependentSymbol, Comparator.nullsFirst(String::compareTo))
			.thenComparing(PlatformPosition::getType, Comparator.nullsFirst(PositionType::compareTo))
			.thenComparing(PlatformPosition::getPseudoAccount, Comparator.nullsFirst(String::compareTo))
			.thenComparing(PlatformPosition::getDay, Comparator.nullsFirst(LocalDate::compareTo))
			.thenComparing(PlatformPosition::getId, Comparator.nullsFirst(Long::compareTo));

	@CsvIgnore
	private static final String[] CSV_ORDER = { "PSEUDOACCOUNT", "TRADINGACCOUNT", "TYPE", "CATEGORY",
			"INDEPENDENTEXCHANGE", "INDEPENDENTSYMBOL", "MTM", "PNL", "BUYQUANTITY", "SELLQUANTITY", "NETQUANTITY",
			"BUYVALUE", "SELLVALUE", "NETVALUE", "BUYAVGPRICE", "SELLAVGPRICE", "REALISEDPNL", "UNREALISEDPNL",
			"OVERNIGHTQUANTITY", "MULTIPLIER", "LTP", "EXCHANGE", "SYMBOL", "DAY", "PLATFORM", "ACCOUNTID", "ID",
			"STOCKBROKER", "STATE", "DIRECTION", "ATPNL" };

	/**
	 * Writes MULTIPLIER without a decimal tail.
	 *
	 * <p>The field is a {@code Float} because a few commodity contracts have a fractional scale
	 * (MCX GOLDM = 0.1), but it is whole on everything else — and this column has always been
	 * written as an integer, so emitting {@code 1.0} would change EVERY row of at-desktop's exported
	 * CSV and break downstream scripts parsing it strictly.
	 *
	 * <p>Done here rather than with {@code @CsvCustomBindByName} on the field: adding any binding
	 * annotation flips opencsv into annotation-driven mode, which silently drops every unannotated
	 * column — verified, it collapsed the export from 31 columns to 1.
	 */
	@CsvIgnore
	public static final HeaderColumnNameMappingStrategy<PlatformPosition> PLATFORM_CSV_STRATEGY = new HeaderColumnNameMappingStrategy<>() {

		/** -2 = not yet resolved, -1 = column absent. */
		private int multiplierColumn = -2;

		@Override
		public String[] transmuteBean(final PlatformPosition bean)
				throws CsvDataTypeMismatchException, CsvRequiredFieldEmptyException {

			final String[] cells = super.transmuteBean(bean);

			if (this.multiplierColumn == -2) {
				this.multiplierColumn = -1;
				final String[] header = this.generateHeader(bean);
				for (int i = 0; i < header.length; i++) {
					// Inlined, not a constant: opencsv maps static fields as columns unless they
					// carry @CsvIgnore, and a stray constant here adds a phantom CSV column.
					if ("MULTIPLIER".equalsIgnoreCase(header[i])) {
						this.multiplierColumn = i;
						break;
					}
				}
			}

			final int col = this.multiplierColumn;
			if ((col >= 0) && (col < cells.length)) {
				cells[col] = withoutDecimalTail(cells[col]);
			}
			return cells;
		}
	};

	/** {@code "1.0"} to {@code "1"}, leaving {@code "0.1"} and anything unparseable untouched. */
	private static String withoutDecimalTail(final String value) {
		if ((value == null) || value.isEmpty()) {
			return value;
		}
		try {
			final float f = Float.parseFloat(value);
			return (f == Math.rint(f)) ? String.valueOf((long) f) : value;
		} catch (final NumberFormatException e) {
			return value;
		}
	}

	static {
		PLATFORM_CSV_STRATEGY.setType(PlatformPosition.class);
		PLATFORM_CSV_STRATEGY.setColumnOrderOnWrite(new LiteralComparator<String>(CSV_ORDER));
	}

	@Column(length = SHORT_VARCHAR_LENGTH)
	@EqualsAndHashCode.Include
	private String category;

	private Float ltp;

	@Enumerated(EnumType.STRING)
	@Column(length = 21)
	@EqualsAndHashCode.Include
	private TradingPlatform platform;

	@Column(name = "acc_id", length = SHORT_VARCHAR_LENGTH)
	@EqualsAndHashCode.Include
	private String accountId;

	private Integer overnightQuantity;

	/**
	 * Contract scale applied to quantity when valuing the position: P&amp;L is
	 * {@code qty * multiplier * priceDiff}. Usually 1, but commodity contracts whose quoted price
	 * unit differs from the traded quantity unit need a real scale — and it is not always a whole
	 * number. MCX GOLDM, for example, is quantified in grams but quoted per 10 grams, so its
	 * multiplier is {@code 0.1}. Hence {@code Float}, not {@code Integer}.
	 *
	 * <p>Serialised by {@link WholeFloatSerializer} so it still emits {@code 1} and not {@code 1.0}:
	 * this field's published type was {@code int}, and it is whole on every equity and
	 * equity-derivative contract. Only the commodity contracts whose old integer value was wrong
	 * anyway now emit a decimal.
	 */
	@JsonSerialize(using = WholeFloatSerializer.class)
	private Float multiplier;

	private Float realisedPnl, unrealisedPnl;

	/**
	 * The rest of AutoTrader's own computed P&amp;L set (entry basis; {@code atMtm}
	 * previous-close basis). Together with {@code atPnl} these form "our" complete set, computed
	 * uniformly for every broker by {@code PositionEnrichment}.
	 *
	 * <p>INTERNAL (decided 2026-07-22): stored for analysis and used to fill the resolved
	 * user-facing columns ({@code pnl}/{@code mtm}/{@code realisedPnl}/{@code unrealisedPnl}),
	 * but not published — users get ONE resolved set, not two parallel ones. {@code @JsonIgnore}
	 * keeps them out of the API (Jackson serialises every getter and publishing cannot be
	 * undone); {@code @CsvIgnore} keeps at-desktop's CSV export at its long-standing 31 columns.
	 * Only {@code atPnl} stays published, for backward compatibility.
	 */
	@JsonIgnore
	@CsvIgnore
	private Float atMtm, atRealisedPnl, atUnrealisedPnl;

	/**
	 * The broker's P&amp;L set VERBATIM, captured by {@code PositionEnrichment} before the
	 * user-facing columns are resolved — null where the broker sent nothing, never back-filled.
	 * With the resolved set in {@code pnl}/{@code mtm}/{@code realisedPnl}/{@code unrealisedPnl}
	 * and ours in {@code at*}, these preserve the raw input so a wrong number can always be
	 * traced to its source (the discriminator the pre-2026-07 model lacked). Internal only.
	 */
	@JsonIgnore
	@CsvIgnore
	private Float brokerPnl, brokerMtm, brokerRealisedPnl, brokerUnrealisedPnl;

	/**
	 * Guards the one-time capture of the {@code broker*} fields: enrichment can run more than
	 * once on the same object (re-enrichment pass), and a second capture would read the already
	 * RESOLVED columns as if the broker had sent them. Transient — never persisted or published.
	 */
	@Transient
	@JsonIgnore
	@CsvIgnore
	private boolean brokerSetCaptured;

	/**
	 * The carried (overnight) leg, <b>signed</b>: positive = carried long, negative = carried
	 * short. Unlike {@code overnightQuantity} — a published magnitude that cannot tell the two
	 * apart — this can drive MTM. See trading/docs/pnl-mtm-reference-spec.md §7.2.
	 *
	 * <p>Intermediate inputs, NOT results: {@code @JsonIgnore} keeps them out of the published API
	 * (Jackson serialises every getter, and publishing cannot be undone), {@code @CsvIgnore} keeps
	 * them out of at-desktop's CSV export.
	 */
	@JsonIgnore
	@CsvIgnore
	private Integer carriedQuantity;

	/** Signed value the carried leg came in at. Same visibility rules as {@link #carriedQuantity}. */
	@JsonIgnore
	@CsvIgnore
	private Float carriedValue;

	/**
	 * The previous close actually used for {@code atMtm} on this row — stored so an MTM is
	 * reproducible after the fact (a bad close and bad arithmetic are otherwise
	 * indistinguishable). Same visibility rules as {@link #carriedQuantity}.
	 */
	@JsonIgnore
	@CsvIgnore
	private Float prevClose;

	private PositionState state;

	private PositionDirection direction;

}

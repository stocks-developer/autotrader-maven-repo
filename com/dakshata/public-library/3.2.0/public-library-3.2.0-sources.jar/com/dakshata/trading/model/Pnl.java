/**
 *
 */
package com.dakshata.trading.model;

import lombok.Builder;
import lombok.Data;

/**
 * Represents a detailed profit and loss information.
 *
 * @author PRITESH
 *
 */
@Builder
@Data
public class Pnl {

	private Float pnl, mtm, realisedPnl, unrealisedPnl;
	
	private Float multiplier;

	private Integer lotSize;
	
}

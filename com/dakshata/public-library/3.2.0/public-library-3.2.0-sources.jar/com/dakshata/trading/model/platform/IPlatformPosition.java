package com.dakshata.trading.model.platform;

import com.dakshata.constants.trading.PositionDirection;
import com.dakshata.constants.trading.PositionState;
import com.dakshata.constants.trading.TradingPlatform;
import com.dakshata.trading.model.portfolio.IPosition;

public interface IPlatformPosition extends IPosition {

	/**
	 * Some platforms return multiple sets of positions. For example, see below
	 * response format from Zerodha:<br>
	 * <br>
	 * The positions API returns two sets of positions, net and day. net is the
	 * actual, current net position portfolio, while day is a snapshot of the buying
	 * and selling activity for that particular day.
	 */
	String getCategory();

	/**
	 * Raw trading account id
	 */
	String getAccountId();

	/**
	 * LTP isn't really a part of position, but many platforms return it inside
	 * position object.
	 */
	Float getLtp();

	/**
	 * Represents the trading platform to which this position belongs.
	 */
	TradingPlatform getPlatform();

	/**
	 * Quantity held previously and carried forward over night
	 *
	 */
	Integer getOvernightQuantity();

	/**
	 * The quantity/lot size multiplier used for calculating P&Ls, i.e.
	 * {@code pnl = quantity * multiplier * priceDifference}.
	 *
	 * <p>Usually 1. It is a fraction on commodity contracts whose quoted price unit is coarser than
	 * the traded quantity unit — MCX GOLDM is held in grams but quoted per 10 grams, giving
	 * {@code 0.1}.
	 */
	Float getMultiplier();

	/**
	 * Realised intraday returns
	 */
	Float getRealisedPnl();

	/**
	 * Unrealised intraday returns
	 */
	Float getUnrealisedPnl();

	/**
	 * MTM computed by AutoTrader from the previous day's close, independent of the broker's
	 * {@code mtm}. Null until the previous-close plumbing populates it.
	 */
	Float getAtMtm();

	/**
	 * Realised P&amp;L computed by AutoTrader (entry basis, weighted average), independent of the
	 * broker's {@code realisedPnl}.
	 */
	Float getAtRealisedPnl();

	/**
	 * Unrealised P&amp;L computed by AutoTrader (entry basis), independent of the broker's
	 * {@code unrealisedPnl}. Always {@code atPnl - atRealisedPnl}.
	 */
	Float getAtUnrealisedPnl();

	/**
	 * The broker's total P&amp;L verbatim — null when the broker sent none. Captured before the
	 * user-facing {@code pnl} column is resolved. Internal.
	 */
	Float getBrokerPnl();

	/** The broker's MTM verbatim — null when the broker sent none. Internal. */
	Float getBrokerMtm();

	/** The broker's realised P&amp;L verbatim — null when the broker sent none. Internal. */
	Float getBrokerRealisedPnl();

	/** The broker's unrealised P&amp;L verbatim — null when the broker sent none. Internal. */
	Float getBrokerUnrealisedPnl();

	/**
	 * Carried (overnight) leg quantity, <b>signed</b>: positive = carried long, negative = carried
	 * short. Internal MTM input, not part of the published API — unlike
	 * {@link #getOvernightQuantity()}, which is a magnitude.
	 */
	Integer getCarriedQuantity();

	/**
	 * Signed value the carried leg came in at. Internal MTM input, not part of the published API.
	 */
	Float getCarriedValue();

	/**
	 * The previous day's close actually used for {@code atMtm} on this row. Internal, stored so a
	 * computed MTM is reproducible after the fact.
	 */
	Float getPrevClose();

	/**
	 * Position state OPEN or CLOSED.
	 */
	PositionState getState();

	/**
	 * Position direction (LONG, SHORT, NEUTRAL).
	 */
	PositionDirection getDirection();

}

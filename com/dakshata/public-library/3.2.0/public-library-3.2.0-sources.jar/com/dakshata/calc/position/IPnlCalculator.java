/**
 *
 */
package com.dakshata.calc.position;

import com.dakshata.trading.model.Pnl;
import com.dakshata.trading.model.platform.IPlatformPosition;

/**
 * PnL calculation for securities.
 *
 * @author PRITESH
 *
 */
public interface IPnlCalculator {

	/**
	 * Calculates detailed pnl.
	 *
	 * @param pos       position
	 * @param calcPrice price to be used for pnl calculation
	 * @return a pnl object
	 */
	Pnl calculate(IPlatformPosition pos, float calcPrice);

	/**
	 * Calculates detailed pnl.
	 *
	 * @param pos       position
	 * @param calcPrice price to be used for pnl calculation
	 * @param lotSize   lotSize (pass zero or null if not applicable)
	 * @return a pnl object
	 */
	Pnl calculate(IPlatformPosition pos, float calcPrice, final Integer lotSize);

	/**
	 * Calculates detailed pnl including a true previous-close-basis MTM.
	 *
	 * <p>Without a usable {@code prevClose} (null or non-positive), or when the position's carried
	 * leg cannot be determined, {@code mtm} falls back to {@code pnl} — exact for intraday
	 * positions, a bounded degradation for carried ones. See
	 * trading/docs/pnl-mtm-reference-spec.md §4.4 and §8.
	 *
	 * @param pos       position
	 * @param calcPrice price to be used for pnl calculation
	 * @param prevClose previous trading day's close (null when unknown)
	 * @param lotSize   lotSize (pass zero or null if not applicable)
	 * @return a pnl object
	 */
	Pnl calculate(IPlatformPosition pos, float calcPrice, final Float prevClose, final Integer lotSize);

	/**
	 * Calculates pnl.
	 *
	 * @param quantity     quantity
	 * @param buyAvgPrice  buy average price
	 * @param sellAvgPrice sell average price
	 * @param lotSize      lotSize (pass zero or null if not applicable)
	 * @param multiplier   multiplier (pass zero or null if not applicable)
	 * @return pnl
	 */
	float calculate(final int quantity, final float buyAvgPrice, final float sellAvgPrice, final Integer lotSize,
			final Float multiplier);

	/**
	 * Null safe method to calculate average price.
	 */
	float calcNetAvgPriceFromAvgPrice(final Integer cfQty, final Float cfAvgPrice, final Integer dayQty,
			final Float dayAvgPrice);

	/**
	 * Null safe method to calculate average price.
	 */
	float calcNetAvgPriceFromValue(final Integer cfQty, final Float cfValue, final Integer dayQty,
			final Float dayValue);

}

/**
 *
 */
package com.dakshata.calc.position;

import static com.dakshata.tools.number.Checks.nonNullFloat;
import static com.dakshata.tools.number.Checks.nonNullInt;
import static java.util.Optional.ofNullable;

import com.dakshata.trading.model.Pnl;
import com.dakshata.trading.model.platform.IPlatformPosition;

/**
 * Pnl calculator.
 *
 * @author PRITESH
 *
 */
public class PnlCalculator implements IPnlCalculator {

	private static final float DEFAULT_MULTIPLIER = 1f;

	private static final int DEFAULT_LOT_SIZE = 1;

	@Override
	public Pnl calculate(final IPlatformPosition pos, final float calcPrice) {
		return this.calculate(pos, calcPrice, null);
	}

	@Override
	public Pnl calculate(final IPlatformPosition pos, final float calcPrice, final Integer lotSize) {
		return this.calculate(pos, calcPrice, null, lotSize);
	}

	@Override
	public Pnl calculate(final IPlatformPosition pos, final float calcPrice, final Float prevClose,
			final Integer lotSize) {

		final int buyQty = ofNullable(pos.getBuyQuantity()).orElse(0);
		final int sellQty = ofNullable(pos.getSellQuantity()).orElse(0);
		final float multiplier = this.validMultiplier(pos.getMultiplier());
		final int lot = this.validLotSize(lotSize);

		// Reconcile each leg's broker-reported average against its broker-reported value before any
		// downstream P&L uses it — some brokers drop or charge-inflate the average on a carried
		// position while the value stays clean. See effectiveAvgPrice.
		final float buyAvgPrice = this.effectiveAvgPrice(ofNullable(pos.getBuyAvgPrice()).orElse(0f),
				pos.getBuyValue(), buyQty, multiplier);
		final float sellAvgPrice = this.effectiveAvgPrice(ofNullable(pos.getSellAvgPrice()).orElse(0f),
				pos.getSellValue(), sellQty, multiplier);

		final float realisedPnl = this.calculateRealisedPnl(buyQty, sellQty, buyAvgPrice, sellAvgPrice, lot,
				multiplier);

		// Float, not int: a fractional multiplier (MCX GOLDM = 0.1) would truncate the position to
		// zero quantity and report no P&L at all.
		final float finalBuyQty = buyQty * lot * multiplier;
		final float finalSellQty = sellQty * lot * multiplier;

		final float sellValue = sellAvgPrice * finalSellQty;
		final float buyValue = buyAvgPrice * finalBuyQty;

		// Remaining means open quantity on the other side
		// Example: A long position with 10 qty will have remaining sell qty = 10
		final float remainSellQty = Math.max(0, finalBuyQty - finalSellQty);
		final float remainBuyQty = Math.max(0, finalSellQty - finalBuyQty);

		final float remainSellVal = remainSellQty * calcPrice;
		final float remainBuyVal = remainBuyQty * calcPrice;

		final float totalSellVal = sellValue + remainSellVal;
		final float totalBuyVal = buyValue + remainBuyVal;

		final float pnl = (totalSellVal - totalBuyVal);

		// Unrealised is the remainder, which makes invariant I1 (pnl = realised + unrealised) hold
		// by construction. See trading/docs/pnl-mtm-reference-spec.md §4.3.
		final float unrealisedPnl = pnl - realisedPnl;

		final float mtm = this.calculateMtm(pos, pnl, buyQty, sellQty, buyAvgPrice, sellAvgPrice, prevClose, lot,
				multiplier);

		return Pnl.builder().lotSize(lotSize).mtm(mtm).multiplier(multiplier).pnl(pnl).realisedPnl(realisedPnl)
				.unrealisedPnl(unrealisedPnl).build();
	}

	@Override
	public float calculate(final int quantity, final float buyAvgPrice, final float sellAvgPrice, final Integer lotSize,
			final Float multiplier) {
		final int lot = this.validLotSize(lotSize);
		final float mult = this.validMultiplier(multiplier);

		return (quantity * (sellAvgPrice - buyAvgPrice)) * lot * mult;
	}

	@Override
	public float calcNetAvgPriceFromAvgPrice(final Integer cfQty, final Float cfAvgPrice, final Integer dayQty,
			final Float dayAvgPrice) {
		final float cfValue = nonNullInt(cfQty) * nonNullFloat(cfAvgPrice);
		final float dayValue = nonNullInt(dayQty) * nonNullFloat(dayAvgPrice);
		return this.calcNetAvgPriceFromValue(cfQty, cfValue, dayQty, dayValue);
	}

	@Override
	public float calcNetAvgPriceFromValue(final Integer cfQty, final Float cfValue, final Integer dayQty,
			final Float dayValue) {
		final float totalValue = nonNullFloat(cfValue) + nonNullFloat(dayValue);
		final int totalQty = nonNullInt(cfQty) + nonNullInt(dayQty);

		return (totalQty == 0) ? 0 : totalValue / totalQty;
	}

	/**
	 * Realised P&amp;L on the weighted-average cost basis: the matched quantity valued at the
	 * difference of the two average prices. Trade-level data would be needed only for a FIFO
	 * basis, which is not what we report — see trading/docs/pnl-mtm-reference-spec.md §4.2.
	 */
	private float calculateRealisedPnl(final int buyQty, final int sellQty, final float buyAvgPrice,
			final float sellAvgPrice, final Integer lotSize, final Float multiplier) {
		if ((buyQty == 0) || (sellQty == 0)) {
			return 0;
		}

		final int realQty = Math.min(buyQty, sellQty);

		return this.calculate(realQty, buyAvgPrice, sellAvgPrice, lotSize, multiplier);
	}

	/**
	 * MTM per spec §4.4, in the reduced form {@code mtm = pnl + (Cv − Cq×Pc) × lot × M}. For an
	 * intraday position the carried leg is zero, so this reduces to exactly {@code pnl}
	 * (invariant I3, exact — same float arithmetic, not merely close).
	 *
	 * <p>When the adapter did not supply the carried leg, it is derived where that is provably
	 * possible: {@code overnightQuantity == 0} means the leg is exactly zero, and a position with
	 * activity on only one side whose quantity equals the magnitude of {@code overnightQuantity}
	 * (some adapters ship it signed, e.g. negative for a short) is purely carried, so the leg is the
	 * whole position. Otherwise — mixed carried-and-traded with no carried
	 * fields, or a carried position with no usable previous close — {@code mtm} falls back to
	 * {@code pnl} (spec §8): theoretically wrong but bounded, and never a number the size of the
	 * whole position. {@code PositionEnrichment} logs the degradations; the conditions here and
	 * there must stay in sync.
	 */
	private float calculateMtm(final IPlatformPosition pos, final float pnl, final int buyQty, final int sellQty,
			final float buyAvgPrice, final float sellAvgPrice, final Float prevClose, final int lot,
			final float multiplier) {

		Integer carriedQty = pos.getCarriedQuantity();
		Float carriedVal = pos.getCarriedValue();

		if ((carriedQty == null) || (carriedVal == null)) {
			final Integer overnight = pos.getOvernightQuantity();
			if (overnight == null) {
				return pnl;
			}
			if (overnight == 0) {
				carriedQty = 0;
				carriedVal = 0f;
			} else if ((sellQty == 0) && (buyQty == Math.abs(overnight))) {
				carriedQty = buyQty;
				carriedVal = buyQty * buyAvgPrice;
			} else if ((buyQty == 0) && (sellQty == Math.abs(overnight))) {
				carriedQty = -sellQty;
				carriedVal = -(sellQty * sellAvgPrice);
			} else {
				return pnl;
			}
		}

		if ((carriedQty != 0) && ((prevClose == null) || (prevClose <= 0f))) {
			return pnl;
		}

		final float pc = (prevClose == null) ? 0f : prevClose;
		return pnl + ((carriedVal - (carriedQty * pc)) * lot * multiplier);
	}

	/**
	 * Effective average entry price for one leg, reconciling the broker's reported average price
	 * against its reported leg value. Two broker defects seen on carried (T+1) positions motivate
	 * it — measured live on 2026-07-25 across ten brokers holding the identical option:
	 *
	 * <ol>
	 * <li><b>Average missing, value present.</b> The broker ships the carried leg with no
	 * {@code avgPrice} but a correct {@code value} (5Paisa: value 750, avg blank). Left alone the
	 * average defaults to 0, the entire cost basis vanishes and a loss shows as a phantom
	 * full-value <i>profit</i> (a −42 row rendered as +708). Derive {@code value / qty}.</li>
	 * <li><b>Average and value disagree.</b> The broker folds charges into {@code avgPrice} while
	 * {@code value} stays the clean traded cost (Motilal: value 750 ⇒ 25, avg 26.98). Prefer
	 * {@code value / qty}.</li>
	 * </ol>
	 *
	 * <p>When {@code avgPrice} and {@code value} already agree — both clean, or both inflated in
	 * lockstep as the broker's own MTM confirms (Profitmart/IIFL/Zebu) — nothing is changed: the
	 * true cost is not recoverable from the position payload and is left to the broker.
	 *
	 * <p>The disagreement rule (2) applies only when {@code multiplier == 1}. For a non-unit
	 * multiplier we cannot assume the broker's {@code value} excludes it, so a value⇔average
	 * mismatch is ambiguous and the broker's average is kept. Derivation (1) always applies — a
	 * derived price is strictly better than the 0 it replaces.
	 */
	private float effectiveAvgPrice(final float avgPrice, final Float value, final int qty, final float multiplier) {
		if ((qty <= 0) || (value == null)) {
			return avgPrice;
		}
		final float derived = value / qty;
		// (1) average missing/zero but a value is present -> derive it
		if (avgPrice <= 0f) {
			return (derived > 0f) ? derived : avgPrice;
		}
		// (2) average and value disagree -> trust the clean value (unit multiplier only)
		if (multiplier == 1f) {
			final float tolerance = Math.max(1f, Math.abs(value) * 1e-3f);
			if (Math.abs((avgPrice * qty) - value) > tolerance) {
				return derived;
			}
		}
		return avgPrice;
	}

	/**
	 * Only a non-positive multiplier is invalid. A fractional one is legitimate — MCX GOLDM trades
	 * in grams but is quoted per 10 grams, so 0.1 is its real scale. (This guard used to reject
	 * everything below 1, which silently turned that 0.1 into 1 and overstated GOLDM P&amp;L
	 * tenfold.)
	 */
	private float validMultiplier(final Float mult) {
		final float multiplier = ofNullable(mult).orElse(DEFAULT_MULTIPLIER);
		return (multiplier <= 0f) ? DEFAULT_MULTIPLIER : multiplier;
	}

	private int validLotSize(final Integer lotSize) {
		final int lot = ofNullable(lotSize).orElse(DEFAULT_LOT_SIZE);
		return (lot < 1) ? DEFAULT_LOT_SIZE : lot;
	}

}

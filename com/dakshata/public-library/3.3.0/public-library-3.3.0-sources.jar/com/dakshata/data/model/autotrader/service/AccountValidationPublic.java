/**
 *
 */
package com.dakshata.data.model.autotrader.service;

import java.io.Serializable;

import com.dakshata.constants.trading.TradingOpResult;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Result of validating one trading account, as sent to the outside world.<br>
 * This model should not contain any sensitive information.
 * <p>
 * Deliberately a separate class from the internal
 * {@code com.dakshata.trading.model.dto.AccountValidationResponse}: the public client libraries
 * depend only on this library, so the internal one is not reachable from them. The field names
 * match, so the same JSON deserialises into either.
 * <p>
 * {@code sessionState} is a {@link String} rather than the {@code SessionState} enum on purpose.
 * That enum lives in the {@code constants} project, which this library does not depend on, and
 * copying it here would put the same class in two jars for every service that has both. The value
 * is one of {@code MISSING}, {@code LOGGED_IN}, {@code LOGGED_OUT} or {@code ERROR}.
 *
 * @author Pritesh Mhatre
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountValidationPublic implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long tradingAccId, pseudoAccId;

	private boolean valid;

	private TradingOpResult result;

	private String message, tradingAccLoginId, sessionState;

}

/**
 *
 */
package com.dakshata.timeseries.model.tick;

import com.dakshata.constants.instrument.Exchange;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

/**
 * A key for tick.
 *
 * @author PRITESH
 *
 */
@EqualsAndHashCode
@Builder
@Getter
public class TickKey {

	final short source;

	final short type;

	final short exchange;

	final String symbol;

	@JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
	private TickKey(@JsonProperty("source") final short source, @JsonProperty("type") final short type,
			@JsonProperty("exchange") final short exchange, @JsonProperty("symbol") final String symbol) {
		super();
		this.source = source;
		this.type = type;
		this.exchange = exchange;
		this.symbol = symbol.trim().toUpperCase();
	}

	@Override
	public String toString() {
		return String.format("[%s : %s] - [%d : %d]", Exchange.of(exchange), symbol, source, exchange);
	}

}

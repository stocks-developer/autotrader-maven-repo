package com.dakshata.timeseries.model.tick;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

/**
 * Optimized tick serializer.
 *
 * @author PRITESH
 *
 */
public class TickSerializer extends StdSerializer<Tick> {

	private static final long serialVersionUID = 1366041151743191152L;

	public TickSerializer() {
		this(null);
	}

	public TickSerializer(final Class<Tick> t) {
		super(t);
	}

	@Override
	public void serialize(final Tick t, final JsonGenerator jgen, final SerializerProvider provider)
			throws IOException {
		final Object[] key = { t.key.source, t.key.type, t.key.exchange, t.key.symbol };
		Object[] data = null;
		if (t.key.type == 0) {
			data = new Object[] { t.time, t.ltp, t.lowerCircuit, t.upperCircuit,
					t.lastTradedTime, t.receivedAt }; // Mode LTP (appended: lastTradedTime, receivedAt)
		} else {
			data = new Object[] { t.time, t.ltp, t.open, t.high, t.low, t.close, t.change, t.volume, t.atp, t.tbq,
					t.tsq, t.oi, t.ltq, t.lowerCircuit, t.upperCircuit,
					encodeDepth(t.bids), encodeDepth(t.asks),
					t.lastTradedTime, t.receivedAt }; // Mode Full (trailing: bids, asks, lastTradedTime, receivedAt)
		}
		jgen.writeStartObject();
		jgen.writeObjectField("k", key);
		jgen.writeObjectField("d", data);
		jgen.writeEndObject();
	}

	private static Object[] encodeDepth(final List<DepthLevel> levels) {
		if (levels == null) {
			return null;
		}
		final Object[] out = new Object[levels.size()];
		for (int i = 0; i < levels.size(); i++) {
			final DepthLevel l = levels.get(i);
			out[i] = new Object[] { l.price(), l.qty(), l.orders() };
		}
		return out;
	}

}

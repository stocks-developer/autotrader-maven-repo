/**
 *
 */
package com.dakshata.timeseries.model.tick;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

/**
 * Represents a tick.
 *
 * @author PRITESH
 *
 */
@EqualsAndHashCode
@Builder(toBuilder = true)
@ToString
@Getter
@JsonSerialize(using = TickSerializer.class)
@JsonDeserialize(using = TickDeserializer.class)
public class Tick {

	final TickKey key;

	// Exchange-stamped tick timestamp in millis since epoch (populated in Full/Quote mode only).
	final long time;

	// Exchange-reported last-traded time in millis since epoch. Nullable — populated only in Full mode
	// for websocket ticks and always populated for REST-fetched ticks (from Kite quote API).
	final Long lastTradedTime;

	// Wall-clock time (System.currentTimeMillis) when our code produced this Tick.
	// Used for staleness detection in MPP — see marketfeed-api LiveMarketfeedService.subscribeAndFetchFresh.
	final long receivedAt;

	final float ltp;

	final float open, high, low, close;

	final float change;

	final long volume;

	// Avg. traded price
	final float atp;

	// Total buy, sell quantity
	final long tbq, tsq, ltq;
	
	// Open interest
	final long oi;

	// Circuit limits (nullable — populated async after subscription via Kite Quote API)
	final Float lowerCircuit;

	final Float upperCircuit;

	// 5-level market depth (nullable — only present in FULL mode from vendors that expose it, e.g. Kite)
	final List<DepthLevel> bids;

	final List<DepthLevel> asks;

}

package com.dakshata.timeseries.model.tick;

/**
 * One level of market depth (bid or ask).
 *
 * @author PRITESH
 */
public record DepthLevel(float price, int qty, int orders) {
}

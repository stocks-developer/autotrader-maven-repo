package com.dakshata.timeseries.model.tick;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.dakshata.constants.instrument.Exchange;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.node.ArrayNode;

/**
 * Optimized tick deserializer.
 *
 * @author PRITESH
 *
 */
public class TickDeserializer extends StdDeserializer<Tick> {

	private static final long serialVersionUID = -1507445772605598307L;

	public TickDeserializer() {
		this(null);
	}

	public TickDeserializer(final Class<?> vc) {
		super(vc);
	}

	@Override
	public Tick deserialize(final JsonParser jp, final DeserializationContext ctx)
			throws IOException, JsonProcessingException {
		final JsonNode node = jp.getCodec().readTree(jp);

		final ArrayNode k = (ArrayNode) node.get("k");

		final TickKey key = TickKeyFactoryInternal.build(Exchange.of(k.get(2).asInt()), k.get(3).asText(),
				(short) k.get(0).asInt(), (short) k.get(1).asInt());

		final ArrayNode d = (ArrayNode) node.get("d");

		Tick t = null;
		if (key.getType() == 0) {
			t = Tick.builder().key(key).time(d.get(0).asLong()).ltp((float) d.get(1).asDouble())
					.lowerCircuit(d.size() > 2 && !d.get(2).isNull() ? (float) d.get(2).asDouble() : null)
					.upperCircuit(d.size() > 3 && !d.get(3).isNull() ? (float) d.get(3).asDouble() : null)
					.lastTradedTime(d.size() > 4 && !d.get(4).isNull() ? d.get(4).asLong() : null)
					.receivedAt(d.size() > 5 && !d.get(5).isNull() ? d.get(5).asLong() : 0L)
					.build(); // Mode LTP
		} else {
			t = Tick.builder().key(key).time(d.get(0).asLong()).ltp((float) d.get(1).asDouble())
					.open((float) d.get(2).asDouble()).high((float) d.get(3).asDouble())
					.low((float) d.get(4).asDouble()).close((float) d.get(5).asDouble())
					.change((float) d.get(6).asDouble()).volume(d.get(7).asLong()).atp((float) d.get(8).asDouble())
					.tbq(d.get(9).asLong()).tsq(d.get(10).asLong()).oi(d.get(11).asLong()).ltq(d.get(12).asLong())
					.lowerCircuit(d.size() > 13 && !d.get(13).isNull() ? (float) d.get(13).asDouble() : null)
					.upperCircuit(d.size() > 14 && !d.get(14).isNull() ? (float) d.get(14).asDouble() : null)
					.bids(d.size() > 15 ? decodeDepth(d.get(15)) : null)
					.asks(d.size() > 16 ? decodeDepth(d.get(16)) : null)
					.lastTradedTime(d.size() > 17 && !d.get(17).isNull() ? d.get(17).asLong() : null)
					.receivedAt(d.size() > 18 && !d.get(18).isNull() ? d.get(18).asLong() : 0L)
					.build(); // Mode Full
		}

		return t;
	}

	private static List<DepthLevel> decodeDepth(final JsonNode node) {
		if (node == null || node.isNull() || !node.isArray()) {
			return null;
		}
		final ArrayNode arr = (ArrayNode) node;
		final List<DepthLevel> out = new ArrayList<>(arr.size());
		for (int i = 0; i < arr.size(); i++) {
			final ArrayNode lvl = (ArrayNode) arr.get(i);
			out.add(new DepthLevel((float) lvl.get(0).asDouble(), lvl.get(1).asInt(), lvl.get(2).asInt()));
		}
		return out;
	}

}

/**
 *
 */
package com.dakshata.timeseries.model.tick;

import static com.dakshata.tools.string.StringUtil.isEmpty;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import com.dakshata.constants.instrument.Exchange;

/**
 * A factory for tick keys. This factory internally uses a cache of key to avoid
 * creating too many objects.
 *
 * @author PRITESH
 *
 */
public class TickKeyFactoryInternal {

	private static final ConcurrentMap<String, TickKey> cache = new ConcurrentHashMap<>();

	public static final TickKey build(final Exchange ex, final String symbol, final short source, final short type) {
		if ((ex == null) || isEmpty(symbol)) {
			return null;
		}

		final String key = prepareKey(ex, symbol, source, type);
		TickKey tickKey = cache.get(key);
		if (tickKey == null) {
			// Symbol should always be uppercase
			tickKey = TickKey.builder().exchange(ex.getIndex()).source(source).symbol(symbol.toUpperCase()).type(type)
					.build();
			cache.put(key, tickKey);
		}

		return tickKey;
	}

	private static final String prepareKey(final Exchange ex, final String symbol, final short source,
			final short type) {
		// Symbol should always be uppercase
		return String.format("%d%d%d%s", source, type, ex.getIndex(), symbol.toUpperCase());
	}

}

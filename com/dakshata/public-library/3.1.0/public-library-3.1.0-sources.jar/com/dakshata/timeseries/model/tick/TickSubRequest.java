/**
 *
 */
package com.dakshata.timeseries.model.tick;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Tick subscription request.
 *
 * @author PRITESH
 *
 */
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TickSubRequest {

	private String username;

	@Setter
	private Long expiry;

	private TickKey key;

}

package com.dakshata.calc.position;

/**
 * Utility to calculate aggregated position metrics safely from wrapper classes.
 */
public class PositionQtyAndAvgPriceCalculator {

	/**
	 * Data Transfer Object representing the raw input using Object wrappers.
	 */
	public record RawPositionData(
			Integer buyQuantity,
			Float buyPrice,
			Integer sellQuantity,
			Float sellPrice,
			Integer carryForwardBuyQuantity,
			Float carryForwardBuyPrice,
			Integer carryForwardSellQuantity,
			Float carryForwardSellPrice) {
	}

	/**
	 * Data Transfer Object representing the calculated fields.
	 */
	public record CalculatedPosition(
			Integer buyQuantity,
			Float buyAveragePrice,
			Integer sellQuantity,
			Float sellAveragePrice) {
	}

	/**
	 * Calculates the aggregated buy/sell metrics with strict null-safety. * @param
	 * raw Raw data from the broker's API
	 *
	 * @return Aggregated position metrics (defaults to 0 if input is null)
	 */
	public static CalculatedPosition calculate(RawPositionData raw) {
		// 1. Handle completely null payload
		if (raw == null) {
			return new CalculatedPosition(0, 0.0f, 0, 0.0f);
		}

		// 2. Safely unbox all fields to avoid NullPointerExceptions
		final int dayBuyQty = safeUnbox(raw.buyQuantity());
		final float dayBuyPrice = safeUnbox(raw.buyPrice());
		final int daySellQty = safeUnbox(raw.sellQuantity());
		final float daySellPrice = safeUnbox(raw.sellPrice());

		final int cfBuyQty = safeUnbox(raw.carryForwardBuyQuantity());
		final float cfBuyPrice = safeUnbox(raw.carryForwardBuyPrice());
		final int cfSellQty = safeUnbox(raw.carryForwardSellQuantity());
		final float cfSellPrice = safeUnbox(raw.carryForwardSellPrice());

		// 3. Calculate Buy Metrics
		final int totalBuyQty = dayBuyQty + cfBuyQty;
		float buyAvgPrice = 0.0f;

		if (totalBuyQty > 0) {
			// Use double for intermediate calculation to prevent float precision loss
			final double totalBuyValue = ((double) dayBuyQty * dayBuyPrice) + ((double) cfBuyQty * cfBuyPrice);
			buyAvgPrice = (float) (totalBuyValue / totalBuyQty);
		}

		// 4. Calculate Sell Metrics
		final int totalSellQty = daySellQty + cfSellQty;
		float sellAvgPrice = 0.0f;

		if (totalSellQty > 0) {
			final double totalSellValue = ((double) daySellQty * daySellPrice) + ((double) cfSellQty * cfSellPrice);
			sellAvgPrice = (float) (totalSellValue / totalSellQty);
		}

		return new CalculatedPosition(totalBuyQty, buyAvgPrice, totalSellQty, sellAvgPrice);
	}

	// --- Null-Safety Helpers ---

	private static int safeUnbox(Integer value) {
		return value == null ? 0 : value;
	}

	private static float safeUnbox(Float value) {
		return value == null ? 0.0f : value;
	}
}
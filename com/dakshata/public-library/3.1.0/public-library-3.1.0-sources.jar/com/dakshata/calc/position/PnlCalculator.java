/**
 *
 */
package com.dakshata.calc.position;

import static com.dakshata.tools.number.Checks.nonNullFloat;
import static com.dakshata.tools.number.Checks.nonNullInt;
import static java.util.Optional.ofNullable;

import com.dakshata.trading.model.Pnl;
import com.dakshata.trading.model.platform.IPlatformPosition;

/**
 * Pnl calculator.
 *
 * @author PRITESH
 *
 */
public class PnlCalculator implements IPnlCalculator {

	private static final int DEFAULT_MULTIPLIER = 1;

	private static final int DEFAULT_LOT_SIZE = 1;

	@Override
	public Pnl calculate(final IPlatformPosition pos, final float calcPrice) {
		return this.calculate(pos, calcPrice, null);
	}

	@Override
	public Pnl calculate(final IPlatformPosition pos, final float calcPrice, final Integer lotSize) {

		final int buyQty = ofNullable(pos.getBuyQuantity()).orElse(0);
		final int sellQty = ofNullable(pos.getSellQuantity()).orElse(0);
		final float buyAvgPrice = ofNullable(pos.getBuyAvgPrice()).orElse(0f);
		final float sellAvgPrice = ofNullable(pos.getSellAvgPrice()).orElse(0f);
		final int multiplier = this.validMultiplier(pos.getMultiplier());
		final int lot = this.validLotSize(lotSize);

		final float realisedPnl = this.calculateRealisedPnl(buyQty, sellQty, buyAvgPrice, sellAvgPrice, lot,
				multiplier);
		final float unrealisedPnl = this.calculateUnrealisedPnl(buyQty, sellQty, buyAvgPrice, sellAvgPrice, lot,
				multiplier, calcPrice);

		final int finalBuyQty = buyQty * lot * multiplier;
		final int finalSellQty = sellQty * lot * multiplier;

		final float sellValue = sellAvgPrice * finalSellQty;
		final float buyValue = buyAvgPrice * finalBuyQty;

		// Remaining means open quantity on the other side
		// Example: A long position with 10 qty will have remaining sell qty = 10
		final int remainSellQty = Math.max(0, finalBuyQty - finalSellQty);
		final int remainBuyQty = Math.max(0, finalSellQty - finalBuyQty);

		final float remainSellVal = remainSellQty * calcPrice;
		final float remainBuyVal = remainBuyQty * calcPrice;

		final float totalSellVal = sellValue + remainSellVal;
		final float totalBuyVal = buyValue + remainBuyVal;

		final float pnl = (totalSellVal - totalBuyVal);

		return Pnl.builder().lotSize(lotSize).mtm(pnl).multiplier(multiplier).pnl(pnl).realisedPnl(realisedPnl)
				.unrealisedPnl(unrealisedPnl).build();
	}

	@Override
	public float calculate(final int quantity, final float buyAvgPrice, final float sellAvgPrice, final Integer lotSize,
			final Integer multiplier) {
		final int lot = this.validLotSize(lotSize);
		final int mult = this.validMultiplier(multiplier);

		return (quantity * (sellAvgPrice - buyAvgPrice)) * lot * mult;
	}

	@Override
	public float calcNetAvgPriceFromAvgPrice(final Integer cfQty, final Float cfAvgPrice, final Integer dayQty,
			final Float dayAvgPrice) {
		final float cfValue = nonNullInt(cfQty) * nonNullFloat(cfAvgPrice);
		final float dayValue = nonNullInt(dayQty) * nonNullFloat(dayAvgPrice);
		return this.calcNetAvgPriceFromValue(cfQty, cfValue, dayQty, dayValue);
	}

	@Override
	public float calcNetAvgPriceFromValue(final Integer cfQty, final Float cfValue, final Integer dayQty,
			final Float dayValue) {
		final float totalValue = nonNullFloat(cfValue) + nonNullFloat(dayValue);
		final int totalQty = nonNullInt(cfQty) + nonNullInt(dayQty);

		return (totalQty == 0) ? 0 : totalValue / totalQty;
	}

	private float calculateRealisedPnl(final int buyQty, final int sellQty, final float buyAvgPrice,
			final float sellAvgPrice, final Integer lotSize, final Integer multiplier) {
		if ((buyQty == 0) || (sellQty == 0)) {
			return 0;
		}

		if (buyQty != sellQty) {
			// With the inputs taken it is not possible to calculate realised pnl
			// We need the trades data to correctly calculate realized pnl
			// Hence for now, we return it to be zero
			return 0;
		}

		final int realQty = Math.min(buyQty, sellQty);

		return this.calculate(realQty, buyAvgPrice, sellAvgPrice, lotSize, multiplier);
	}

	private float calculateUnrealisedPnl(final int buyQty, final int sellQty, final float buyAvgPrice,
			final float sellAvgPrice, final Integer lotSize, final Integer multiplier, final float calcPrice) {
		// With the inputs taken it is not possible to calculate realised pnl
		// We need the trades data to correctly calculate realized pnl
		// Hence for now, we return it to be zero
		return 0;
	}

	private int validMultiplier(final Integer mult) {
		final int multiplier = ofNullable(mult).orElse(DEFAULT_MULTIPLIER);
		return (multiplier < 1) ? DEFAULT_MULTIPLIER : multiplier;
	}

	private int validLotSize(final Integer lotSize) {
		final int lot = ofNullable(lotSize).orElse(DEFAULT_MULTIPLIER);
		return (lot < 1) ? DEFAULT_LOT_SIZE : lot;
	}

}

package com.dakshata.tools.trading;

import static com.dakshata.tools.string.StringUtil.isEmpty;
import static java.util.stream.Collectors.toSet;

import java.util.Set;

import com.dakshata.trading.model.platform.IPlatformOrder;
import com.dakshata.trading.model.platform.IPlatformPosition;

public class PositionOpenChildrenFilter {

	public boolean hasOpenChildren(final IPlatformPosition p, final Set<IPlatformOrder> orders) {
		return orders.stream().filter(o -> this.isOpenChild(p, o)).findAny().isPresent();
	}

	public Set<IPlatformOrder> getOpenChildren(final IPlatformPosition p, final Set<IPlatformOrder> orders) {
		return orders.stream().filter(o -> this.isOpenChild(p, o)).collect(toSet());
	}

	private boolean isOpenChild(final IPlatformPosition p, final IPlatformOrder o) {
		if (isEmpty(o.getParentOrderId())) {
			return false;
		} else if (!o.isOpenOrTriggerPending()) {
			return false;
		} else if (!p.getType().matches(o.getVariety())) {
			return false;
		} else if (p.getInstrument() != null) {
			return p.getInstrument().equals(o.getInstrument());
		} else {
			final String exchange = p.getIndependentExchange();
			final String symbol = p.getIndependentSymbol();

			if ((exchange != null) && (symbol != null)) {
				return exchange.equals(o.getIndependentExchange()) && symbol.equals(o.getIndependentSymbol());
			}
		}

		return false;
	}

}

/**
 *
 */
package com.dakshata.tools.common;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;

import lombok.extern.slf4j.Slf4j;

/**
 * Generic event handler.
 *
 * @author PRITESH
 *
 */
@Slf4j
public abstract class EventHandler<E> {

	protected final BlockingQueue<E> queue;

	protected final ExecutorService pool;

	protected final Thread runner;

	public EventHandler(final String name, final BlockingQueue<E> queue, final ExecutorService pool,
			final boolean daemon) {
		super();
		this.queue = queue;
		this.pool = pool;
		this.runner = new Thread(this::startEventHandling, name);
		this.runner.setDaemon(daemon);
	}

	public EventHandler(final String name, final BlockingQueue<E> queue, final ExecutorService pool) {
		this(name, queue, pool, true);
	}

	public void begin() {
		log.debug("Starting event handler: {}", this.runner.getName());
		this.runner.start();
	}

	public boolean accept(final E event) {
		final boolean result = this.queue.offer(event);
		if (!result) {
			log.error("Queue is full, please investigate: {}", this.getClass().getSimpleName());
		}
		return result;
	}

	private void startEventHandling() {
		log.debug("{} is starting event handling loop.", this.runner.getName());
		while (true) {
			try {
				this.handleEvent(this.queue.take());
			} catch (final InterruptedException e) {
				log.error("{} is interrupted and terminated.", this.runner.getName());
				break;
			}
		}

		this.cleanup();
	}

	protected void cleanup() {
		if (this.pool != null) {
			this.pool.shutdownNow();
		}
	}

	protected abstract void handleEvent(E event);

}

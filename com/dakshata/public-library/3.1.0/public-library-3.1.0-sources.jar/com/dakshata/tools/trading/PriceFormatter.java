package com.dakshata.tools.trading;

import java.math.BigDecimal;
import java.math.RoundingMode;

import com.dakshata.constants.instrument.Segment;

public final class PriceFormatter {

	private static final float DELTA_FLOAT = 0.000001f;

	private static final double DELTA_DOUBLE = 0.000000001;

	private static final int DEFAULT_DECIMAL_PLACES = 4;

	private PriceFormatter() {
	}

	/**
	 * Removes trailing zeros from a float price. Use String.valueOf() to avoid
	 * floating point expansion noise.
	 */
	public static String removeTrailingDecimalZeros(final float price) {
		// Fix: Use String constructor. BigDecimal.valueOf(float) promotes to double,
		// turning 100.55f into 100.55000305... which ruins formatting.
		return new BigDecimal(String.valueOf(price)).stripTrailingZeros().toPlainString();
	}

	/**
	 * Parses a string to float safely. Returns 0f on failure or NaN.
	 */
	public static float parse(final String value) {
		if ((value == null) || value.isBlank()) {
			return 0f;
		}
		try {
			final float f = Float.parseFloat(value);
			// Fix: Explicitly handle NaN and Infinite values as 0.0f
			if (Float.isNaN(f) || Float.isInfinite(f)) {
				return 0f;
			}
			return f;
		} catch (final NumberFormatException e) {
			return 0f;
		}
	}

	public static Float roundTick(final Float price, final Float tickSize) {
		if (price == null) {
			return null;
		}
		if ((tickSize == null) || Float.isNaN(tickSize) || (tickSize <= DELTA_FLOAT)) {
			return price;
		}

		// Fix: Use String.valueOf() to avoid float->double widening noise.
		// BigDecimal.valueOf(float) promotes to double, turning 99.95f into
		// 99.9500045776367... which causes rounding to return 99.950005 instead of
		// 99.95.
		final BigDecimal p = new BigDecimal(String.valueOf(price));
		final BigDecimal t = new BigDecimal(String.valueOf(tickSize));

		final BigDecimal rounded = p.divide(t, 0, RoundingMode.HALF_UP).multiply(t);

		return rounded.floatValue();
	}

	/**
	 * High-precision support for Double-based systems. Handles NULL inputs safely
	 * to prevent NPEs.
	 */
	public static double roundTick(final Double price, final Double tickSize) {
		// 1. Safety Check: Price
		// If price is null, NaN, or Infinite -> Return 0.0 (Invalid Price)
		if ((price == null) || Double.isNaN(price) || Double.isInfinite(price)) {
			return 0.0;
		}

		// 2. Safety Check: Tick Size
		if ((tickSize == null) || Double.isNaN(tickSize) || (tickSize <= DELTA_DOUBLE)) {
			return price;
		}

		final BigDecimal p = BigDecimal.valueOf(price);
		final BigDecimal t = BigDecimal.valueOf(tickSize);

		final BigDecimal rounded = p.divide(t, 0, RoundingMode.HALF_UP).multiply(t);

		return rounded.doubleValue();
	}

	/**
	 * Sanitizes the price to the default 4 decimal places. It will ONLY modify and
	 * return a new Float if the original price goes beyond 4 decimal places.
	 */
	public static Float sanitizePrice(final Float price) {
		return sanitizePrice(price, DEFAULT_DECIMAL_PLACES);
	}

	/**
	 * Sanitizes the price to the specified maximum decimal places. It will ONLY
	 * modify and return a new Float if the original price goes beyond the specified
	 * decimal places.<br>
	 * Note: This method was to fix certain prices like "12.400001" in master
	 * orderbook which cause errors when placed in child.
	 */
	public static Float sanitizePrice(final Float price, final int maxDecimalPlaces) {
		// 1. Guard against null, NaN (Not a Number), and Infinity
		if ((price == null) || price.isNaN() || price.isInfinite()) {
			return price;
			// Note: If you prefer to fail-fast and stop the order immediately,
			// you could replace the return statement above with:
			// throw new IllegalArgumentException("Invalid price value: " + price);
		}

		// 2. Convert to String to prevent binary floating-point drift
		final BigDecimal bdPrice = new BigDecimal(price.toString());

		// 3. safely ignore trailing zeros and check scale
		if (bdPrice.stripTrailingZeros().scale() > maxDecimalPlaces) {

			// 4. Round to exactly the requested decimal places.
			return bdPrice.setScale(maxDecimalPlaces, RoundingMode.HALF_UP).floatValue();
		}

		// 5. If it has acceptable decimal places, return the exact original object.
		return price;
	}

	/**
	 * Converts a Float price to a BigDecimal, automatically applying the correct
	 * decimal scale based on the exchange segment.
	 */
	public static BigDecimal convertAndAdjustPrice(Float price, Segment segment) {
		if (price == null) {
			return null;
		}

		// Default to 2 decimal places for Equity and Commodity
		int scale = 2;

		if (segment != null) {
			switch (segment) {
			case CURRENCY:
				scale = 4; // CDS requires 4 decimal places
				break;
			case EQUITY:
			case COMMODITY:
			default:
				scale = 2;
				break;
			}
		}

		// Bridge via String to drop memory garbage, then apply the segment-specific
		// scale
		return new BigDecimal(price.toString()).setScale(scale, RoundingMode.HALF_UP);
	}

}
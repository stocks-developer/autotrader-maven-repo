package com.dakshata.tools.trading;

import com.dakshata.constants.trading.PositionDirection;
import com.dakshata.trading.model.platform.IPlatformPosition;

/**
 * Calculates position direction.
 *
 * @author PRITESH
 *
 */
public interface IPositionDirectionCalculator {

	PositionDirection calculate(IPlatformPosition position);

}

package com.dakshata.tools.trading;

import static com.dakshata.constants.trading.PositionDirection.LONG;
import static com.dakshata.constants.trading.PositionDirection.NEUTRAL;
import static com.dakshata.constants.trading.PositionDirection.SHORT;

import com.dakshata.constants.trading.PositionDirection;
import com.dakshata.trading.model.platform.IPlatformPosition;

/**
 * Calculates position direction.
 *
 * @author PRITESH
 *
 */
public class PositionDirectionCalculator implements IPositionDirectionCalculator {

	@Override
	public PositionDirection calculate(final IPlatformPosition position) {
		final Integer net = position.getNetQuantity();
		if (net != null) {
			if (net > 0) {
				return LONG;
			} else if (net < 0) {
				return SHORT;
			}
		}

		return NEUTRAL;
	}

}

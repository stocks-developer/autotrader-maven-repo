package com.dakshata.tools.string;

import static com.dakshata.constants.IGeneral.BLANK;
import static com.dakshata.constants.IGeneral.COMMA;
import static com.dakshata.constants.IGeneral.SEMI_COLON;
import static java.util.UUID.randomUUID;
import static java.util.stream.Collectors.toList;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpCookie;
import java.nio.charset.Charset;
import java.util.Base64;
import java.util.Collection;
import java.util.Random;
import java.util.UUID;

public final class StringUtil {

	private static final Charset LATIN_1 = Charset.forName("Cp1252");

	public static String[] splitBySpace(final String data) {
		if (isEmpty(data)) {
			return new String[] {};
		}

		return data.split("\\s+");
	}

	public static String[] splitLines(final String data) {
		if (isEmpty(data)) {
			return new String[] {};
		}

		return data.split("\\r?\\n|\\r");
	}

	public static String uuidPlain() {
		final UUID id = randomUUID();
		return id.toString().replace("-", BLANK);
	}

	public static boolean isEmpty(final String s) {
		return (s == null) || s.trim().isEmpty();
	}

	public static String truncate(final String input, final int length) {
		if ((input == null) || (input.length() <= length)) {
			return input;
		}

		return input.substring(0, length);
	}

	public static String replaceComma(final String input) {
		if (isEmpty(input)) {
			return null;
		}

		return input.replace(COMMA, SEMI_COLON);
	}

	public static String stackTrace(final Throwable t) {
		final StringWriter sw = new StringWriter();
		final PrintWriter pw = new PrintWriter(sw);
		t.printStackTrace(pw);
		final String stackTrace = sw.toString();
		return stackTrace;
	}

	public static String cookie(final Collection<HttpCookie> cookies) {
		return String.join(SEMI_COLON, cookies.stream().map(HttpCookie::toString).collect(toList()));
	}

	public static boolean containsWhitespace(final String str) {
		if ((str == null) || str.isEmpty()) {
			return false;
		}
		final int strLen = str.length();
		for (int i = 0; i < strLen; i++) {
			if (Character.isWhitespace(str.charAt(i))) {
				return true;
			}
		}
		return false;
	}

	public static String encodeBase64(final String decoded) {
		return (decoded == null) ? null : Base64.getEncoder().encodeToString(decoded.getBytes());
	}

	public static String decodeBase64(final String encoded) {
		return (encoded == null) ? null : new String(Base64.getDecoder().decode(encoded));
	}

	/**
	 * Generates a random string from the characters given.
	 *
	 * @param pool   characters to use in the random string
	 * @param length expected length
	 * @return random string
	 */
	public static String generateRandom(final char[] pool, final int length) {
		final Random r = new Random();
		final char[] result = new char[length];
		for (int i = 0; i < length; ++i) {
			result[i] = pool[r.nextInt(pool.length)];
		}
		return new String(result);
	}

	public static String trim(final String str) {
		return str == null ? null : str.trim();
	}

	public static String upper(final String src) {
		return (src != null) ? src.toUpperCase() : src;
	}

	public static String lower(final String src) {
		return (src != null) ? src.toLowerCase() : src;
	}

	public static String removeEQ(final String symbol) {
		if (isEmpty(symbol)) {
			return symbol;
		}

		final String s = symbol.trim();
		return s.endsWith("-EQ") ? s.substring(0, s.length() - 3) : symbol;
	}

	public static String removeSurrogateChars(final String text) {
		final StringBuilder sb = new StringBuilder();
		for (int i = 0; i < text.length(); i++) {
			final char ch = text.charAt(i);
			if (!Character.isHighSurrogate(ch) && !Character.isLowSurrogate(ch)) {
				sb.append(ch);
			}
		}
		return sb.toString();
	}

	/**
	 * Converts charset.<br>
	 *
	 * MariaDB has a default encoding of latin1 (which is equivalent to Cp1252).
	 */
	public static String convertCharsetToLatin1(final String text) {
		if (isEmpty(text)) {
			return text;
		}

		return new String(text.getBytes(), LATIN_1);
	}

	public static String extractHtmlTitle(final String html) {
		if (html == null) {
			return null;
		}

		if (!html.contains("<html") && !html.contains("<HTML")) {
			return null;
		}

		int begin = html.indexOf("<title");
		begin = (begin < 0) ? html.indexOf("<TITLE") : begin;
		begin = html.indexOf('>', begin);
		int end = html.indexOf("</title");
		end = (end < 0) ? html.indexOf("</TITLE") : end;

		if ((begin < 0) || (end < 0)) {
			return null;
		}

		return html.substring(begin + 1, end);
	}

	public static String nullSafeToString(Object o, String defaultVal) {
		return (o == null) ? defaultVal : o.toString();
	}

	public static String nullSafeToString(Object o) {
		return nullSafeToString(o, null);
	}

	public static String nonEmpty(String x) {
		return ((x == null) || x.isBlank()) ? null : x.trim();
	}

}

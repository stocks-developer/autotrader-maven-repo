/**
 *
 */
package com.dakshata.tools.jpa;

import java.io.InputStream;
import java.util.Properties;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import org.jasypt.util.text.BasicTextEncryptor;

/**
 * Responsible for storing data in an encrypted form.
 *
 * @author PRITESH
 *
 */
@Converter
public class EncryptionConverter implements AttributeConverter<String, String> {

	private static final BasicTextEncryptor ENCRYPTOR;

	static {
		ENCRYPTOR = new BasicTextEncryptor();
		final String pwd = loadPassword();
		ENCRYPTOR.setPassword(pwd);
	}

	@Override
	public String convertToDatabaseColumn(final String attribute) {
		return this.encrypt(attribute);
	}

	@Override
	public String convertToEntityAttribute(final String dbData) {
		return this.decrypt(dbData);
	}

	private String encrypt(final String data) {
		if ((data == null) || data.trim().isEmpty()) {
			return data;
		}

		return ENCRYPTOR.encrypt(data.trim());
	}

	private String decrypt(final String data) {
		if ((data == null) || data.trim().isEmpty()) {
			return data;
		}

		return ENCRYPTOR.decrypt(data);
	}

	public static final String loadPassword() {
		try {
			final Properties configuration = new Properties();
			final InputStream inputStream = EncryptionConverter.class.getClassLoader()
					.getResourceAsStream("application.properties");
			configuration.load(inputStream);
			inputStream.close();

			return configuration.get("encryptor.password").toString();
		} catch (final Exception e) {
			return "not-needed";
		}
	}

}

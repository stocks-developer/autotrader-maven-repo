package com.dakshata.tools.date;

import static com.dakshata.tools.string.StringUtil.isEmpty;
import static java.time.format.DateTimeFormatter.ISO_TIME;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

public final class DateFormatter {

	public static String formatTimeISO(final Timestamp time) {
		return (time == null) ? "null" : formatTimeISO(time.toLocalDateTime().toLocalTime());
	}

	public static String formatTimeISO(final LocalTime time) {
		return (time == null) ? "null" : time.format(ISO_TIME);
	}

	public static String format(final Date date, final String pattern) {
		final SimpleDateFormat formatter = new SimpleDateFormat(pattern);
		return formatter.format(date);
	}

	public static Date parse(final String source, final String pattern) throws ParseException {
		final SimpleDateFormat formatter = new SimpleDateFormat(pattern);
		return formatter.parse(source);
	}

	public static Timestamp parseTimestamp(final String text, final DateTimeFormatter formatter) {
		if (isEmpty(text)) {
			return null;
		}

		try {
			return Timestamp.valueOf(LocalDateTime.parse(text, formatter));
		} catch (final DateTimeParseException e) {
			// Do nothing
		}

		return null;
	}

}

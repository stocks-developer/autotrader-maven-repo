package com.dakshata.tools.trading;

import static com.dakshata.constants.trading.PositionState.CLOSED;
import static com.dakshata.constants.trading.PositionState.OPEN;

import java.util.Set;

import com.dakshata.constants.trading.PositionState;
import com.dakshata.constants.trading.PositionType;
import com.dakshata.trading.model.platform.IPlatformOrder;
import com.dakshata.trading.model.platform.IPlatformPosition;
import com.dakshata.trading.model.portfolio.Portfolio;

/**
 * Calculates the state of the position (<code>OPEN</code> or
 * <code>CLOSED</code>).
 *
 * @author PRITESH
 *
 */
public class PositionStateCalculator implements IPositionStateCalculator {

	private final PositionOpenChildrenFilter openChildrenFilter = new PositionOpenChildrenFilter();

	@Override
	public PositionState calculate(final IPlatformPosition position, final Portfolio portfolio) {
		// If position type is null, we default to MIS
		final PositionType type = position.getType() == null ? PositionType.MIS : position.getType();
		switch (type) {
		case MIS:
		case NRML:
		case CNC:
		case MTF:
			return (position.getNetQuantity() == 0) ? CLOSED : OPEN;
		case BO:
		case CO:
			return this.calculateComplex(position, portfolio);
		default:
			throw new RuntimeException("Invalid position type: " + position.getType());
		}
	}

	private PositionState calculateComplex(final IPlatformPosition p, final Portfolio portfolio) {
		if (portfolio == null) {
			return CLOSED;
		}

		final Set<IPlatformOrder> orders = portfolio.getOrders();
		if ((orders == null) || orders.isEmpty()) {
			return CLOSED;
		}

		final boolean openChildren = this.openChildrenFilter.hasOpenChildren(p, orders);

		return openChildren ? OPEN : CLOSED;
	}

}

/**
 *
 */
package com.dakshata.tools.common;

import java.util.EnumSet;

/**
 * Utility methods for enums.
 *
 * @author PRITESH
 *
 */
public final class EnumUtil {

	private static final String INVALID_ENUM_MSG = "Invalid %s: [%s]. Valid values are: %s";

	private EnumUtil() {
	}

	/**
	 * Parses enum without throwing an exception. Assumes that enum constants are
	 * defined in uppercase.
	 *
	 * @param <T>   Type of enum
	 * @param clazz type of enum
	 * @param value enum text
	 * @return Enum or null
	 */
	public static final <E extends Enum<E>> E parse(final Class<E> clazz, final String value) {
		try {
			return value == null ? null : Enum.valueOf(clazz, value.toUpperCase());
		} catch (final Exception e) {
			return null;
		}
	}

	/**
	 * Parses enum and thorws a user friendly exception. Assumes that enum constants
	 * are defined in uppercase.
	 *
	 * @param <T>   Type of enum
	 * @param clazz type of enum
	 * @param value enum text
	 * @return Enum or null
	 */
	public static final <E extends Enum<E>> E parseStrict(final Class<E> clazz, final String value) throws Exception {
		final E result = parse(clazz, value);
		if (result == null) {
			throw new Exception(invalidEnumErrorMsg(clazz, value));
		}

		return result;
	}

	public static final <E extends Enum<E>> String invalidEnumErrorMsg(final Class<E> c, final String value) {
		return String.format(INVALID_ENUM_MSG, c.getSimpleName(), value, EnumSet.allOf(c));
	}

}

/**
 * All utilities related to numbers.
 * 
 * @author PRITESH
 *
 */
package com.dakshata.tools.number;
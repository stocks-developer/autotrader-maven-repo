/**
 *
 */
package com.dakshata.tools.cache;

import static com.dakshata.tools.number.Parser.parseBoolean;
import static com.dakshata.tools.number.Parser.parseFloat;
import static com.dakshata.tools.number.Parser.parseInteger;
import static com.dakshata.tools.number.Parser.parseLong;

import java.util.Map;

/**
 * Helper methods for maps containing properties.
 *
 * @author PRITESH
 *
 */
public final class PropertiesMapHelper {

	public static final String get(final Map<String, String> map, final String key) {
		return (map == null) ? null : map.get(key);
	}

	public static final String get(final Map<String, String> map, final String key, final String defaultVal) {
		final String result = get(map, key);
		return result == null ? defaultVal : result;
	}

	public static final Integer getInteger(final Map<String, String> map, final String key) {
		return parseInteger(get(map, key));
	}

	public static final Integer getInteger(final Map<String, String> map, final String key, final Integer defaultVal) {
		final Integer result = getInteger(map, key);
		return result == null ? defaultVal : result;
	}

	public static final Float getFloat(final Map<String, String> map, final String key) {
		return parseFloat(get(map, key));
	}

	public static final Float getFloat(final Map<String, String> map, final String key, final Float defaultVal) {
		final Float result = getFloat(map, key);
		return result == null ? defaultVal : result;
	}

	public static final Long getLong(final Map<String, String> map, final String key) {
		return parseLong(get(map, key));
	}

	public static final Long getLong(final Map<String, String> map, final String key, final Long defaultVal) {
		final Long result = getLong(map, key);
		return result == null ? defaultVal : result;
	}

	public static final Boolean getBoolean(final Map<String, String> map, final String key) {
		return parseBoolean(get(map, key));
	}

	public static final Boolean getBoolean(final Map<String, String> map, final String key, final Boolean defaultVal) {
		final Boolean result = getBoolean(map, key);
		return result == null ? defaultVal : result;
	}

	public static final String getMandatory(final Map<String, String> map, final String key) throws Exception {
		final String value = get(map, key);
		if (value == null) {
			final String message = "Mandatory property is null: " + key;
			throw new Exception(message);
		}
		return value;
	}

	public static final Integer getIntegerMandatory(final Map<String, String> map, final String key) throws Exception {
		return parseInteger(getMandatory(map, key));
	}

	public static final Float getFloatMandatory(final Map<String, String> map, final String key) throws Exception {
		return parseFloat(getMandatory(map, key));
	}

	public static final Long getLongMandatory(final Map<String, String> map, final String key) throws Exception {
		return parseLong(getMandatory(map, key));
	}

	public static final Boolean getBooleanMandatory(final Map<String, String> map, final String key) throws Exception {
		return parseBoolean(getMandatory(map, key));
	}

}

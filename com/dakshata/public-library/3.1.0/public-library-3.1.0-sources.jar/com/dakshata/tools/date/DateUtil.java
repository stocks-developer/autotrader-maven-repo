/**
 *
 */
package com.dakshata.tools.date;

import static java.time.LocalDate.now;
import static java.time.LocalTime.MAX;
import static java.time.ZoneId.systemDefault;
import static java.time.temporal.ChronoUnit.DAYS;

import java.sql.Timestamp;
import java.time.*;
import java.time.temporal.TemporalAccessor;
import java.util.Date;
import java.util.EnumSet;
import java.util.Set;

/**
 * Date utility methods.
 *
 * @author PRITESH
 *
 */
public final class DateUtil {

	private static final Set<DayOfWeek> WEEKEND = EnumSet.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY);

	private DateUtil() {
	}

	public static Timestamp[] dayRange(final LocalDate day) {
		final Timestamp start = Timestamp.valueOf(day.atStartOfDay());
		final Timestamp end = Timestamp.valueOf(LocalDateTime.of(day, MAX));
		return new Timestamp[] { start, end };
	}

	public static boolean isWeekend(final LocalDate day) {
		return WEEKEND.contains(day.getDayOfWeek());
	}

	public static boolean isWeekend() {
		return isWeekend(now());
	}

	/**
	 * Calculates current working day. If it is a weekend then last friday is
	 * returned. Otherwise passed date is returned.
	 *
	 * @param onOrBefore on or before day
	 * @return current day
	 */
	public static LocalDate currentWorkingDay(final LocalDate onOrBefore) {
		if (!isWeekend(onOrBefore)) {
			return onOrBefore;
		}

		final LocalDate yesterday = onOrBefore.minusDays(1);
		if (!isWeekend(yesterday)) {
			return yesterday;
		}

		return yesterday.minusDays(1);
	}

	public static LocalDate currentWorkingDay() {
		return currentWorkingDay(LocalDate.now());
	}

	public static LocalDate toLocalDate(final Date from) {
		Date op = from;
		if (from instanceof java.sql.Date) {
			// Sql Date does not support toInstant() method
			op = new Date(from.getTime());
		}

		return op.toInstant().atZone(systemDefault()).toLocalDate();
	}

	public static Date toDate(final LocalDate from) {
		return Date.from(from.atStartOfDay(systemDefault()).toInstant());
	}

	public static long daysBetween(final Date from, final Date to) {
		return DAYS.between(toLocalDate(from), toLocalDate(to));
	}

	public static boolean isSameMonth(final TemporalAccessor a, final TemporalAccessor b) {
		if ((a == null) || (b == null)) {
			return false;
		}

		return YearMonth.from(a).equals(YearMonth.from(b));
	}

	public static boolean isPreviousMonth(final TemporalAccessor current, final TemporalAccessor previous) {
		if ((current == null) || (previous == null)) {
			return false;
		}

		return YearMonth.from(current).plusMonths(-1).equals(YearMonth.from(previous));
	}

	/**
	 * Provides sql date that only contains day part (not time).
	 */
	public static java.sql.Date sqlDateWithoutTime(final long millis) {
		return java.sql.Date.valueOf(Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate());
	}

	public static Integer licenseDaysLeft(java.sql.Date expiry) {
		final LocalDate ex = expiry.toLocalDate();
		final int days = (int) LocalDate.now().until(ex, DAYS);
		return Math.max(0, days + 1);
	}

	/**
	 * Moves the given date by a specified number of business days.
	 * <p>
	 * A positive number moves forward; a negative number moves backward. Saturdays
	 * and Sundays are skipped and not counted as business days.
	 * </p>
	 *
	 * @param startDate the starting {@link LocalDate}
	 * @param days      the number of business days to move; positive to move
	 *                  forward, negative to move backward
	 * @return the resulting {@link LocalDate} after moving the specified business
	 *         days
	 */
	public static LocalDate moveBusinessDays(LocalDate startDate, int days) {
		LocalDate result = startDate;
		int movedDays = 0;
		final int step = days > 0 ? 1 : -1;

		while (movedDays != days) {
			result = result.plusDays(step);
			if (!((result.getDayOfWeek() == DayOfWeek.SATURDAY) || (result.getDayOfWeek() == DayOfWeek.SUNDAY))) {
				movedDays += step;
			}
		}

		return result;
	}

}

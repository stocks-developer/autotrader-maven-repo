/**
 *
 */
package com.dakshata.tools.error;

import java.util.concurrent.atomic.AtomicInteger;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * Provides utility methods for Exceptions.
 *
 * @author PRITESH
 *
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ExceptionUtil {

	/**
	 * This method checks if the given error (Exception) is because of the given
	 * cause (Exception).
	 *
	 * @param error     error
	 * @param candidate exception class to check
	 * @return true, if the error was due to the given candidate exception
	 */
	public static final boolean isCause(final Throwable error, final Class<? extends Throwable> candidate) {
		return isCause(new AtomicInteger(1), error, candidate);
	}

	private static final boolean isCause(final AtomicInteger counter, final Throwable error,
			final Class<? extends Throwable> candidate) {
		if ((error == null) || (candidate == null)) {
			return false;
		}

		if (counter.getAndIncrement() > 10) {
			return false;
		}

		if (candidate.isInstance(error)) {
			return true;
		}

		return isCause(counter, error.getCause(), candidate);
	}

}

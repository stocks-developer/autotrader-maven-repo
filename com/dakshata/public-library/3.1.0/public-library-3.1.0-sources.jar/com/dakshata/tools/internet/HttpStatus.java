/**
 *
 */
package com.dakshata.tools.internet;

import static com.dakshata.tools.string.StringUtil.isEmpty;
import static org.apache.http.impl.EnglishReasonPhraseCatalog.INSTANCE;

import java.util.HashMap;
import java.util.Map;

/**
 * HTTP Status codes utilities.
 *
 * @author PRITESH
 *
 */
public final class HttpStatus {

	private static final Map<Integer, String> REASONS = new HashMap<>();

	static {
		REASONS.put(429,
				"Too Many Requests. Your application has sent too many requests in a very short span of time.");
	}

	private HttpStatus() {
		super();
	}

	public static final String toText(final int status) {
		return INSTANCE.getReason(status, null);
	}

	public static final String toTextDefault(final int status, final String text) {
		return isEmpty(text) ? isEmpty(toText(status)) ? REASONS.get(status) : toText(status) : text;
	}

}

/**
 *
 */
package com.dakshata.tools.trading;

import static com.dakshata.constants.IGeneral.PIPE;

import com.dakshata.trading.model.trade.StockBroker;

/**
 * Responsible for building model keys.
 *
 * @author PRITESH
 *
 */
public final class KeyBuilder {

	private KeyBuilder() {
	}

	/**
	 * This key is saved in the database in ModelActivity & Ledger tables. So do not
	 * modify it's format otherwise existing records will not follow new format.
	 */
	public static final String makeTradingAccKey(final StockBroker broker, final String loginId) {
		final String b = (broker == null) ? null : broker.getId();
		final String l = (loginId == null) ? null : loginId.toUpperCase();
		return b + PIPE + l;
	}

}

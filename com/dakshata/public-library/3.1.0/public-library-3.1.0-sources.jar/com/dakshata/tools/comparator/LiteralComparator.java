package com.dakshata.tools.comparator;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.collections4.comparators.ComparableComparator;
import org.apache.commons.collections4.comparators.ComparatorChain;
import org.apache.commons.collections4.comparators.FixedOrderComparator;
import org.apache.commons.collections4.comparators.NullComparator;

/**
 * This {@link java.util.Comparator} takes an array of literals that define an
 * order. Anything not included in the array is placed after anything in the
 * array and is then sorted according to its natural order.
 *
 * @param <T> The type to be sorted
 *
 */
public class LiteralComparator<T extends Comparable<T>> implements Comparator<T>, Serializable {

	private static final long serialVersionUID = 1L;

	private final Comparator<T> c;

	/**
	 * Constructor.
	 *
	 * @param predefinedOrder Objects that define the order of comparison
	 */
	public LiteralComparator(final T[] predefinedOrder) {
		final List<T> predefinedList = predefinedOrder == null ? Collections.<T>emptyList()
				: Arrays.<T>asList(predefinedOrder);
		final FixedOrderComparator<T> fixedComparator = new FixedOrderComparator<>(predefinedList);
		fixedComparator.setUnknownObjectBehavior(FixedOrderComparator.UnknownObjectBehavior.AFTER);
		this.c = new ComparatorChain<>(Arrays.<Comparator<T>>asList(fixedComparator, new NullComparator<>(false),
				new ComparableComparator<>()));
	}

	@Override
	public int compare(final T o1, final T o2) {
		return this.c.compare(o1, o2);
	}

}

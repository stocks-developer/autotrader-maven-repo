package com.dakshata.tools.trading;

import com.dakshata.constants.trading.PositionState;
import com.dakshata.trading.model.platform.IPlatformPosition;
import com.dakshata.trading.model.portfolio.Portfolio;

/**
 * Checks whether the position is <code>OPEN</code> or <code>CLOSED</code>.
 *
 * @author PRITESH
 *
 */
public interface IPositionStateCalculator {

	PositionState calculate(IPlatformPosition position, Portfolio portfolio);

}

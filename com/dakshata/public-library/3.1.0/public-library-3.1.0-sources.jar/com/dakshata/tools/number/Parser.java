/**
 *
 */
package com.dakshata.tools.number;

import static com.dakshata.tools.string.StringUtil.isEmpty;
import static java.lang.Float.isFinite;

import java.text.NumberFormat;
import java.text.ParseException;

import lombok.extern.slf4j.Slf4j;

/**
 * Parsing numbers from string.
 *
 * @author PRITESH
 *
 */
@Slf4j
public final class Parser {

	public static Float parseFloat(final String f, final Float defaultVal) {
		final Float r = parseFloat(f);
		return ((r != null) && isFinite(r)) ? r : defaultVal;
	}

	public static Float parseFloat(final String f) {
		if (f == null) {
			return null;
		}

		try {
			return Float.parseFloat(f);
		} catch (final NumberFormatException e) {
			try {
				final Number number = NumberFormat.getNumberInstance().parse(f);
				return number.floatValue();
			} catch (final ParseException e1) {
				if (!isEmpty(f)) {
					// Restricted logging by skipping blanks
					log.error("Could not parse float: {}", f);
				}
			}
		}
		return null;
	}

	public static Integer parseInteger(final String i, final Integer defaultVal) {
		final Integer r = parseInteger(i);
		return (r != null) ? r : defaultVal;
	}

	public static Integer parseInteger(final String i) {
		if (i == null) {
			return null;
		}

		try {
			return Integer.parseInt(i);
		} catch (final NumberFormatException e) {
			log.error("Could not parse integer: {}", e.getMessage());
			return null;
		}
	}

	public static Long parseLong(final String i, final Long defaultVal) {
		final Long r = parseLong(i);
		return (r != null) ? r : defaultVal;
	}

	public static Long parseLong(final String i) {
		if (i == null) {
			return null;
		}

		try {
			return Long.parseLong(i);
		} catch (final NumberFormatException e) {
			log.error("Could not parse long: {}", e.getMessage());
			return null;
		}
	}

	public static Boolean parseBoolean(final String i) {
		if (i == null) {
			return null;
		}

		return Boolean.parseBoolean(i);
	}

	public static Boolean parseBoolean(final String i, Boolean defaultVal) {
		final Boolean r = Boolean.parseBoolean(i);
		return (r != null) ? r : defaultVal;
	}

}

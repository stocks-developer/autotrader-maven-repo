/**
 *
 */
package com.dakshata.tools.common;

import java.time.LocalTime;

import com.dakshata.data.model.common.IOperationResponse;
import com.dakshata.data.model.common.OperationResponse;

/**
 * Responsible for determining working hours for trading.
 *
 * @author PRITESH
 *
 */
public final class SystemStatus {

	private static final LocalTime OFFLINE_START = LocalTime.of(0, 1);

	private static final LocalTime OFFLINE_END = LocalTime.of(7, 30);

	private static final String OFFLINE_MESSAGE = "Offline: Operations are not allowed from ["
			+ OFFLINE_START.toString() + " am] to [" + OFFLINE_END.toString() + " am]";

	public static IOperationResponse<Boolean> isOffline() {
		final LocalTime now = LocalTime.now();
		final boolean offline = now.isAfter(OFFLINE_START) && now.isBefore(OFFLINE_END);
		final String message = (offline) ? OFFLINE_MESSAGE : null;
		return OperationResponse.<Boolean>builder().result(offline).message(message).build();
	}

}

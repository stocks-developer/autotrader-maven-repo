/**
 *
 */
package com.dakshata.tools.file;

import static java.nio.file.StandardOpenOption.TRUNCATE_EXISTING;
import static java.nio.file.StandardOpenOption.WRITE;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;

import com.opencsv.bean.HeaderColumnNameMappingStrategy;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;

/**
 * File system utility classes.
 *
 * @author PRITESH
 *
 */
public final class FileSystem {

	public static void delete(final String path) throws IOException {
		final Path p = Paths.get(path);
		Files.deleteIfExists(p);
	}

	public static void createNewFile(final String path) throws IOException {
		final File file = new File(path);
		if (file.getParentFile() != null) {
			file.getParentFile().mkdirs();
		}
		file.createNewFile();
	}

	public static void createNewFileIfMissing(final String path) throws IOException {
		final Path p = Paths.get(path);
		if (Files.notExists(p)) {
			createNewFile(path);
		}
	}

	public static void recreateNewFile(final String path) throws IOException {
		delete(path);
		createNewFile(path);
	}

	public static void writeLines(final String path, final Iterable<? extends CharSequence> lines, final Charset cs)
			throws InterruptedException, IOException {
		try {
			Files.write(Paths.get(path), lines, cs, WRITE, TRUNCATE_EXISTING);
		} catch (final Exception e) {
			// Retry if first attempt fails
			Thread.sleep(250);
			Files.write(Paths.get(path), lines, WRITE, TRUNCATE_EXISTING);
		}
	}

	public static <T> void writeCsv(final String fileName, final Iterator<T> itr,
			final HeaderColumnNameMappingStrategy<T> strategy) throws Exception {
		Writer writer = null;
		try {
			createNewFileIfMissing(fileName);
			writer = new FileWriter(fileName);
			final StatefulBeanToCsv<T> converter = new StatefulBeanToCsvBuilder<T>(writer).withMappingStrategy(strategy)
					.withApplyQuotesToAll(false).withLineEnd(System.lineSeparator()).build();
			converter.write(itr);
		} catch (final Exception e) {
			throw e;
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
	}

	public static final void replaceInFile(final String path, final String search, final String replace)
			throws IOException {
		final Path p = Paths.get(path);
		final String contents = new String(Files.readAllBytes(p));
		final String result = contents.replace(search, replace);
		Files.write(p, result.getBytes());
	}

}

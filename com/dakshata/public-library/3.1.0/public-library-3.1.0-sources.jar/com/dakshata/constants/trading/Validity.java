package com.dakshata.constants.trading;

import static org.apache.commons.lang3.EnumUtils.isValidEnum;

/**
 * Represents order validity (DAY, IOC).
 *
 * TTL validity is supported by Zerodha.
 *
 * @author PRITESH
 *
 */
public enum Validity {

	DAY, IOC, TTL, GTC, GTD, GFD, EOS, COL;

	public static Validity parse(String v) {
		if (isValidEnum(Validity.class, v)) {
			return Validity.valueOf(v);
		}
		return null;
	}

	public String toSharekhan() {
		switch (this) {
		case DAY:
			return "GFD";
		case IOC:
			return "IOC";
		case GTD:
			return "MyGTD";
		default:
			return "GFD";
		}
	}

	public static Validity fromSharekhan(final String v) {
		if (v == null) return null;
		switch (v) {
		case "GFD":
			return DAY;
		case "IOC":
			return IOC;
		case "MyGTD":
			return GTD;
		default:
			return null;
		}
	}

}

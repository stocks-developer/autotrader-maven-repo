/**
 *
 */
package com.dakshata.constants.autotrader;

/**
 * AutoTrader public constants.
 *
 * @author PRITESH
 *
 */
public interface IAutoTrader {

	String API_KEY_HEADER = "api-key";

	String UI_DATE_PICKER_FORMAT = "MM/dd/yyyy";

}

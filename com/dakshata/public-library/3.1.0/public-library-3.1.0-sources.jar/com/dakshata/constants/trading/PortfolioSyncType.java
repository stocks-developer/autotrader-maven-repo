/**
 *
 */
package com.dakshata.constants.trading;

/**
 * Indicates the type of portfolio sync.
 *
 * @author PRITESH
 *
 */
public enum PortfolioSyncType {

	POSITION, ORDER, MARGIN, HOLDING;

}

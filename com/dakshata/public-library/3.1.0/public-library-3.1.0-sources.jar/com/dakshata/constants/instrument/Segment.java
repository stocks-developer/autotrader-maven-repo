/**
 *
 */
package com.dakshata.constants.instrument;

import lombok.extern.slf4j.Slf4j;

/**
 * A segment represents functional area of an instrument.
 *
 * @author PRITESH
 *
 */
@Slf4j
public enum Segment {

	EQUITY, COMMODITY, CURRENCY;

	public static final Segment of(final String exchange) {
		switch (exchange.toUpperCase()) {
		case "NSE":
		case "BSE":
		case "NFO":
		case "BFO":
		case "NSEFO":
		case "BSEFO":
		case "NSECM":
		case "BSECM":
		case "CASH":
		case "NSE_FO":
		case "NSE_CM":
		case "BSE_FO":
		case "BSE_CM":
		case "NSEEQ":
		case "BSEEQ":
			return EQUITY;
		case "MCX":
		case "NCDEX":
		case "NCO":
		case "BCO":
		case "COM":
		case "MCXFO":
		case "MCX_FO":
		case "MCXCOMM":
			return COMMODITY;
		case "CDS":
		case "BCD":
		case "NCD":
		case "NSECD":
		case "NSECDS":
		case "CUR":
		case "CDE_FO":
		case "NSECURR":
			return CURRENCY;
		}

		log.error("SD-ERR-014: Cannot convert segment. Raw: {}", exchange);
		throw new RuntimeException("Invalid exchange: " + exchange);
	}

	public static final Segment fromFyers(final int segment) {
		switch (segment) {
		case 10:
		case 11:
			return EQUITY;
		case 12:
			return CURRENCY;
		case 20:
			return COMMODITY;
		}

		log.error("SD-ERR-014: Cannot convert segment. Raw: {}", segment);
		throw new RuntimeException("Invalid segment: " + segment);
	}

	public static final Segment fromShoonya(final String segment) {
		switch (segment.toUpperCase()) {
		case "E":
		case "D":
			return EQUITY;
		case "C":
			return CURRENCY;
		case "M":
			return COMMODITY;
		}

		log.error("SD-ERR-015: Cannot convert Shoonya segment. Raw: {}", segment);
		return null;
	}
}

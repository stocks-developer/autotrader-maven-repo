package com.dakshata.constants.instrument;

import java.util.EnumSet;
import java.util.Set;

import lombok.Getter;

/**
 * Source of the instruments.
 *
 * Defines sources for financial instruments and categorizes them based on
 * different features.
 *
 * @author PRITESH
 */
@Getter
public enum Source {

	// @formatter:off
    // Standard Sources
    ALICEBLUE(SourceFeature.EAGER_CACHE),
    ANGEL(SourceFeature.EAGER_CACHE),
    BAJAJ_FIN,
    CHOICE,
    DHAN(SourceFeature.EAGER_CACHE),
    EDELWEISS,
    FINVASIA(SourceFeature.EAGER_CACHE),
    FIVE_PAISA(SourceFeature.EAGER_CACHE),
    FYERS(SourceFeature.EAGER_CACHE),
    GROWW(SourceFeature.EAGER_CACHE),
    HDFC_SEC,
    ICICI,
    IIFL(SourceFeature.EAGER_CACHE),
    IIFL_MARKETS(SourceFeature.EAGER_CACHE),
    KOTAK,
    KOTAK_NEO(SourceFeature.EAGER_CACHE),
    MASTERTRUST(SourceFeature.EAGER_CACHE),
    MOTILAL_OSWAL(SourceFeature.EAGER_CACHE),
    MSTOCK,
    NSE,
    PROFITMART(SourceFeature.DYNAMIC),
    PROFITMAX(SourceFeature.DYNAMIC),
    RUPEETRACKER,
    SAS(SourceFeature.DYNAMIC),
    SHAREKHAN(SourceFeature.EAGER_CACHE),
    UPSTOX,
    UPSTOX_API(SourceFeature.EAGER_CACHE),
    ZEBU,
    ZEBULL,
    ZERODHA(SourceFeature.EAGER_CACHE),

    // XTS Platforms
    ANAND_RATHI(SourceFeature.XTS, SourceFeature.EAGER_CACHE),
    XTS_AETRAM(SourceFeature.XTS),
    XTS_AGARWAL(SourceFeature.XTS),
    XTS_AMBALAL(SourceFeature.XTS),
    XTS_ARHAM(SourceFeature.XTS),
    XTS_ATS(SourceFeature.XTS),
    XTS_AXIS(SourceFeature.XTS),
    XTS_BONANZA(SourceFeature.XTS),
    XTS_CHOICE(SourceFeature.XTS),
    XTS_DBONLINE(SourceFeature.XTS),
    XTS_EUREKA(SourceFeature.XTS),
    XTS_FIVE_PAISA(SourceFeature.XTS),
    XTS_IIFL(SourceFeature.XTS, SourceFeature.EAGER_CACHE),
    XTS_JAINAM(SourceFeature.XTS, SourceFeature.EAGER_CACHE),
    XTS_MLB(SourceFeature.XTS, SourceFeature.EAGER_CACHE),
    XTS_MOTILAL(SourceFeature.XTS),
    XTS_NIRMAL(SourceFeature.XTS),
    XTS_PESB(SourceFeature.XTS),
    XTS_RELIGARE(SourceFeature.XTS),
    XTS_RMONEY(SourceFeature.XTS),
    XTS_SHARE_IND(SourceFeature.XTS),
    XTS_SMC(SourceFeature.XTS),
    XTS_SW_CAPITAL(SourceFeature.XTS),
    XTS_TSWIFT(SourceFeature.XTS),
    XTS_WISDOM(SourceFeature.XTS),
    XTS_ZEBU(SourceFeature.XTS),

    // KAMBALA Platforms
    KAMBALA_FLATTRADE(SourceFeature.KAMBALA, SourceFeature.EAGER_CACHE),
	KAMBALA_PLINDIA(SourceFeature.KAMBALA, SourceFeature.EAGER_CACHE),
    KAMBALA_PROFITMART(SourceFeature.KAMBALA, SourceFeature.EAGER_CACHE),
    KAMBALA_TRADEJINI(SourceFeature.KAMBALA, SourceFeature.DYNAMIC);
    // @formatter:on

	/**
	 * Features supported by the source.
	 */
	private final Set<SourceFeature> features;

	/**
	 * Constructor for a source with features.
	 */
	Source(final SourceFeature... features) {
		this.features = features.length > 0 ? EnumSet.of(features[0], features) : EnumSet.noneOf(SourceFeature.class);
	}

	/**
	 * Checks if the source supports a specific feature.
	 */
	public boolean hasFeature(final SourceFeature feature) {
		return this.features.contains(feature);
	}

	/**
	 * Convenience methods for common feature checks.
	 */
	public boolean isEagerCache() {
		return this.hasFeature(SourceFeature.EAGER_CACHE);
	}

	public boolean isDynamic() {
		return this.hasFeature(SourceFeature.DYNAMIC);
	}

	public boolean isXts() {
		return this.hasFeature(SourceFeature.XTS);
	}

	public boolean isKambala() {
		return this.hasFeature(SourceFeature.KAMBALA);
	}
}

/**
 * Enum representing special features of a Source.
 */
enum SourceFeature {
	EAGER_CACHE, DYNAMIC, XTS, KAMBALA
}

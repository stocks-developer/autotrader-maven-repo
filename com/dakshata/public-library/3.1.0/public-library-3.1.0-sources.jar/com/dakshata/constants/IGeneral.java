/**
 *
 */
package com.dakshata.constants;

import java.time.ZoneId;
import java.util.TimeZone;
import java.util.regex.Pattern;

/**
 * General constants.
 *
 * @author PRITESH
 *
 */
public interface IGeneral {

	String STOCKS_DEVELOPER = "Stocks Developer";

	String BLANK = "";

	String COMMA = ",";

	String HYPHEN = "-";

	String COLON = ":";

	String SEMI_COLON = ";";

	String PIPE = "|";

	String TILDE = "~";

	String UI_RECORD_SEPARATOR = TILDE;

	String SUCCESS = "success";

	String FAILURE = "failure";

	String ERROR = "error";

	ZoneId IST_ZONE_ID = ZoneId.of("Asia/Kolkata");

	TimeZone IST = TimeZone.getTimeZone(IST_ZONE_ID);

	String TRADING_ACC_HEADER = "SD-TA-ID";

	String IPV4_REGEX = "^((25[0-5]|(2[0-4]|1\\d|[1-9]|)\\d)\\.?\\b){4}$";

	Pattern IPV4_PATTERN = Pattern.compile(IPV4_REGEX);

}

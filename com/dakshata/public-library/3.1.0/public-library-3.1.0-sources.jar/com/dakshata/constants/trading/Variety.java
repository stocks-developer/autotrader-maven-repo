package com.dakshata.constants.trading;

import static com.dakshata.constants.trading.TradingPlatform.SMART_API;
import static com.dakshata.tools.string.StringUtil.isEmpty;

import java.util.Arrays;
import java.util.function.Function;

import lombok.extern.slf4j.Slf4j;

/**
 * Represents order variety (REGULAR, BO, CO).
 *
 * @author PRITESH
 *
 */
@Slf4j
public enum Variety {

	REGULAR("SIMPLE", "regular", null, null, null, null, null, "REGULAR", null, null, null, null),
	BO("OCO", "bo", "B", "BO", "BO", "BO", "BO", null, "BO", "BO", "BO", "BO"),
	CO("CO", "co", "H", "CO", "CO", "CO", "CO", null, "CO", "CO", "CO", "CO"),
	ICEBERG(null, "iceberg", null, null, null, null, null, null, null, null, null, null),
	/**
	 * Good Till Triggered (resting trigger / GTT / Forever order). All broker
	 * columns are null on purpose: GTT is never serialized as a broker variety
	 * string; it is detected internally (variety == GTT) and routed to the broker's
	 * dedicated GTT endpoint by each broker's OrderOps.
	 */
	GTT(null, null, null, null, null, null, null, null, null, null, null, null);

	private final String upstox, kite, shoonya, fyers, profitmart, mastertrust, edelweiss, kotak, a3, sas, profitmax,
			kambala;

	Variety(final String upstox, final String kite, final String shoonya, final String fyers, final String profitmart,
			final String mastertrust, final String edelweiss, final String kotak, final String a3, final String sas,
			final String profitmax, final String kambala) {
		this.upstox = upstox;
		this.kite = kite;
		this.shoonya = shoonya;
		this.fyers = fyers;
		this.profitmart = profitmart;
		this.mastertrust = mastertrust;
		this.edelweiss = edelweiss;
		this.kotak = kotak;
		this.a3 = a3;
		this.sas = sas;
		this.profitmax = profitmax;
		this.kambala = kambala;
	}

	public boolean isComplex() {
		return (this == BO) || (this == CO);
	}

	public String prettyPrint() {

		switch (this) {
		case REGULAR:
			return "regular";
		case CO:
			return "cover";
		case BO:
			return "bracket";
		case ICEBERG:
			return "iceberg";
		case GTT:
			return "gtt";
		}

		return "unknown";
	}

	public static Variety fromText(final String input) {
		if (isEmpty(input)) {
			return REGULAR;
		}

		final String v = input.toUpperCase();
		switch (v) {
		case "BO":
			return BO;
		case "CO":
			return CO;
		default:
			return REGULAR;
		}
	}

	public static Variety fromUpstox(final String type) {
		return from(type, ot -> ot.upstox, "upstox", null);
	}

	public static Variety fromA3(final String type) {
		return from(type, ot -> ot.a3, "a3", REGULAR);
	}

	public static Variety fromEdelweiss(final String type) {
		return from(type, ot -> ot.edelweiss, "edelweiss", REGULAR);
	}

	public static Variety fromMastertrust(final String type) {
		return from(type, ot -> ot.mastertrust, "mastertrust", REGULAR);
	}

	public static Variety fromShoonya(final String type) {
		return from(type, ot -> ot.shoonya, "shoonya", REGULAR);
	}

	public static Variety fromFyers(final String type) {
		return from(type, ot -> ot.fyers, "fyers", REGULAR);
	}

	public static Variety fromProfitmart(final String type) {
		return from(type, ot -> ot.profitmart, "profitmart", REGULAR);
	}

	public static Variety fromProfitmax(final String type) {
		return from(type, ot -> ot.profitmax, "profitmax", REGULAR);
	}

	public static Variety fromKambala(final String type) {
		return from(type, ot -> ot.kambala, "kambala", REGULAR);
	}

	public static Variety fromKite(final String type) {
		return from(type, ot -> ot.kite, "kite", null);
	}

	public static Variety fromKotak(final String type) {
		return from(type, ot -> ot.kotak, "kotak", null);
	}

	public static Variety fromSas(final String type) {
		return from(type, ot -> ot.sas, "sas", REGULAR);
	}

	public String toUpstox() {
		return this.upstox;
	}

	public String toShoonya() {
		return this.shoonya;
	}

	public String toKite() {
		return this.kite;
	}

	public String toKotak() {
		return this.kotak;
	}

	public String toA3() {
		return this.a3;
	}

	public String toSas() {
		return this.sas;
	}

	public String toAngel(final OrderType ot, final boolean amo) {
		switch (this) {
		case REGULAR:
			if ((OrderType.SL_MARKET == ot) || (OrderType.STOP_LOSS == ot)) {
				return "STOPLOSS";
			}
			return "NORMAL";
		case BO:
			return "ROBO";
		default:
			return null;
		}
	}

	public static Variety fromAngel(final String variety) {
		if (variety == null) return null;
		switch (variety.toUpperCase()) {
		case "AMO":
		case "STOPLOSS":
		case "NORMAL":
			return REGULAR;
		case "ROBO":
			return BO;
		default:
			log.error("SD-ERR-012: Unknown Variety. Raw: {}, Platform: {}", variety, SMART_API);
			return null;
		}
	}

	private static Variety from(final String type, final Function<Variety, String> fun, final String platform,
			final Variety defaultVar) {
		if (type == null) {
			return null;
		}

		final String t = type.trim();
		final Variety variety = Arrays.stream(Variety.values()).filter(ot -> {
			final String result = fun.apply(ot);
			return (result == null) ? false : result.equalsIgnoreCase(t);
		}).findAny().orElse(defaultVar);

		if (variety == null) {
			log.error("SD-ERR-012: Unknown Variety. Raw: {}, Platform: {}", type, platform);
		}

		return variety;
	}

}

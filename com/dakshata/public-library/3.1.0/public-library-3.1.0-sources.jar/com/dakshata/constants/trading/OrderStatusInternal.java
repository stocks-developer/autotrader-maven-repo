/**
 *
 */
package com.dakshata.constants.trading;

/**
 * Order status set by internal trading systems.
 *
 * @author PRITESH
 *
 */
public enum OrderStatusInternal {

	RECEIVED, CANCELLED, ERROR, PLACED

}

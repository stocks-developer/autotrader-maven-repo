/**
 *
 */
package com.dakshata.constants.trading;

/**
 * Represents state of the position, which can be either OPEN or CLOSED.
 * 
 * @author PRITESH
 *
 */
public enum PositionState {

	OPEN, CLOSED

}

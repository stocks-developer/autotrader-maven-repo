/**
 *
 */
package com.dakshata.constants.instrument;

/**
 * Type of option.
 *
 * @author PRITESH
 *
 */
public enum OptionType {

	CE("Call"), PE("Put");

	private final String name;

	private OptionType(final String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public static final boolean isValid(final String type) {
		if (type == null) {
			return false;
		}

		final String mapped = map(type);
		return CE.name().equalsIgnoreCase(mapped) || PE.name().equalsIgnoreCase(mapped);
	}

	public static final OptionType from(final String type) {
		final String mapped = map(type);
		return isValid(type) ? OptionType.valueOf(mapped.toUpperCase()) : null;
	}

	private static final String map(final String type) {
		if ("CA".equalsIgnoreCase(type)) {
			return "CE";
		}
		if ("PA".equalsIgnoreCase(type)) {
			return "PE";
		}

		return type;
	}

}

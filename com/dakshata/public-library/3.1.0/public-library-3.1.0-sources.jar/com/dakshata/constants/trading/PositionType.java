/**
 *
 */
package com.dakshata.constants.trading;

import static com.dakshata.constants.trading.ProductType.DELIVERY;
import static com.dakshata.constants.trading.ProductType.INTRADAY;
import static com.dakshata.constants.trading.ProductType.NORMAL;

import java.util.Arrays;
import java.util.function.Function;

import lombok.extern.slf4j.Slf4j;

/**
 * Represents a position type (MIS, NRML, CNC, BO, CO).
 *
 * @author PRITESH
 *
 */
@Slf4j
public enum PositionType {

	MIS("MIS", "I", "MIS", "INTRADAY", "I", "MIS", "MIS", "MIS", "MIS", "INTRADAY", null, INTRADAY),
	NRML("NRML", null, "NRML", "MARGIN", "M", "NRML", "NRML", "NRML", "NRML", "MARGIN", null, NORMAL),
	CNC("CNC", "D", "CNC", "CNC", "C", "CNC", "CNC", "CNC", "CNC", "CNC", null, DELIVERY),
	BO("BO", "OCO", "BO", "BO", "B", "BO", "BO", "BO", "BO", "BO", Variety.BO, INTRADAY),
	CO("CO", "CO", "CO", "CO", "H", "CO", "CO", "CO", "CO", "CO", Variety.CO, INTRADAY),
	MTF("MTF", "MTF", "MTF", "MTF", "MTF", "MTF", "MTF", "MTF", "MTF", "MTF", null, DELIVERY);

	private final String upstox, kite, ant, fyers, shoonya, mastertrust, edelweiss, kotakNeo, xts, dhan;

	private final Variety variety;

	private final ProductType productType;

	PositionType(final String kite, final String upstox, final String ant, final String fyers, final String shoonya,
			final String mastertrust, final String edelweiss, final String kotakNeo, final String xts,
			final String dhan, final Variety variety, final ProductType productType) {
		this.upstox = upstox;
		this.kite = kite;
		this.ant = ant;
		this.fyers = fyers;
		this.shoonya = shoonya;
		this.mastertrust = mastertrust;
		this.edelweiss = edelweiss;
		this.kotakNeo = kotakNeo;
		this.xts = xts;
		this.dhan = dhan;
		this.variety = variety;
		this.productType = productType;
	}

	/**
	 * This should be the standard method going forward.
	 */
	public static PositionType parse(final String rawType, TradingPlatform platform) {

		if (rawType != null) {
			switch (rawType.toUpperCase()) {
			case "INTRADAY":
			case "MIS":
				return MIS;
			case "CNC":
			case "DELIVERY":
			case "LONGTERM":
				return CNC;
			case "NORMAL":
			case "NRML":
				return NRML;
			case "BO":
				return BO;
			case "CO":
				return CO;
			case "MTF":
				return MTF;
			}
		}

		log.error("SD-ERR-009: Unknown PositionType. Raw: {}, Platform: {}", rawType, platform);
		return null;
	}

	public static PositionType fromXts(final String type) {
		return from(type, ot -> ot.xts, "xts");
	}

	public static PositionType fromDhan(final String type) {
		return from(type, ot -> ot.dhan, "dhan");
	}

	public static PositionType fromKotakNeo(final String type) {
		return from(type, ot -> ot.kotakNeo, "kotakNeo");
	}

	public static PositionType fromFyers(final String type) {
		return from(type, ot -> ot.fyers, "fyers");
	}

	public static PositionType fromUpstox(final String type) {
		return from(type, ot -> ot.upstox, "upstox");
	}

	public static PositionType fromKite(final String type) {
		return from(type, ot -> ot.kite, "kite");
	}

	public static PositionType fromAnt(final String type) {
		return from(type, ot -> ot.ant, "ant");
	}

	public static PositionType fromShoonya(final String type) {
		return from(type, ot -> ot.shoonya, "shoonya");
	}

	public static PositionType fromMastertrust(final String type) {
		return from(type, ot -> ot.mastertrust, "mastertrust");
	}

	public static PositionType fromEdelweiss(final String type) {
		return from(type, ot -> ot.edelweiss, "edelweiss");
	}

	public static PositionType fromAngel(final String productType) {
		if (productType == null) return null;
		switch (productType.toUpperCase()) {
		case "INTRADAY":
		case "MARGIN":
		case "AMO_MARGIN":
			return MIS;
		case "DELIVERY":
		case "AMO_DELIVERY":
			return CNC;
		case "CARRYFORWARD":
		case "AMO_CARRYFORWARD":
			return NRML;
		case "BO":
			return BO;
		case "CO":
			return CO;
		}

		log.error("SD-ERR-009: Unknown PositionType. Raw: {}, Platform: {}", productType, "angel");
		return null;
	}

	public static PositionType fromMotilal(final String posType) {
		switch (posType.toUpperCase()) {
		case "VALUEPLUS":
			return MIS;
		case "DELIVERY":
		case "SELLFROMDP":
		case "BTST":
			return CNC;
		case "NORMAL":
			return NRML;
		case "MTF":
			return MTF;
		}

		log.error("SD-ERR-009: Unknown PositionType. Raw: {}, Platform: {}", posType, "motilal");
		return null;
	}

	public String toXts() {
		return this.xts;
	}

	public String toUpstox() {
		return this.upstox;
	}

	public String toKite() {
		return this.kite;
	}

	public String toAnt() {
		return this.ant;
	}

	public String toFyers() {
		return this.fyers;
	}

	public String toShoonya() {
		return this.shoonya;
	}

	public String toMastertrust() {
		return this.mastertrust;
	}

	public String toEdelweiss() {
		return this.edelweiss;
	}

	public String toDhan() {
		return this.dhan;
	}

	public ProductType getProductType() {
		return this.productType;
	}

	public boolean matches(final Variety v) {
		return (this.variety != null) && (this.variety == v);
	}

	private static PositionType from(final String type, final Function<PositionType, String> fun,
			final String platform) {
		if (type == null) {
			return null;
		}

		final String t = type.trim();
		final PositionType positionType = Arrays.stream(PositionType.values()).filter(ot -> {
			final String result = fun.apply(ot);
			return (result == null) ? false : result.equalsIgnoreCase(t);
		}).findAny().orElse(null);

		if (positionType == null) {
			log.error("SD-ERR-009: Unknown PositionType. Raw: {}, Platform: {}", type, platform);
		}

		return positionType;
	}

}

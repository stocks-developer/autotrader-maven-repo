package com.dakshata.constants.trading;

import static com.dakshata.tools.string.StringUtil.isEmpty;

import java.util.Arrays;
import java.util.function.Function;

import com.dakshata.tools.string.StringUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * Represents a order trade type (BUY or SELL).
 *
 * @author PRITESH
 *
 */
@Slf4j
public enum TradeType {

	BUY("b", "B", 1, "B", "B", "B", 1, "B", "B", "B"), SELL("s", "S", -1, "S", "S", "S", 2, "S", "S", "S");

	private final String upstox, shoonya, iifl, profitmart, a3, zebu, profitmax, kambala;

	private final int fyers, choice;

	TradeType(final String upstox, final String shoonya, final int fyers, final String iifl, final String profitmart,
			final String a3, final int choice, final String zebu, final String profitmax, final String kambala) {
		this.upstox = upstox;
		this.shoonya = shoonya;
		this.fyers = fyers;
		this.iifl = iifl;
		this.profitmart = profitmart;
		this.a3 = a3;
		this.choice = choice;
		this.zebu = zebu;
		this.profitmax = profitmax;
		this.kambala = kambala;
	}

	/**
	 * This should be the standard method going forward.
	 */
	public static TradeType parse(final String rawType, TradingPlatform platform) {

		if (rawType != null) {
			switch (rawType.toUpperCase()) {
			case "B":
			case "BUY":
				return BUY;
			case "S":
			case "SELL":
				return SELL;
			}
		}

		log.error("SD-ERR-01: Unknown TradeType. Raw: {}, Platform: {}", rawType, platform);
		return null;
	}

	public final String toShort() {
		return this == BUY ? "B" : "S";
	}

	public static final TradeType fromShort(final String input) {
		if (isEmpty(input)) {
			return null;
		}

		switch (input.toUpperCase()) {
		case "B":
			return BUY;
		case "S":
			return SELL;
		}

		return null;
	}

	public static final TradeType fromText(final String text) {
		if (StringUtil.isEmpty(text)) {
			return null;
		}

		final String t = text.toUpperCase();

		switch (t) {
		case "BUY":
		case "COVER":
			return TradeType.BUY;
		case "SELL":
		case "SHORT":
			return TradeType.SELL;
		}

		return null;
	}

	public static TradeType fromUpstox(final String type) {
		return from(type, ot -> ot.upstox, "upstox");
	}

	public static TradeType fromIifl(final String type) {
		return from(type, ot -> ot.iifl, "iifl");
	}

	public static TradeType fromShoonya(final String type) {
		return from(type, ot -> ot.shoonya, "shoonya");
	}

	public static TradeType fromProfitmart(final String type) {
		return from(type, ot -> ot.profitmart, "profitmart");
	}

	public static TradeType fromProfitmax(final String type) {
		return from(type, ot -> ot.profitmax, "profitmax");
	}

	public static TradeType fromKambala(final String type) {
		return from(type, ot -> ot.kambala, "kambala");
	}

	public static TradeType fromA3(final String type) {
		return from(type, ot -> ot.a3, "a3");
	}

	public static TradeType fromZebu(final String type) {
		return from(type, ot -> ot.zebu, "zebu");
	}

	public static TradeType fromFyers(final int type) {
		for (final TradeType t : TradeType.values()) {
			if (type == t.fyers) {
				return t;
			}
		}

		log.error("SD-ERR-011: Unknown TradeType. Raw: {}, Platform: {}", type, "fyers");
		return null;
	}

	public static TradeType fromChoice(final int type) {
		for (final TradeType t : TradeType.values()) {
			if (type == t.choice) {
				return t;
			}
		}

		log.error("SD-ERR-011: Unknown TradeType. Raw: {}, Platform: {}", type, "choice");
		return null;
	}

	public String toUpstox() {
		return this.upstox;
	}

	public String toIifl() {
		return this.iifl;
	}

	public String toShoonya() {
		return this.shoonya;
	}

	public String toProfitmart() {
		return this.profitmart;
	}

	public String toProfitmax() {
		return this.profitmax;
	}

	public String toKambala() {
		return this.kambala;
	}

	public String toA3() {
		return this.a3;
	}

	public int toFyers() {
		return this.fyers;
	}

	public int toChoice() {
		return this.choice;
	}

	private static TradeType from(final String type, final Function<TradeType, String> fun, final String platform) {
		if (type == null) {
			return null;
		}

		final String t = type.trim();
		final TradeType tradeType = Arrays.stream(TradeType.values()).filter(ot -> {
			final String result = fun.apply(ot);
			return (result == null) ? false : result.equalsIgnoreCase(t);
		}).findAny().orElse(null);

		if (tradeType == null) {
			log.error("SD-ERR-011: Unknown TradeType. Raw: {}, Platform: {}", type, platform);
		}

		return tradeType;
	}

}

/**
 *
 */
package com.dakshata.constants.instrument;

import static java.util.Collections.unmodifiableSet;

import java.util.HashSet;
import java.util.Set;

/**
 * @author PRITESH
 *
 */
final class ExchSegments {

	static final Set<String> NSE, BSE, MCX, NCDEX;

	static {
		Set<String> x = new HashSet<>();
		x.add("NSE");
		x.add("NSECM");
		x.add("NSEEQ");
		x.add("NFO");
		x.add("NSEFO");
		x.add("CDS");
		x.add("CDE");
		x.add("NSECD");
		x.add("NSECDS");
		x.add("NCD");
		x.add("NSE-FX");
		x.add("NSECURR");
		NSE = unmodifiableSet(x);

		x = new HashSet<>();
		x.add("BSE");
		x.add("BSECM");
		x.add("BSEEQ");
		x.add("BFO");
		x.add("BSEFO");
		x.add("BCD");
		BSE = unmodifiableSet(x);

		x = new HashSet<>();
		x.add("MCX");
		x.add("MCX-CM");
		x.add("MCXFO");
		x.add("MCXCOMM");
		MCX = unmodifiableSet(x);

		x = new HashSet<>();
		x.add("NCDEX");
		NCDEX = unmodifiableSet(x);
	}

}

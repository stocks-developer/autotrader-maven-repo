package com.dakshata.constants.trading;

import static com.dakshata.tools.string.StringUtil.isEmpty;
import static java.util.Collections.unmodifiableSet;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Function;

import lombok.extern.slf4j.Slf4j;

/**
 * Represents a product type (INTRADAY, DELIVERY, NORMAL).
 *
 * @author PRITESH
 *
 */
@Slf4j
public enum ProductType {

	INTRADAY("MIS", "I", "MIS", "INTRADAY", "INTRADAY", "I", "MIS", "I", "MIS", "MIS", "MIS", "M", "MIS", "MIS", "I",
			"MIS", "I", "INTRADAY", "BIGTRADE"),
	DELIVERY("CNC", "D", "CNC", "DELIVERY", "CNC", "D", "CNC", "C", "CNC", "CNC", null, "D", "CNC", "CNC", "C", "CNC",
			"C", "CNC", "INVESTMENT"),
	NORMAL("NRML", null, "NRML", "CARRYFORWARD", "MARGIN", null, "NRML", "M", "NRML", "NRML", "NORMAL", "D", "NRML",
			"NRML", "M", "NRML", "M", "MARGIN", "INVESTMENT"),
	MTF("MTF", "MTF", "MTF", "MARGIN", "MTF", "MTF", "MTF", "MTF", "MTF", "MTF", "MTF", "MF", "MTF", "NRML", "MTF",
			"MTF", "MTF", "MTF", "BIGTRADE+");

	private final String upstox, kite, ant, angel, fyers, iifl, profitmart, shoonya, mastertrust, edelweiss, kotak,
			choice, zebu, sas, profitmax, kotakNeo, kambala, dhan, sharekhan;

	private static final Set<String> COMPLEX_TYPES;

	static {
		final Set<String> types = new HashSet<>();
		types.add("BO");
		types.add("CO");
		types.add("OCO");
		// Finvaisa shoonya: B => BO, H => CP
		types.add("B");
		types.add("H");

		COMPLEX_TYPES = unmodifiableSet(types);
	}

	ProductType(final String kite, final String upstox, final String ant, final String angel, final String fyers,
			final String iifl, final String profitmart, final String shoonya, final String mastertrust,
			final String edelweiss, final String kotak, final String choice, final String zebu, final String sas,
			final String profitmax, final String kotakNeo, final String kambala, final String dhan,
			final String sharekhan) {
		this.upstox = upstox;
		this.kite = kite;
		this.ant = ant;
		this.angel = angel;
		this.fyers = fyers;
		this.iifl = iifl;
		this.profitmart = profitmart;
		this.shoonya = shoonya;
		this.mastertrust = mastertrust;
		this.edelweiss = edelweiss;
		this.kotak = kotak;
		this.choice = choice;
		this.zebu = zebu;
		this.sas = sas;
		this.profitmax = profitmax;
		this.kotakNeo = kotakNeo;
		this.kambala = kambala;
		this.dhan = dhan;
		this.sharekhan = sharekhan;
	}

	public String toText() {
		switch (this) {
		case INTRADAY:
			return "MIS";
		case NORMAL:
			return "NRML";
		case DELIVERY:
			return "CNC";
		case MTF:
			return "MTF";
		default:
			break;
		}
		return null;
	}

	/**
	 * This should be the standard method going forward.
	 */
	public static ProductType parse(final String type) {
		if (isEmpty(type)) {
			return null;
		} else if (isComplex(type)) {
			return INTRADAY;
		}

		switch (type.toUpperCase()) {
		case "MIS":
		case "INTRADAY":
			return INTRADAY;
		case "NRML":
		case "NORMAL":
			return NORMAL;
		case "CNC":
		case "DELIVERY":
			return DELIVERY;
		case "MTF":
		case "BNPL":
			return MTF;
		}

		log.error("SD-ERR-010: Unknown ProductType. Raw: {}", type);
		return null;
	}

	public static ProductType fromDhan(final String type) {
		return from(type, ot -> ot.dhan, "dhan");
	}

	public static ProductType fromZebu(final String type) {
		return from(type, ot -> ot.zebu, "zebu");
	}

	public static ProductType fromKotak(final String type) {
		return from(type, ot -> ot.kotak, "kotak");
	}

	public static ProductType fromFyers(final String type) {
		return from(type, ot -> ot.fyers, "fyers");
	}

	public static ProductType fromUpstox(final String type) {
		return from(type, ot -> ot.upstox, "upstox");
	}

	public static ProductType fromIifl(final String type) {
		return from(type, ot -> ot.iifl, "iifl");
	}

	public static ProductType fromKite(final String type) {
		return from(type, ot -> ot.kite, "kite");
	}

	public static ProductType fromAnt(final String type) {
		return from(type, ot -> ot.ant, "ant");
	}

	public static ProductType fromProfitmart(final String type) {
		return from(type, ot -> ot.profitmart, "profitmart");
	}

	public static ProductType fromShoonya(final String type) {
		return from(type, ot -> ot.shoonya, "shoonya");
	}

	public static ProductType fromMastertrust(final String type) {
		return from(type, ot -> ot.mastertrust, "mastertrust");
	}

	public static ProductType fromEdelweiss(final String type) {
		return from(type, ot -> ot.edelweiss, "edelweiss");
	}

	public static ProductType fromChoice(final String type) {
		return from(type, ot -> ot.choice, "choice");
	}

	public static ProductType fromSas(final String type) {
		return from(type, ot -> ot.sas, "sas");
	}

	public static ProductType fromProfitmax(final String type) {
		return from(type, ot -> ot.profitmax, "profitmax");
	}

	public static ProductType fromKambala(final String type) {
		return from(type, ot -> ot.kambala, "kambala");
	}

	public static ProductType fromKotakNeo(final String type) {
		return from(type, ot -> ot.kotakNeo, "kotakNeo");
	}

	public static ProductType fromAngel(final String type) {
		if (isEmpty(type)) return null;
		switch (type.toUpperCase()) {
		case "AMO_DELIVERY":
			return DELIVERY;
		case "AMO_CARRYFORWARD":
			return NORMAL;
		}

		return from(type, ot -> ot.angel, "angel");
	}

	public static ProductType fromMotilal(final String prodType) {
		switch (prodType.toUpperCase()) {
		case "VALUEPLUS":
			return INTRADAY;
		case "DELIVERY":
		case "SELLFROMDP":
		case "BTST":
			return DELIVERY;
		case "NORMAL":
			return NORMAL;
		case "MTF":
			return MTF;
		}

		log.error("SD-ERR-010: Unknown ProductType. Raw: {}, Platform: {}", prodType, "motilal");
		return null;
	}

	public String toUpstox() {
		return this.upstox;
	}

	public String toIifl() {
		return this.iifl;
	}

	public String toKite() {
		return this.kite;
	}

	public String toAnt() {
		return this.ant;
	}

	public String toFyers() {
		return this.fyers;
	}

	public String toAngel() {
		return this.angel;
	}

	public String toProfitmart() {
		return this.profitmart;
	}

	public String toProfitmax() {
		return this.profitmax;
	}

	public String toKambala() {
		return this.kambala;
	}

	public String toShoonya() {
		return this.shoonya;
	}

	public String toMastertrust() {
		return this.mastertrust;
	}

	public String toEdelweiss() {
		return this.edelweiss;
	}

	public String toKotak() {
		return this.kotak;
	}

	public String toChoice() {
		return this.choice;
	}

	public String toDhan() {
		return this.dhan;
	}

	public String toZebu() {
		return this.zebu;
	}

	public String toSas() {
		return this.sas;
	}

	public String toKotakNeo() {
		return this.kotakNeo;
	}

	public String toSharekhan() {
		return this.sharekhan;
	}

	public static ProductType fromSharekhan(final String type) {
		return from(type, ot -> ot.sharekhan, "sharekhan");
	}

	public static final boolean isComplex(final String type) {
		if (isEmpty(type)) {
			return false;
		}

		return COMPLEX_TYPES.contains(type.toUpperCase());
	}

	private static ProductType from(final String type, final Function<ProductType, String> fun, final String platform) {
		if (isEmpty(type)) {
			return null;
		}

		if (isComplex(type)) {
			return INTRADAY;
		}

		final String t = type.trim();
		final ProductType productType = Arrays.stream(ProductType.values()).filter(ot -> {
			final String result = fun.apply(ot);
			return (result == null) ? false : result.equalsIgnoreCase(t);
		}).findAny().orElse(null);

		if (productType == null) {
			log.error("SD-ERR-010: Unknown ProductType. Raw: {}, Platform: {}", type, platform);
		}

		return productType;
	}

}

/**
 *
 */
package com.dakshata.constants.trading;

import java.util.Arrays;
import java.util.function.Function;

import lombok.extern.slf4j.Slf4j;

/**
 * Margin category
 *
 * @author PRITESH
 *
 */
@Slf4j
public enum MarginCategory {

	EQUITY("S"), COMMODITY("C"), ALL(null);

	private final String upstox;

	private MarginCategory(final String upstox) {
		this.upstox = upstox;
	}

	public static MarginCategory fromUpstox(final String type) {
		return from(type, mc -> mc.upstox, "upstox");
	}

	public String toUpstox() {
		return this.upstox;
	}

	private static MarginCategory from(final String type, final Function<MarginCategory, String> fun,
			final String platform) {
		if (type == null) {
			return null;
		}

		final String t = type.trim();
		final MarginCategory category = Arrays.stream(MarginCategory.values()).filter(ot -> {
			final String result = fun.apply(ot);
			return (result == null) ? false : result.equalsIgnoreCase(t);
		}).findAny().orElse(null);

		if (category == null) {
			log.error("SD-ERR-006: Unknown MarginCategory. Raw: {}, Platform: {}", type, platform);
		}

		return category;
	}

}

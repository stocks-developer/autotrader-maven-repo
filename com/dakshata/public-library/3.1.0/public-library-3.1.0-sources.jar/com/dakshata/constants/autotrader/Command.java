/**
 *
 */
package com.dakshata.constants.autotrader;

/**
 * AutoTrader commands.
 *
 * @author PRITESH
 *
 */
public enum Command {

	// @formatter:off
	PLACE_ORDER,
	MODIFY_ORDER,
	CANCEL_ORDER,
	CANCEL_ALL_ORDERS,
	CANCEL_CHILD_ORDER,
	SQUARE_OFF_POSITION,
	SQUARE_OFF_PORTFOLIO,
	SQUARE_OFF_HOLDING,
	INCREASE_HOLDING,
	BROKER_LOGIN,
	PLACE_ORDER_COPY,
	CANCEL_ORDER_COPY,
	MODIFY_ORDER_COPY,
	READ_ORDERS,
	READ_POSITIONS,
	READ_MARGINS,
	READ_HOLDINGS;
	// @formatter:on

}

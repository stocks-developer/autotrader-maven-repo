package com.dakshata.constants.trading;

/**
 * Broker-independent status of a resting GTT (Good Till Triggered) order.
 *
 * <p>
 * Each broker exposes its own status vocabulary; the {@code from*} helpers
 * normalise them to this common set so the management view can render a single
 * filter (ACTIVE / TRIGGERED / ALL) across brokers.
 *
 * @author PRITESH
 *
 */
public enum GttStatus {

	ACTIVE, TRIGGERED, CANCELLED, EXPIRED, REJECTED, DISABLED, UNKNOWN;

	/**
	 * Normalises a Zerodha / Kite GTT status (active, triggered, disabled, expired,
	 * cancelled, rejected, deleted).
	 */
	public static GttStatus fromKite(final String raw) {
		if (raw == null) {
			return UNKNOWN;
		}
		switch (raw.trim().toLowerCase()) {
		case "active":
			return ACTIVE;
		case "triggered":
			return TRIGGERED;
		case "disabled":
			return DISABLED;
		case "expired":
			return EXPIRED;
		case "cancelled":
		case "deleted":
			return CANCELLED;
		case "rejected":
			return REJECTED;
		default:
			return UNKNOWN;
		}
	}

	/**
	 * Normalises an Angel GTT rule status (NEW, ACTIVE, SENTTOEXCHANGE, CANCELLED,
	 * FORALL).
	 */
	public static GttStatus fromAngel(final String raw) {
		if (raw == null) {
			return UNKNOWN;
		}
		switch (raw.trim().toUpperCase()) {
		case "NEW":
		case "ACTIVE":
		case "SENTTOEXCHANGE":
			return ACTIVE;
		case "TRIGGERED":
			return TRIGGERED;
		case "CANCELLED":
			return CANCELLED;
		case "EXPIRED":
			return EXPIRED;
		case "REJECTED":
			return REJECTED;
		default:
			return UNKNOWN;
		}
	}

	/**
	 * Normalises a Fyers GTT order-book {@code ord_status} code (1 cancelled, 2
	 * traded/filled, 4 transit, 5 rejected, 6 pending; 3 reserved).
	 */
	public static GttStatus fromFyers(final Integer ordStatus) {
		if (ordStatus == null) {
			return UNKNOWN;
		}
		switch (ordStatus) {
		case 4:
		case 6:
			return ACTIVE;
		case 2:
			return TRIGGERED;
		case 1:
			return CANCELLED;
		case 5:
			return REJECTED;
		default:
			return UNKNOWN;
		}
	}

	/**
	 * Normalises a Dhan Forever order status (TRANSIT, PENDING, REJECTED, CANCELLED,
	 * TRADED, EXPIRED, CONFIRM).
	 */
	public static GttStatus fromDhan(final String raw) {
		if (raw == null) {
			return UNKNOWN;
		}
		switch (raw.trim().toUpperCase()) {
		case "TRANSIT":
		case "PENDING":
		case "CONFIRM":
			return ACTIVE;
		case "TRADED":
			return TRIGGERED;
		case "CANCELLED":
			return CANCELLED;
		case "EXPIRED":
			return EXPIRED;
		case "REJECTED":
			return REJECTED;
		default:
			return UNKNOWN;
		}
	}

	/**
	 * Normalises an Upstox GTT rule status (SCHEDULED, TRIGGERED, EXPIRED, OPEN,
	 * COMPLETED, CANCELLED, PENDING, FAILED, INACTIVE).
	 */
	public static GttStatus fromUpstox(final String raw) {
		if (raw == null) {
			return UNKNOWN;
		}
		switch (raw.trim().toUpperCase()) {
		case "SCHEDULED":
		case "PENDING":
		case "OPEN":
			return ACTIVE;
		case "TRIGGERED":
		case "COMPLETED":
			return TRIGGERED;
		case "CANCELLED":
			return CANCELLED;
		case "EXPIRED":
			return EXPIRED;
		case "FAILED":
			return REJECTED;
		case "INACTIVE":
			return DISABLED;
		default:
			return UNKNOWN;
		}
	}

}

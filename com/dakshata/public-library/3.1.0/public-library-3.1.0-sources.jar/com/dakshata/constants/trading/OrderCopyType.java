/**
 *
 */
package com.dakshata.constants.trading;

/**
 * Represents the type of copy operation in a master-child copy setup.
 *
 * @author PRITESH
 *
 */
public enum OrderCopyType {

	PLACE, CANCEL, MODIFY

}

/**
 * All data model related constants.
 * 
 * @author PRITESH
 *
 */
package com.dakshata.constants.data.model;
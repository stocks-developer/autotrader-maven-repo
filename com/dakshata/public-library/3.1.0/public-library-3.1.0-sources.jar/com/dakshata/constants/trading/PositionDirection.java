/**
 *
 */
package com.dakshata.constants.trading;

/**
 * Shows the direction of the position.
 *
 * @author PRITESH
 *
 */
public enum PositionDirection {

	/*
	 * A BO/CO position can have zero quantity but it is open. As it is open, it is
	 * not correct to display it as closed; hence we changed it to NEUTRAL.
	 */
	LONG, SHORT, NEUTRAL;

}

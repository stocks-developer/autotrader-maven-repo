/**
 *
 */
package com.dakshata.constants.trading;

/**
 * Represents category of position (DAY or NET).
 *
 * @author PRITESH
 *
 */
public enum PositionCategory {
	DAY, NET
}

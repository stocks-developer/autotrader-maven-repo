/**
 * Package for all trading related constants.
 * 
 * @author PRITESH
 *
 */
package com.dakshata.constants.trading;
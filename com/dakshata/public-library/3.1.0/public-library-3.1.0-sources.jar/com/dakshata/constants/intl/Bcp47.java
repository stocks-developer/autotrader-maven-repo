/**
 *
 */
package com.dakshata.constants.intl;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * BCP 47 locales.
 *
 * https://www.techonthenet.com/js/language_tags.php
 *
 * @author PRITESH
 *
 */
@Getter
@AllArgsConstructor
public enum Bcp47 {

	// @formatter:off
	ENGLISH_INDIA("en-IN"),
	ENGLISH_UK("en-GB"),
	ENGLISH_US("en-US");
	// @formatter:on

	private final String tag;

}

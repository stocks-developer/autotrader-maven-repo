package com.dakshata.constants.trading;

import lombok.extern.slf4j.Slf4j;

/**
 * Represents order's status.
 *
 * @author PRITESH
 *
 */
@Slf4j
public enum OrderStatus {

	OPEN, COMPLETE, CANCELLED, REJECTED, TRIGGER_PENDING, UNKNOWN;

	/**
	 * This should be the standard method going forward.
	 */
	public static final OrderStatus parse(final String type, final String platform, final String orderId) {
		if (type == null) {
			return null;
		}

		final String t = type.toLowerCase().trim();
		switch (t) {
		case "open":
		case "pending":
		case "modified":
		case "put order req received":
		case "validation pending":
		case "confirmation pending":
		case "order pending":
		case "transit":
		case "part-traded":
		case "modify validation pending":
		case "open pending":
		case "cancel pending":
		case "modify pending":
		case "approved":
		case "amo":
		case "amo req received":
		case "modify amo req received":
		case "after market order req received":
		case "amo submitted":
		case "modify after market order req received":
		case "not modified":
		case "o-pending":
		case "xmitted":
		case "sent to iifl":
		case "partly executed":
		case "sent to exch":
		case "waiting in q on exch link":
		case "placed":
		case "ah placed":
		case "partial":
		case "sent":
		case "slo":
		case "confirm":
		case "opn":
		case "client xmitted":
		case "gateway xmitted":
		case "oms xmitted":
		case "exchange xmitted":
		case "a.accept":
		case "new":
		case "acked":
		case "partiallyfilled":
		case "replaced":
		case "pendingreplace":
		case "part_traded":
		case "pendingnew":
		case "pendingcancel":
		case "a.modify":
		case "sl triggered": // Sl triggered is OPEN on IIFL
			return OPEN;
		case "complete":
		case "completed":
		case "traded":
		case "fullyexecuted":
		case "fully executed":
		case "trd":
		case "filled":
		case "executed":
		case "delivery_awaited":
			return COMPLETE;
		case "rejected":
		case "exchange rejected":
		case "rejected by iifl":
		case "rejected by exch":
		case "rejected by 5p":
		case "frozen":
		case "gateway reject":
		case "oms reject":
		case "order error":
		case "a.reject":
		case "error":
		case "failed":
			return REJECTED;
		case "cancelled":
		case "canceled":
		case "ah cancelled":
		case "cancelled amo":
		case "amo cancelled":
		case "cancelled after market order":
		case "o-cancelled":
		case "can":
		case "a.cancel":
		case "cancel":
		case "expired":
			return CANCELLED;
		case "trigger pending":
		case "trigger_pending":
		case "triggered":
			return TRIGGER_PENDING;
		}

		log.error("SD-ERR-007: Unknown OrderStatus. Raw: {}, Platform: {}, Order id: {}", type, platform, orderId);

		return UNKNOWN;
	}

	public static final OrderStatus fromXts(final String type, final String orderId) {
		return parse(type, "XTS", orderId);
	}

	public static final OrderStatus fromDhan(final String type, final String orderId) {
		return parse(type, "dhan", orderId);
	}

	public static final OrderStatus fromKite(final String type, final String orderId) {
		return parse(type, "kite", orderId);
	}

	public static final OrderStatus fromZebu(final String type, final String orderId) {
		return parse(type, "zebu", orderId);
	}

	public static final OrderStatus fromMastertrust(final String type, final String orderId) {
		return parse(type, "mastertrust", orderId);
	}

	public static final OrderStatus fromUpstox(final String type, final String orderId) {
		return parse(type, "upstox", orderId);
	}

	public static final OrderStatus fromScalpert(final String type, final String orderId) {
		return parse(type, "scalpert", orderId);
	}

	public static final OrderStatus fromAnt(final String type, final String orderId) {
		return parse(type, "ant", orderId);
	}

	public static final OrderStatus fromShoonya(final String type, final String orderId) {
		return parse(type, "shoonya", orderId);
	}

	public static final OrderStatus fromAngel(final String type, final String orderId) {
		return parse(type, "angel", orderId);
	}

	public static final OrderStatus fromIifl(final String type, final String orderId) {
		return parse(type, "iifl", orderId);
	}

	public static final OrderStatus fromProfitmart(final String type, final String orderId) {
		return parse(type, "profitmart", orderId);
	}

	public static final OrderStatus fromProfitmax(final String type, final String orderId) {
		return parse(type, "profitmax", orderId);
	}

	public static final OrderStatus fromKambala(final String type, final String orderId) {
		return parse(type, "kambala", orderId);
	}

	public static final OrderStatus fromEdelweiss(final String type, final String orderId) {
		return parse(type, "edelweiss", orderId);
	}

	public static final OrderStatus fromMotilal(final String type, final String orderId) {
		return parse(type, "motilal", orderId);
	}

	public static final OrderStatus fromKotak(final String type, final String orderId) {
		return parse(type, "kotak", orderId);
	}

	public static final OrderStatus fromKotakNeo(final String type, final String orderId) {
		return parse(type, "kotakNeo", orderId);
	}

	public static final OrderStatus fromChoice(final String type, final String orderId) {
		return parse(type, "choice", orderId);
	}

	public static final OrderStatus fromSas(final String type, final String orderId) {
		return parse(type, "sas", orderId);
	}

	public static final OrderStatus fromFyers(final int type) {
		switch (type) {
		case 4:
		case 6:
			return OPEN;
		case 2:
			return COMPLETE;
		case 5:
			return REJECTED;
		case 1:
			return CANCELLED;
		}

		log.error("SD-ERR-007: Unknown OrderStatus. Raw: {}, Platform: {}", type, "fyers");

		return UNKNOWN;
	}

}

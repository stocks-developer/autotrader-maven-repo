/**
 *
 */
package com.dakshata.constants.trading;

/**
 * Represents a trading operation result.
 *
 * @author PRITESH
 *
 */
public enum TradingOpResult {

	SUCCESS, FAILURE, PENDING

}

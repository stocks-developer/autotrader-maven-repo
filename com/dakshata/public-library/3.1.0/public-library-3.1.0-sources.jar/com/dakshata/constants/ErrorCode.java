package com.dakshata.constants;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Represents error codes. These new error code enum helps us to identify and
 * process an error.
 */
@AllArgsConstructor
@Getter
public enum ErrorCode {

	// @formatter:off
	MANUAL_LOGIN_NEEDED(1001, "Manual login is needed into your trading account."),
	INSUFFICIENT_WALLET_BALANCE(1002, "Insufficient balance in your wallet."),
	LICENSE_EXPIRED(1003, "License has expired."),
	SYSTEM_FORBIDDEN(1004, "Http 403: Forbidden. Our system denied access."),
	BROKER_AUTH_FAILED(1005, "Authorization failure given by broker."),
	BROKER_SESSION_EXPIRED(1006, "Broker session expired."),
	BROKER_SERVER_TIMEOUT(1007, "Broker's server timeout");
	// @formatter:on

	private final int code;
	private final String message;

	// Static map for quick lookup
	private static final Map<Integer, ErrorCode> CODE_MAP = Arrays.stream(values())
			.collect(Collectors.toMap(ErrorCode::getCode, Function.identity()));

	/**
	 * Retrieves an ErrorCode based on the numeric error code.
	 *
	 * @param code the error code
	 * @return the corresponding ErrorCode, or null if not found
	 */
	public static ErrorCode fromCode(final int code) {
		return CODE_MAP.getOrDefault(code, null);
	}

	@Override
	public String toString() {
		return String.format("ErrorCode[%d]: %s", this.code, this.message);
	}
}

/**
 *
 */
package com.dakshata.constants.trading;

/**
 * Specified the method to be used for order splitting.
 *
 * @author Pritesh Mhatre
 *
 */
public enum OrderSplitMethod {
	/**
	 * NO => Do not split the order
	 */
	NO,
	/**
	 * AUTO => Split the order automatically using quantity free limit
	 */
	AUTO,
	/**
	 * QTY => Split the order based on quantity specified by the user
	 */
	QTY
}

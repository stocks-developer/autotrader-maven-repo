/**
 *
 */
package com.dakshata.constants.instrument;

import java.util.HashSet;
import java.util.Set;

import lombok.extern.slf4j.Slf4j;

/**
 * Type of instrument.
 *
 * @author PRITESH
 *
 */
@Slf4j
public enum InstrumentType {

	EQ, FUT, OPT, INDEX, OTHER;

	private static final Set<Integer> acceptableFyersInstruments = new HashSet<>();

	static {
		acceptableFyersInstruments.add(0);
		acceptableFyersInstruments.add(4);
		acceptableFyersInstruments.add(9);
		acceptableFyersInstruments.add(10);
		acceptableFyersInstruments.add(11);
		acceptableFyersInstruments.add(12);
		acceptableFyersInstruments.add(13);
		acceptableFyersInstruments.add(14);
		acceptableFyersInstruments.add(15);
		acceptableFyersInstruments.add(16);
		acceptableFyersInstruments.add(19);
		acceptableFyersInstruments.add(30);
		acceptableFyersInstruments.add(31);
		acceptableFyersInstruments.add(50);
	}

	public static boolean isValidFyersInstrument(final Integer code) {
		return acceptableFyersInstruments.contains(code);
	}

	public static InstrumentType fromFyers(final int code) {
		switch (code) {
		case 0:
		case 4:
		case 9:
		case 50:
			return EQ;
		case 10:
			return INDEX;
		case 11:
		case 12:
		case 13:
		case 16:
		case 30:
			return FUT;
		case 14:
		case 15:
		case 31:
		case 19:
			return OPT;
		}

		log.error("SD-ERR-022: Cannot convert instrument type. Raw: {}", code);
		throw new RuntimeException("Invalid instrument type: " + code);
	}

	public final boolean isDerivative() {
		return (this == FUT) || (this == OPT);
	}

	public final boolean isOption() {
		return this == OPT;
	}

	public final boolean isFuture() {
		return this == FUT;
	}

	public final boolean isEquity() {
		return this == EQ;
	}

	public final boolean isIndex() {
		return this == INDEX;
	}

	public final boolean isOther() {
		return this == OTHER;
	}

}

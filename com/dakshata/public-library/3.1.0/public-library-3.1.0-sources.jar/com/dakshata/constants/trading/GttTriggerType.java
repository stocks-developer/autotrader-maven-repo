package com.dakshata.constants.trading;

/**
 * Trigger type for a GTT (Good Till Triggered) order.
 *
 * <ul>
 * <li>{@link #SINGLE} - one resting trigger leg (leg1).</li>
 * <li>{@link #OCO} - two legs (One-Cancels-Other): leg1 = target (trigger above
 * LTP) and leg2 = stop-loss (trigger below LTP); whichever fires first cancels
 * the other.</li>
 * </ul>
 *
 * @author PRITESH
 *
 */
public enum GttTriggerType {

	SINGLE, OCO;

}

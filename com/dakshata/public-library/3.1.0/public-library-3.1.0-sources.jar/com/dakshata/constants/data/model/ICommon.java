/**
 *
 */
package com.dakshata.constants.data.model;

/**
 * Common constants of data model project.
 *
 * @author PRITESH
 *
 */
public interface ICommon {
	/**
	 * Used for float comparison.
	 */
	float DELTA = 0.0001f;

	int UUID_LENGTH = 36;

	int DEFAULT_VARCHAR_LENGTH = 255;

	/**
	 * Columns which contain very small data, so we do not want to use default 255
	 * length.
	 */
	int MINI_VARCHAR_LENGTH = 15;

	/**
	 * Columns which contain small data, so we do not want to use default 255
	 * length.
	 */
	int SHORT_VARCHAR_LENGTH = 50;

	/**
	 * Columns which contain medium data, so we do not want to use default 255
	 * length.
	 */
	int MEDIUM_VARCHAR_LENGTH = 150;

}

package com.dakshata.constants.trading;

import java.util.Arrays;
import java.util.function.Function;

import lombok.extern.slf4j.Slf4j;

/**
 * Represents an order type (LIMIT, MARKET, STOP_LOSS, SL_MARKET).
 *
 * @author PRITESH
 *
 */
@Slf4j
public enum OrderType {

	LIMIT("l", "LIMIT", "LIMIT", "LIMIT", 1, "L", "LMT", "LIMIT", "LIMIT", "LIMIT", "L", "RL_LIMIT", "L", "LIMIT",
			"LMT", "LIMIT", "L", "Limit", "LMT", "LIMIT", "LIMIT"),
	MARKET("m", "MARKET", "MARKET", "MARKET", 2, "MKT", "MKT", "MARKET", "MARKET", "MARKET", "MKT", "RL_MKT", "MKT",
			"MARKET", "MKT", "MARKET", "MKT", "Market", "MKT", "MARKET", "MARKET"),
	STOP_LOSS("sl", "SL", "SL", "STOPLOSS_LIMIT", 4, "SL", "SL-LMT", "SL", "STOP_LIMIT", "STOPLOSS", "SL", "SL_LIMIT",
			"SL", "SL", "SL-LMT", "SL", "SL", "StopLimit", "SL-LMT", "STOP_LOSS", "SL"),
	SL_MARKET("sl-m", "SL-M", "SL-M", "STOPLOSS_MARKET", 3, "SL-M", "SL-MKT", "SLM", "STOP_MARKET", null, "SL-M",
			"SL_MKT", "SL-M", "SL-M", "SL-MKT", "SL-M", "SL-M", "StopMarket", "SL-MKT", "STOP_LOSS_MARKET", "SLM");

	private final String upstox, kite, ant, angel, profitmart, shoonya, mastertrust, edelweiss, motilal, a3, choice,
			zebu, sas, profitmax, upstoxApi, kotakNeo, xts, kambala, dhan, iiflMarkets;

	private final int fyers;

	OrderType(final String upstox, final String kite, final String ant, final String angel, final int fyers,
			final String profitmart, final String shoonya, final String mastertrust, final String edelweiss,
			final String motilal, final String a3, final String choice, final String zebu, final String sas,
			final String profitmax, final String upstoxApi, final String kotakNeo, final String xts,
			final String kambala, final String dhan, String iiflMarkets) {
		this.upstox = upstox;
		this.kite = kite;
		this.ant = ant;
		this.angel = angel;
		this.fyers = fyers;
		this.profitmart = profitmart;
		this.shoonya = shoonya;
		this.mastertrust = mastertrust;
		this.edelweiss = edelweiss;
		this.motilal = motilal;
		this.a3 = a3;
		this.choice = choice;
		this.zebu = zebu;
		this.sas = sas;
		this.profitmax = profitmax;
		this.upstoxApi = upstoxApi;
		this.kotakNeo = kotakNeo;
		this.xts = xts;
		this.kambala = kambala;
		this.dhan = dhan;
		this.iiflMarkets = iiflMarkets;
	}

	/**
	 * Calculates the correct order type based on the provided parameters. Fixes
	 * broker inconsistencies where LIMIT might be sent for STOP_LOSS/SL_MARKET
	 * orders.
	 *
	 * @param originalOrderType The original order type received from the platform.
	 * @param price             The order price.
	 * @param triggerPrice      The trigger price.
	 * @return The corrected OrderType.
	 */
	public static OrderType calculateCorrectOrderType(OrderType originalOrderType, Float price, Float triggerPrice) {
		final boolean hasTriggerPrice = (triggerPrice != null) && (triggerPrice > 0.0f);
		final boolean hasPrice = (price != null) && (price > 0.0f);

		if (hasTriggerPrice) {
			// If a trigger price is present, it must be a Stop-Loss order.
			return hasPrice ? OrderType.STOP_LOSS : OrderType.SL_MARKET;
		} else // If there's no trigger price, it cannot be a Stop-Loss order.
		// Correct it if the broker wrongly marked a normal order as a Stop-Loss.
		if ((originalOrderType == OrderType.STOP_LOSS) || (originalOrderType == OrderType.SL_MARKET)) {
			return hasPrice ? OrderType.LIMIT : OrderType.MARKET;
		}

		return originalOrderType;
	}

	/**
	 * This should be the standard method going forward.
	 */
	public static OrderType parse(final String rawType, TradingPlatform platform) {
		if (rawType != null) {

			switch (rawType.toUpperCase()) {
			case "LIMIT":
			case "OCO_LIMIT":
				return LIMIT;
			case "MARKET":
			case "MKT":
				return MARKET;
			case "SL":
			case "SL-LMT":
			case "STOPLOSS":
			case "STOP_LIMIT":
			case "STOPLOSS_LIMIT":
				return STOP_LOSS;
			case "SLM":
			case "SL-M":
			case "SL-MKT":
			case "STOP_MARKET":
			case "STOPLOSS_MARKET":
				return SL_MARKET;
			}
		}

		log.error("SD-ERR-008: Unknown OrderType. Raw: {}, Platform: {}", rawType, platform);
		return null;
	}

	public static OrderType fromFyers(final int type) {
		for (final OrderType t : OrderType.values()) {
			if (type == t.fyers) {
				return t;
			}
		}

		log.error("SD-ERR-008: Unknown OrderType. Raw: {}, Platform: {}", type, "fyers");
		return null;
	}

	public static OrderType fromXts(final String type) {
		return from(type, ot -> ot.xts, "xts");
	}

	public static OrderType fromDhan(final String type) {
		return from(type, ot -> ot.dhan, "dhan");
	}

	public static OrderType fromAngel(final String type) {
		return from(type, ot -> ot.angel, "angel");
	}

	public static OrderType fromZebu(final String type) {
		return from(type, ot -> ot.zebu, "zebu");
	}

	public static OrderType fromUpstox(final String type) {
		return from(type, ot -> ot.upstox, "upstox");
	}

	public static OrderType fromUpstoxApi(final String type) {
		return from(type, ot -> ot.upstoxApi, "upstox-api");
	}

	public static OrderType fromKite(final String type) {
		return from(type, ot -> ot.kite, "kite");
	}

	public static OrderType fromAnt(final String type) {
		return from(type, ot -> ot.ant, "ant");
	}

	public static OrderType fromA3(final String type) {
		return from(type, ot -> ot.a3, "a3");
	}

	public static OrderType fromKotakNeo(final String type) {
		return from(type, ot -> ot.kotakNeo, "kotakNeo");
	}

	public static OrderType fromProfitmart(final String type) {
		return from(type, ot -> ot.profitmart, "profitmart");
	}

	public static OrderType fromProfitmax(final String type) {
		return from(type, ot -> ot.profitmax, "profitmax");
	}

	public static OrderType fromKambala(final String type) {
		return from(type, ot -> ot.kambala, "kambala");
	}

	public static OrderType fromShoonya(final String type) {
		return from(type, ot -> ot.shoonya, "shoonya");
	}

	public static OrderType fromChoice(final String type) {
		return from(type, ot -> ot.choice, "choice");
	}

	public static OrderType fromSas(final String type) {
		return from(type, ot -> ot.sas, "sas");
	}

	public static OrderType fromMastertrust(final String type) {
		if ("SL-M".equalsIgnoreCase(type)) {
			return SL_MARKET;
		}
		if ("M".equalsIgnoreCase(type)) {
			return MARKET;
		}

		return from(type, ot -> ot.mastertrust, "mastertrust");
	}

	public static OrderType fromEdelweiss(final String type) {
		if ("SL-M".equalsIgnoreCase(type)) {
			return SL_MARKET;
		}
		if ("SL".equalsIgnoreCase(type)) {
			return STOP_LOSS;
		}

		return from(type, ot -> ot.edelweiss, "edelweiss");
	}

	public static OrderType fromMotilal(final String type) {
		return from(type, ot -> ot.motilal, "motilal");
	}

	public String toXts() {
		return this.xts;
	}

	public String toUpstox() {
		return this.upstox;
	}

	public String toUpstoxApi() {
		return this.upstoxApi;
	}

	public String toKite() {
		return this.kite;
	}

	public String toAnt() {
		return this.ant;
	}

	public String toA3() {
		return this.a3;
	}

	public String toKotakNeo() {
		return this.kotakNeo;
	}

	public String toShoonya() {
		return this.shoonya;
	}

	public String toAngel() {
		return this.angel;
	}

	public String toProfitmart() {
		return this.profitmart;
	}

	public String toProfitmax() {
		return this.profitmax;
	}

	public String toKambala() {
		return this.kambala;
	}

	public String toMastertrust() {
		return this.mastertrust;
	}

	public String toEdelweiss() {
		return this.edelweiss;
	}

	public String toMotilal() {
		return this.motilal;
	}

	public String toChoice() {
		return this.choice;
	}

	public String toZebu() {
		return this.zebu;
	}

	public String toDhan() {
		return this.dhan;
	}

	public String toSas() {
		return this.sas;
	}

	public String toIiflMarkets() {
		return this.iiflMarkets;
	}

	public int toFyers() {
		return this.fyers;
	}

	public boolean isSLOrSLM() {
		return (this == STOP_LOSS) || (this == SL_MARKET);
	}

	private static OrderType from(final String type, final Function<OrderType, String> fun, final String platform) {
		if (type == null) {
			return null;
		}

		final String t = type.trim();
		final OrderType orderType = Arrays.stream(OrderType.values()).filter(ot -> {
			final String result = fun.apply(ot);
			return (result == null) ? false : result.equalsIgnoreCase(t);
		}).findAny().orElse(null);

		if (orderType == null) {
			log.error("SD-ERR-008: Unknown OrderType. Raw: {}, Platform: {}", type, platform);
		}

		return orderType;
	}

}

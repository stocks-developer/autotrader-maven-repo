package com.dakshata.constants.trading;

import java.util.EnumSet;
import java.util.Set;

import com.dakshata.constants.instrument.Source;

import lombok.Getter;

/**
 * Enum representing various trading platforms.
 */
@Getter
public enum TradingPlatform {

    // @formatter:off
    ALICE_API(Source.ALICEBLUE, "AliceBlue"),
    ALICE_API_IPV6(Source.ALICEBLUE, "AliceBlue", TradingPlatformFeature.IPV6),
    ALICE_API_V2_IPV6(Source.ALICEBLUE, "AliceBlue", TradingPlatformFeature.IPV6),
    BREEZE_API(Source.ICICI, "ICICI"),
    CHOICE_API(Source.CHOICE, "Choice"),
    CHOICE_API_IPV6(Source.CHOICE, "Choice", TradingPlatformFeature.IPV6),
    CHOICE_API_TOTP(Source.CHOICE, "Choice"),
    DHAN(Source.DHAN, "Dhan"),
    DHAN_V2(Source.DHAN, "Dhan"),
    DHAN_V2_IPV6(Source.DHAN, "Dhan", TradingPlatformFeature.IPV6),
    DHAN_V2_AT_IPV6(Source.DHAN, "Dhan", TradingPlatformFeature.IPV6),
    EDELWEISS(Source.EDELWEISS, "Edelweiss"),
    FP_API(Source.FIVE_PAISA, "5Paisa"),
    FP_API_TOTP(Source.FIVE_PAISA, "5Paisa"),
    FP_API_IPV6(Source.FIVE_PAISA, "5Paisa", TradingPlatformFeature.IPV6),
    FYERS_API(Source.FYERS, "Fyers", TradingPlatformFeature.MPP),
    FYERS_API_IPV6(Source.FYERS, "Fyers", TradingPlatformFeature.IPV6, TradingPlatformFeature.MPP),
    GROWW_API_IPV6(Source.GROWW, "Groww", TradingPlatformFeature.IPV6),
    HDFC_SEC(Source.HDFC_SEC, "HDFC Securities"),
    ICICI(Source.ICICI, "ICICI"),
    IIFL_API(Source.IIFL, "IIFL"),
    IIFL_MARKETS_API(Source.IIFL_MARKETS, "IIFL", TradingPlatformFeature.MPP),
    IIFL_MKT_API_IPV6(Source.IIFL_MARKETS, "IIFL", TradingPlatformFeature.IPV6, TradingPlatformFeature.MPP),
    IIFL_MARKETS_API_M(Source.IIFL_MARKETS, "IIFL", TradingPlatformFeature.OAUTH, TradingPlatformFeature.MPP),
    IIFL_MKT_API_M_IPV6(Source.IIFL_MARKETS, "IIFL", TradingPlatformFeature.OAUTH, TradingPlatformFeature.IPV6, TradingPlatformFeature.MPP),
    KITE(Source.ZERODHA, "Zerodha"),
    KITE_IPV6(Source.ZERODHA, "Zerodha", TradingPlatformFeature.IPV6),
    KOTAK_NEO(Source.KOTAK_NEO, "Kotak"),
    KOTAK_NEO_TOTP(Source.KOTAK_NEO, "Kotak", TradingPlatformFeature.LOGIN_ID_CAPS),
    KOTAK_NEO_IPV6(Source.KOTAK_NEO, "Kotak", TradingPlatformFeature.LOGIN_ID_CAPS, TradingPlatformFeature.IPV6),
    MASTERTRUST(Source.MASTERTRUST, "Mastertrust"),
    MASTERTRUST_IPV6(Source.MASTERTRUST, "Mastertrust", TradingPlatformFeature.IPV6),
    MOTILAL_API(Source.MOTILAL_OSWAL, "Motilal"),
    MOTILAL_API_IPV4(Source.MOTILAL_OSWAL, "Motilal"),
    MOTILAL_API_M(Source.MOTILAL_OSWAL, "Motilal", TradingPlatformFeature.OAUTH),
    MOTILAL_API_V7(Source.MOTILAL_OSWAL, "Motilal"),
    MSTOCK_API(Source.MSTOCK, "MStock"),
    MYNT_API(Source.ZEBU, "Zebu", TradingPlatformFeature.KAMBALA),
    MYNT_API_IPV4(Source.ZEBU, "Zebu", TradingPlatformFeature.KAMBALA),
    NUVAMA(Source.EDELWEISS, "Nuvama"),
    NUVAMA_RETAIL(Source.EDELWEISS, "Nuvama"),
    NUVAMA_RETAIL_IPV6(Source.EDELWEISS, "Nuvama", TradingPlatformFeature.IPV6),
    PROFITMART(Source.PROFITMART, "Profitmart"),
    PROFITMAX(Source.PROFITMAX, "Profitmart"),
    SAS(Source.SAS, "SAS"),
    SAS_API(Source.SAS, "SAS"),
    SAS_STOCKO_API(Source.SAS, "SAS"),
    SAS_STOCKO_API_IPV6(Source.SAS, "SAS", TradingPlatformFeature.IPV6),
    SHAREKHAN_API(Source.SHAREKHAN, "Sharekhan"),
    SHAREKHAN_API_M(Source.SHAREKHAN, "Sharekhan", TradingPlatformFeature.OAUTH),
    SHOONYA_BETA(Source.FINVASIA, "Finvasia"),
    SHOONYA_BETA_IPV6(Source.FINVASIA, "Finvasia", TradingPlatformFeature.IPV6),
    SHOONYA_OTP(Source.FINVASIA, "Finvasia"),
    SMART_API(Source.ANGEL, "Angel One"),
    SMART_API_IPV6(Source.ANGEL, "Angel One", TradingPlatformFeature.IPV6),
    SMART_API_M(Source.ANGEL, "Angel One", TradingPlatformFeature.OAUTH),
    SMART_API_M_IPV6(Source.ANGEL, "Angel One", TradingPlatformFeature.OAUTH, TradingPlatformFeature.IPV6),
    UPSTOX(Source.UPSTOX_API, "Upstox", TradingPlatformFeature.OAUTH),
    UPSTOX_API(Source.UPSTOX_API, "Upstox"),
    UPSTOX_API_IPV6(Source.UPSTOX_API, "Upstox", TradingPlatformFeature.OAUTH, TradingPlatformFeature.IPV6),
    UPSTOX_API_AT_IPV6(Source.UPSTOX_API, "Upstox", TradingPlatformFeature.IPV6),
    ZEBULL(Source.ZEBULL, "Zebu"),
    ZERODHA_API(Source.ZERODHA, "Zerodha", TradingPlatformFeature.MPP),
    ZERODHA_API_IPV6(Source.ZERODHA, "Zerodha", TradingPlatformFeature.IPV6, TradingPlatformFeature.MPP),
    ZERODHA_API_M(Source.ZERODHA, "Zerodha", TradingPlatformFeature.OAUTH, TradingPlatformFeature.MPP),
    ZERODHA_API_M_IPV6(Source.ZERODHA, "Zerodha", TradingPlatformFeature.OAUTH, TradingPlatformFeature.IPV6, TradingPlatformFeature.MPP),

    // XTS Platforms
    XTS_AETRAM(Source.XTS_AETRAM, "AETRAM", TradingPlatformFeature.XTS),
    XTS_AGARWAL(Source.XTS_AGARWAL, "AC Agarwal", TradingPlatformFeature.XTS),
    XTS_AMBALAL(Source.XTS_AMBALAL, "Ambalal", TradingPlatformFeature.XTS),
    XTS_ARHAM(Source.XTS_ARHAM, "ARHAM", TradingPlatformFeature.XTS),
    XTS_ANAND_RATHI(Source.ANAND_RATHI, "Anand Rathi", TradingPlatformFeature.XTS),
    XTS_ATS(Source.XTS_ATS, "ATS", TradingPlatformFeature.XTS),
    XTS_AXIS(Source.XTS_AXIS, "Axis", TradingPlatformFeature.XTS),
    XTS_BONANZA(Source.XTS_BONANZA, "Bonanza", TradingPlatformFeature.XTS),
    XTS_CHOICE(Source.XTS_CHOICE, "Choice", TradingPlatformFeature.XTS),
    XTS_DBONLINE(Source.XTS_DBONLINE, "DBOnline", TradingPlatformFeature.XTS),
    XTS_EUREKA(Source.XTS_EUREKA, "Eureka", TradingPlatformFeature.XTS),
    XTS_EUREKA_PROP(Source.XTS_EUREKA, "Eureka - PROP", TradingPlatformFeature.XTS),
    XTS_FIVE_PAISA(Source.XTS_FIVE_PAISA, "5Paisa", TradingPlatformFeature.XTS),
    XTS_IIFL(Source.XTS_IIFL, "IIFL", TradingPlatformFeature.XTS),
    XTS_IIFL_TOTP(Source.XTS_IIFL, "IIFL", TradingPlatformFeature.XTS),
    XTS_JAINAM(Source.XTS_JAINAM, "Jainam", TradingPlatformFeature.XTS),
    XTS_JAINAM_PROP_A(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS),
    XTS_JAINAM_PROP_B(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS),
    XTS_JAINAM_PROP_C(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS),
    XTS_JAINAM_PROP_D(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS),
    XTS_MLB(Source.XTS_MLB, "MLB", TradingPlatformFeature.XTS),
    XTS_MOTILAL(Source.XTS_MOTILAL, "Motilal Oswal", TradingPlatformFeature.XTS),
    XTS_NIRMAL(Source.XTS_NIRMAL, "Nirmal Bang", TradingPlatformFeature.XTS),
    XTS_PESB(Source.XTS_PESB, "PESB", TradingPlatformFeature.XTS),
    XTS_RELIGARE(Source.XTS_RELIGARE, "Religare", TradingPlatformFeature.XTS),
    XTS_RMONEY(Source.XTS_RMONEY, "Rmoney", TradingPlatformFeature.XTS),
    XTS_SHARE_IND(Source.XTS_SHARE_IND, "Share India", TradingPlatformFeature.XTS),
    XTS_SHARE_IND_PROP(Source.XTS_SHARE_IND, "Share India - PROP", TradingPlatformFeature.XTS),
    XTS_SHARE_IND_PROP_M(Source.XTS_SHARE_IND, "Share India - PROP", TradingPlatformFeature.XTS),
    XTS_SMC(Source.XTS_SMC, "SMC", TradingPlatformFeature.XTS),
    XTS_SW_CAPITAL(Source.XTS_SW_CAPITAL, "SW Capital", TradingPlatformFeature.XTS),
    XTS_TSWIFT(Source.XTS_TSWIFT, "Tradeswift", TradingPlatformFeature.XTS),
    XTS_WISDOM(Source.XTS_WISDOM, "WisdomCapital", TradingPlatformFeature.XTS),
    XTS_ZEBU(Source.XTS_ZEBU, "Zebu", TradingPlatformFeature.XTS),

    XTS_AETRAM_IPV6(Source.XTS_AETRAM, "AETRAM", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_AGARWAL_IPV6(Source.XTS_AGARWAL, "AC Agarwal", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_AMBALAL_IPV6(Source.XTS_AMBALAL, "Ambalal", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_ARHAM_IPV6(Source.XTS_ARHAM, "ARHAM", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_A_RATHI_IPV6(Source.ANAND_RATHI, "Anand Rathi", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_ATS_IPV6(Source.XTS_ATS, "ATS", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_AXIS_IPV6(Source.XTS_AXIS, "Axis", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_BONANZA_IPV6(Source.XTS_BONANZA, "Bonanza", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_CHOICE_IPV6(Source.XTS_CHOICE, "Choice", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_DBONLINE_IPV6(Source.XTS_DBONLINE, "DBOnline", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_EUREKA_IPV6(Source.XTS_EUREKA, "Eureka", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_EUREKA_PRO_IPV6(Source.XTS_EUREKA, "Eureka - PROP", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_FIVE_PAISA_IPV6(Source.XTS_FIVE_PAISA, "5Paisa", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_IIFL_IPV6(Source.XTS_IIFL, "IIFL", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_JAINAM_IPV6(Source.XTS_JAINAM, "Jainam", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_JAIN_PRO_A_IPV6(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_JAIN_PRO_B_IPV6(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_JAIN_PRO_C_IPV6(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_JAIN_PRO_D_IPV6(Source.XTS_JAINAM, "Jainam - PROP", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_MLB_IPV6(Source.XTS_MLB, "MLB", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_MOTILAL_IPV6(Source.XTS_MOTILAL, "Motilal Oswal", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_NIRMAL_IPV6(Source.XTS_NIRMAL, "Nirmal Bang", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_PESB_IPV6(Source.XTS_PESB, "PESB", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_RELIGARE_IPV6(Source.XTS_RELIGARE, "Religare", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_RMONEY_IPV6(Source.XTS_RMONEY, "Rmoney", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_SHARE_IND_IPV6(Source.XTS_SHARE_IND, "Share India", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_SHIND_PRO_IPV6(Source.XTS_SHARE_IND, "Share India - PROP", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_SHIND_PRO_M_IPV6(Source.XTS_SHARE_IND, "Share India - PROP", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_SMC_IPV6(Source.XTS_SMC, "SMC", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_SW_CAPITAL_IPV6(Source.XTS_SW_CAPITAL, "SW Capital", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_TSWIFT_IPV6(Source.XTS_TSWIFT, "Tradeswift", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_WISDOM_IPV6(Source.XTS_WISDOM, "WisdomCapital", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),
    XTS_ZEBU_IPV6(Source.XTS_ZEBU, "Zebu", TradingPlatformFeature.XTS, TradingPlatformFeature.IPV6),

    // KAMBALA Platforms
    KAMBALA_FLATTRADE(Source.KAMBALA_FLATTRADE, "Flattrade", TradingPlatformFeature.KAMBALA),
    KAMBALA_FINVASIA(Source.FINVASIA, "Finvasia", TradingPlatformFeature.KAMBALA),
    KAMBALA_PLINDIA(Source.KAMBALA_PLINDIA, "Prabhudas Lilladher", TradingPlatformFeature.KAMBALA),
    KAMBALA_PROFITMART(Source.KAMBALA_PROFITMART, "Profitmart", TradingPlatformFeature.KAMBALA),
    KAMBALA_TRADEJINI(Source.KAMBALA_TRADEJINI, "Tradejini", TradingPlatformFeature.KAMBALA),

    KAMBALA_FLAT_IPV4(Source.KAMBALA_FLATTRADE, "Flattrade", TradingPlatformFeature.KAMBALA),
    KAMBALA_FLAT_IPV6(Source.KAMBALA_FLATTRADE, "Flattrade", TradingPlatformFeature.KAMBALA, TradingPlatformFeature.IPV6),
    KAMBALA_FIN_IPV4(Source.FINVASIA, "Finvasia", TradingPlatformFeature.KAMBALA),
    KAMBALA_PL_IPV4(Source.KAMBALA_PLINDIA, "Prabhudas Lilladher", TradingPlatformFeature.KAMBALA),
    KAMBALA_PROFIT_IPV4(Source.KAMBALA_PROFITMART, "Profitmart", TradingPlatformFeature.KAMBALA),
    KAMBALA_TJINI_IPV4(Source.KAMBALA_TRADEJINI, "Tradejini", TradingPlatformFeature.KAMBALA);
    // @formatter:on

    private final Source source;
    private final String brokerName;
    private final Set<TradingPlatformFeature> features;

    TradingPlatform(final Source source, final String brokerName, final TradingPlatformFeature... features) {
        this.source = source;
        this.brokerName = brokerName;
        this.features = features.length > 0 ? EnumSet.of(features[0], features)
                : EnumSet.noneOf(TradingPlatformFeature.class);
    }

    public boolean hasFeature(final TradingPlatformFeature feature) {
        return this.features.contains(feature);
    }

    public boolean isXts() {
        return this.features.contains(TradingPlatformFeature.XTS);
    }

    public boolean isKambala() {
        return this.features.contains(TradingPlatformFeature.KAMBALA);
    }

    public boolean isOAuth() {
        return this.features.contains(TradingPlatformFeature.OAUTH);
    }

    public boolean isLoginIdCaps() {
        return this.features.contains(TradingPlatformFeature.LOGIN_ID_CAPS);
    }

    public boolean isIpv6() {
        return this.features.contains(TradingPlatformFeature.IPV6);
    }

    public boolean isMpp() {
        return this.features.contains(TradingPlatformFeature.MPP);
    }
}

enum TradingPlatformFeature {
    XTS, KAMBALA, OAUTH, LOGIN_ID_CAPS, IPV6, MPP
}

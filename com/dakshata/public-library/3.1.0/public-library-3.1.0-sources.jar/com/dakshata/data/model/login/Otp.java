/**
 *
 */
package com.dakshata.data.model.login;

import static java.lang.System.currentTimeMillis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Model object for storing OTP information.
 *
 * @author PRITESH
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@EqualsAndHashCode
public class Otp {

	private String loginId;

	private String otp;

	@Builder.Default
	private Long receivedTime = currentTimeMillis();

}

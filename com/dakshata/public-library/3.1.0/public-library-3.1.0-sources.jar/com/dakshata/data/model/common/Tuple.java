/**
 *
 */
package com.dakshata.data.model.common;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * A tuple to hold two objects.
 *
 * @author PRITESH
 *
 */
@Getter
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Tuple<A, B> implements Serializable {

	private static final long serialVersionUID = -7913949493009711184L;

	protected A a;

	protected B b;

}

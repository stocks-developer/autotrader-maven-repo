/**
 * All model classes that serve a common purpose or that cannot be classified
 * into a specific category.
 * 
 * @author PRITESH
 *
 */
package com.dakshata.data.model.common;
/**
 *
 */
package com.dakshata.data.model.autotrader.web;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

/**
 * A key for a holdings row.
 *
 * @author PRITESH
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class HoldingRecord implements Serializable {

	private static final long serialVersionUID = 343098292568881340L;

	private String pseudoAccount;

	private String symbol, nseSymbol, bseSymbol;

	private Integer quantity, t1Qty;

	public int getTotalQuantity() {
		int qty = ((this.getQuantity() != null) && (this.getQuantity() > 0)) ? this.getQuantity() : 0;
		int t1Qty = ((this.getT1Qty() != null) && (this.getT1Qty() > 0)) ? this.getT1Qty() : 0;
		return qty + t1Qty;
	}

	public String toString() {
		return String.format("Holding [%s, %s | NSE => %s | BSE => %s, Total Qty: %d, Qty: %d, T1Qty: %d]",
				pseudoAccount, symbol, nseSymbol, bseSymbol, getTotalQuantity(), quantity, t1Qty);
	}

}

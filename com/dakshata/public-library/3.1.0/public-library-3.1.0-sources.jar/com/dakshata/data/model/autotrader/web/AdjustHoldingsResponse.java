package com.dakshata.data.model.autotrader.web;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class AdjustHoldingsResponse implements Serializable {

	private static final long serialVersionUID = 6547655917800947297L;

	private String pseudoAccount;

	private String exchange;

	private String symbol;

	private String result;
	
	private Boolean success;

}

/**
 *
 */
package com.dakshata.data.model.login;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Represents trading accounts of the user for which we are going to receive
 * OTP.
 *
 * @author PRITESH
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@EqualsAndHashCode
public class OtpAccount {

	private String loginId, broker, phone;

    public String toCsv() {
        return String.join(",", loginId, broker, phone);
    }

    public String toString() {
        return broker + " : " + loginId;
    }
    
}

/**
 *
 */
package com.dakshata.data.model.autotrader.service;

/**
 * This model is used for sending Trading account data to outside world.<br>
 * This model should not contain any sensitive information.
 *
 * @author Pritesh Mhatre
 *
 */
public interface ITradingAccountPublic {

	/**
	 * Internal system id given to the trading account by AutoTrader Web.
	 */
	Long getSystemId();

	/**
	 * Internal system id given to the pseudo account by AutoTrader Web. The pseudo
	 * account that is mapped to this trading account. If there is no mapping, you
	 * will get null.
	 */
	Long getSystemIdOfPseudoAcc();

	/**
	 * Trading account login id.
	 */
	String getLoginId();

	/**
	 * Returns the name of the pseudo account that is mapped to this trading
	 * account. If there is no mapping, you will get null.
	 */
	String getPseudoAccName();

	/**
	 * Tells you whether the trading account is live or not. For an account to be
	 * live, it must be mapped to a pseudo account, otherwise you will get null.
	 */
	Boolean isLive();

	/**
	 * Name of stock broker.
	 */
	String getBroker();

	/**
	 * Name of trading platform being used.
	 */
	String getPlatform();

	/**
	 * Returns the number of days left on the license.
	 */
	Integer getLicenseDaysLeft();

	/**
	 * License expiry date in DD-MMM-YYYY format.
	 */
	String getLicenseExpiryDate();

}

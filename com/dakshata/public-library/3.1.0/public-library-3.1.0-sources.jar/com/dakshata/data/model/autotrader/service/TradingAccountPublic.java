/**
 *
 */
package com.dakshata.data.model.autotrader.service;

import lombok.Builder;
import lombok.Data;

/**
 * This model is used for sending Trading account data to outside world.<br>
 * This model should not contain any sensitive information.
 *
 * @author Pritesh Mhatre
 *
 */
@Data
@Builder
public class TradingAccountPublic implements ITradingAccountPublic {

	private String loginId, pseudoAccName, broker, platform, licenseExpiryDate;

	private Boolean live;

	private Long systemId, systemIdOfPseudoAcc;

	private Integer licenseDaysLeft;

	@Override
	public Boolean isLive() {
		return this.live;
	}

}

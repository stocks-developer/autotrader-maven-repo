/**
 *
 */
package com.dakshata.data.model.activity;

/**
 * An interface to retrieve model id from the model.
 *
 * @author PRITESH
 *
 */
public interface ISupportsModelActivity {

	String activityModelId();

}

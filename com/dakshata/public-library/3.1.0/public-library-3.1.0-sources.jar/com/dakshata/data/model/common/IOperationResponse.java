/**
 *
 */
package com.dakshata.data.model.common;

import com.dakshata.constants.ErrorCode;

/**
 * A typical response for an operation.
 *
 * @author PRITESH
 *
 */
public interface IOperationResponse<T> {

	/**
	 * Result of the operation.
	 */
	T getResult();

	/**
	 * Exception if it occurred, otherwise <code>null</code>
	 */
	Exception getError();

	/**
	 * Any message that may describe operation execution in short. It might be
	 * useful to give an explanation to the user.
	 */
	String getMessage();

	/**
	 * A true value indicates success, otherwise failure.
	 */
	boolean success();

	/**
	 * Operations are executed as commands and they have a command id.
	 */
	String getCommandId();

	/**
	 * This function is useful for sending this object over Internet where we do not
	 * want to carry Exception as it is a heavy object;
	 *
	 * @return compact version of this object
	 */
	IOperationResponse<T> compact();

	/**
	 * Gets the error code. These new error code enum helps us to identify and
	 * process an error.
	 *
	 * @return error code
	 */
	ErrorCode getErrorCode();

	/**
	 * Returns a copy of this response with the new error code applied.
	 *
	 * @param errorCode error code
	 */
	OperationResponse<T> copyWithErrorCode(final ErrorCode errorCode);

	/**
	 * Time taken (milliseconds) for the broker call that produced this response, or
	 * <code>null</code> when not measured. Used to display "time taken to place
	 * order(s)" on the UI.
	 */
	Long getBrokerCallMillis();
}

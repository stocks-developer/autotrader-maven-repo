/**
 *
 */
package com.dakshata.data.model.autotrader.web;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.dakshata.constants.trading.OrderType;
import com.dakshata.constants.trading.TradeType;

import lombok.Data;

/**
 * Represents a data of for the selling or adding to holdings.
 *
 * @author PRITESH
 *
 */
@Data
public class AdjustHoldingsRequest implements Serializable {

	private static final long serialVersionUID = -7291871966561107044L;

	private TradeType tradeType;
	
	private String exchange;
	
	private OrderType orderType;
	
	private Integer quantity;
	
	private String quantityType;
	
	private Float price, triggerPrice;

	/**
	 * Disclosed quantity expressed as a percentage of the order quantity.
	 * Allowed: 0 (no disclosure) or 10-100. Applied only for LIMIT and STOP_LOSS
	 * orders. Below the exchange minimum is auto-clamped on the server.
	 */
	private Integer disclosedQtyPct;

	private List<HoldingRecord> holdings = new ArrayList<>();
	
}

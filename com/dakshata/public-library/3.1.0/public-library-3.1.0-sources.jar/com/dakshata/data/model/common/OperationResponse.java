package com.dakshata.data.model.common;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

import com.dakshata.constants.ErrorCode;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Builder;
import lombok.Getter;

/**
 * A typical operation response.
 *
 * @author PRITESH
 *
 */
@Getter
@Builder(toBuilder = true)
public class OperationResponse<T> implements IOperationResponse<T> {

	public static final OperationResponse<Boolean> SUCCESS = OperationResponse.<Boolean>builder().result(TRUE).build();

	public static final OperationResponse<Boolean> FAILURE = OperationResponse.<Boolean>builder().result(FALSE).build();

	private final T result;

	// HttpClientErrorException object gives "Direct self-reference leading to
	// cycle" error during json serialization (hence ignored)
	@JsonIgnore
	@Builder.Default
	private Exception error = null;

	private final String message;

	private final Boolean status;

	private final String commandId;

	private final ErrorCode errorCode;

	/**
	 * Time taken (milliseconds) for the broker call that produced this response,
	 * i.e. from the moment the place/modify/cancel request was sent to the broker
	 * until its response was received. Populated by the trading app via the generic
	 * broker-call timer; <code>null</code> when not measured. Carried over the wire
	 * so callers (e.g. the at-web Trade screen) can display "time taken to place
	 * order(s)" without a second lookup. Mutable so it can be attached after the
	 * response is built.
	 */
	private Long brokerCallMillis;

	/**
	 * Default constructor is needed during json deserialization.
	 */
	public OperationResponse() {
		this.status = false;
		this.result = null;
		this.message = null;
		this.commandId = null;
		this.errorCode = null;
	}

	public OperationResponse(final T result, final Exception error, final String message, final Boolean status,
			final String commandId, final ErrorCode errorCode, final Long brokerCallMillis) {
		this.result = result;
		this.error = error;
		this.errorCode = errorCode;
		this.status = (status == null) ? (error == null) : status;
		this.commandId = commandId;
		this.brokerCallMillis = brokerCallMillis;

		if (message != null) {
			this.message = message;
		} else if (error != null) {
			if (error.getMessage() != null) {
				this.message = error.getMessage();
			} else {
				this.message = error.getClass().getSimpleName();
			}
		} else {
			this.message = null;
		}
	}

	public OperationResponse(final T result, final Exception error, final String message, final Boolean status,
			final String commandId, final ErrorCode errorCode) {
		this(result, error, message, status, commandId, errorCode, null);
	}

	public OperationResponse(final T result, final Exception error, final String message, final Boolean status,
			final String commandId) {
		this(result, error, message, status, commandId, null, null);
	}

	public static OperationResponse<?> prepareError(final Exception error, final String message,
			final ErrorCode errorCode) {
		return new OperationResponse<Object>(null, error, message, null, null, errorCode, null);
	}

	/**
	 * Attaches the measured broker-call duration (ms) to this response.
	 */
	public void setBrokerCallMillis(final Long brokerCallMillis) {
		this.brokerCallMillis = brokerCallMillis;
	}

	@Override
	public boolean success() {
		return this.status;
	}

	@Override
	public ErrorCode getErrorCode() {
		return this.errorCode;
	}

	/**
	 * This function is useful for sending this object over Internet where we do not
	 * want to carry Exception as it is a heavy object;
	 *
	 * @return compact version of this object
	 */
	@Override
	public OperationResponse<T> compact() {
		this.error = null;
		return this;
	}

	@Override
	public OperationResponse<T> copyWithErrorCode(final ErrorCode errorCode) {
		return new OperationResponse<T>(this.result, this.error, this.message, this.status, this.commandId, errorCode);
	}

	@Override
	public String toString() {
		String pretty = null;
		if (this.status) {
			pretty = String.format("[SUCCESS - %s]", this.result);
		} else {
			pretty = String.format("[FAILURE - %s]", this.message);
		}
		return pretty;
	}

}

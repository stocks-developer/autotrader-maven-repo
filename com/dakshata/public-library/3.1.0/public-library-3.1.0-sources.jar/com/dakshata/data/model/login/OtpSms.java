/**
 *
 */
package com.dakshata.data.model.login;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Responsible for sending OTP sms to our website.
 *
 * @author PRITESH
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@EqualsAndHashCode
public class OtpSms {

	private String sender;
	
	private String sms;
	
	private List<OtpAccount> accounts;
	
}

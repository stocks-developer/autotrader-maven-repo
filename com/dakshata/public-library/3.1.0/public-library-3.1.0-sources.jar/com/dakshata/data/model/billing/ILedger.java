/**
 *
 */
package com.dakshata.data.model.billing;

/**
 * Marks to model as ledger.
 *
 * @author PRITESH
 *
 */
public interface ILedger {

	String ledgerKey();

}

/**
 *
 */
package com.dakshata.data.model.login;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Model object for storing OTP received on email.
 *
 * @author PRITESH
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@EqualsAndHashCode
public class OtpEmail {

	private String from;

	private String to;

	private String subject;

	private String body;

}

/**
 *
 */
package com.dakshata.trading.model.portfolio;

import static java.time.temporal.ChronoUnit.MILLIS;
import static java.util.concurrent.ConcurrentHashMap.newKeySet;

import java.time.LocalTime;
import java.util.EnumMap;
import java.util.Map;
import java.util.Set;

import com.dakshata.constants.trading.PortfolioSyncType;
import com.dakshata.trading.model.platform.IPlatformHolding;
import com.dakshata.trading.model.platform.IPlatformMargin;
import com.dakshata.trading.model.platform.IPlatformOrder;
import com.dakshata.trading.model.platform.IPlatformPosition;
import com.dakshata.trading.model.trade.PseudoAccount;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * Respresents a stock portfolio.
 *
 * @author PRITESH
 *
 */
@Builder(toBuilder = true)
@Getter
@Setter
public class Portfolio {

	private PseudoAccount account;

	@Builder.Default
	private Map<PortfolioSyncType, LocalTime> syncTimes = new EnumMap<>(PortfolioSyncType.class);

	@Builder.Default
	private Set<IOrder> systemOrders = newKeySet();

	@Builder.Default
	private volatile Set<IPlatformOrder> orders = newKeySet();

	@Builder.Default
	private volatile Set<IPlatformPosition> positions = newKeySet();

	@Builder.Default
	private volatile Set<IPlatformMargin> margins = newKeySet();

	@Builder.Default
	private volatile Set<IPlatformHolding> holdings = newKeySet();

	public final String getKey() {
		return this.account.getPortfolioKey();
	}

	public Set<IPlatformOrder> getOrders(final ISlimmer slimmer, final IEnrichment enrich) {
		final Set<IPlatformOrder> p = this.getOrders();
		enrich.enrichPlatformOrder(this.account, p);
		return slimmer.slimOrders(p);
	}

	public Set<IPlatformPosition> getPositions(final ISlimmer slimmer, final IEnrichment enrich) {
		final Set<IPlatformPosition> p = this.getPositions();
		enrich.enrichPosition(this.account, p);
		return slimmer.slimPositions(p);
	}

	public Set<IPlatformMargin> getMargins(final ISlimmer slimmer, final IEnrichment enrich) {
		return slimmer.slimMargins(this.getMargins());
	}

	public Set<IPlatformHolding> getHoldings(final ISlimmer slimmer, final IEnrichment enrich) {
		final Set<IPlatformHolding> p = this.getHoldings();
		enrich.enrichHolding(this.account, p);
		return slimmer.slimHoldings(p);
	}

	/**
	 * Returns true if portfolio part is not older than given time in millis.
	 */
	public boolean isFresh(final PortfolioSyncType type, final long millis) {
		final LocalTime lastUpdated = this.getSyncTimes().get(type);
		if (lastUpdated == null) {
			return false;
		}

		final long diff = lastUpdated.until(LocalTime.now(), MILLIS);
		return ((diff >= 0) && (diff <= millis));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((this.account == null) ? 0 : this.getKey().hashCode());
		return result;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final Portfolio other = (Portfolio) obj;
		if (this.account == null) {
			if (other.account != null) {
				return false;
			}
		} else if (!this.getKey().equals(other.getKey())) {
			return false;
		}
		return true;
	}

}

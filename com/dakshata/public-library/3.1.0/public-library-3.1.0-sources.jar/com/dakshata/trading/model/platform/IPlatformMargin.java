/**
 *
 */
package com.dakshata.trading.model.platform;

import com.dakshata.trading.model.portfolio.IMargin;

/**
 * Represents a platform margin.
 *
 * @author PRITESH
 *
 */
public interface IPlatformMargin extends IMargin {

}

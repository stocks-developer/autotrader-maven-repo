/**
 *
 */
package com.dakshata.trading.model.instrument;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import com.dakshata.constants.instrument.InstrumentType;
import com.dakshata.constants.instrument.OptionType;
import com.dakshata.constants.instrument.Segment;

/**
 * Base class for instruments.
 *
 * @author PRITESH
 *
 */
public interface IBaseInstrument extends Serializable {

	@Override
	int hashCode();

	@Override
	boolean equals(Object obj);

	/**
	 * This id must uniquely identify an instrument globally. It is also advised to
	 * have the identifier self-explanatory.
	 *
	 * @return a unique instrument identifier
	 */
	Long getId();

	/**
	 * A symbol for the instrument.
	 *
	 * @return symbol
	 */
	String getSymbol();

	/**
	 * Segment represents a functional area for instrument.
	 *
	 * @return segment
	 */
	Segment getSegment();

	/**
	 * A name for the instrument (name of the company in case of stocks).
	 *
	 * @return name
	 */
	String getName();

	/**
	 * Gets an instrument type for the instrument (EQ, FUT, OPT).
	 *
	 * @return instrument type
	 */
	InstrumentType getInstrumentType();

	/**
	 * Expiry of a derivative.
	 *
	 * @return expiry
	 */
	Date getExpiry();

	/**
	 * Type of option.
	 *
	 * @return option type
	 */
	OptionType getOptionType();

	/**
	 * Strike price of an option contract.
	 *
	 * @return strike price
	 */
	Float getStrikePrice();

	/**
	 * Get lot size of a derivative contract.
	 *
	 * @return lot size
	 */
	Integer getLotSize();

	/**
	 * Get exchange allowed tick size.
	 *
	 * @return tick size
	 */
	Float getTickSize();

	/**
	 * Last modified date
	 *
	 * @return date on which instrument was last modified
	 */
	Timestamp getLastModified();

	Timestamp getCreatedTime();

	/**
	 * Lower circuit price
	 *
	 * @return lower circuit
	 */
	Float getLowerCircuit();

	/**
	 * Lower circuit price
	 *
	 * @return lower circuit
	 */
	Float getUpperCircuit();

}

package com.dakshata.trading.model.platform;

import com.dakshata.constants.trading.TradeType;

import lombok.Builder;

/**
 * One leg of a resting GTT (Good Till Triggered) order.
 *
 * <p>
 * A SINGLE GTT carries only {@code leg1}; an OCO GTT carries {@code leg1} (the
 * target leg, trigger above LTP) and {@code leg2} (the stop-loss leg, trigger
 * below LTP). {@code transactionType} is per-leg to accommodate brokers that
 * allow it (Zerodha); brokers with an order-level side simply repeat it.
 *
 * @author PRITESH
 *
 */
@Builder
public record GttOrderLeg(TradeType transactionType, Float triggerPrice, Float price, Integer quantity) {
}

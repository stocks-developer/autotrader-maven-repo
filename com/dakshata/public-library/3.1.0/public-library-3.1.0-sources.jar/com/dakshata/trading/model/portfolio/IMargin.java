package com.dakshata.trading.model.portfolio;

import com.dakshata.constants.trading.MarginCategory;
import com.dakshata.trading.model.trade.PseudoAccount;

public interface IMargin extends IPortfolioPart {

	/**
	 * Margin category {@link com.dakshata.constants.trading.MarginCategory}
	 */
	MarginCategory getCategory();

	/**
	 * Total margin
	 */
	Float getTotal();

	/**
	 * Get funds
	 */
	Float getFunds();

	/**
	 * Utilized margin
	 */
	Float getUtilized();

	/**
	 * Available margin
	 */
	Float getAvailable();

	Float getNet();

	Float getSpan();

	Float getExposure();

	Float getCollateral();

	Float getPayin();

	Float getPayout();

	Float getAdhoc();

	Float getRealisedMtm();

	Float getUnrealisedMtm();

	/**
	 * Pseudo account<br>
	 * Not available for API users, please use
	 * {@link IPortfolioPart#getPseudoAccount()}
	 */
	PseudoAccount getAccount();

	/**
	 * Returns a new instance of margin by adding values from this and the parameter
	 * along with new category.
	 *
	 * @param b        margin to be added
	 * @param category new category
	 * @return sum
	 */
	IMargin plus(IMargin b, MarginCategory category);

	/**
	 * Returns a copy of the this margin with the new category.
	 *
	 * @param category new category
	 * @return a copy of this with new category
	 */
	IMargin copy(MarginCategory category);

}

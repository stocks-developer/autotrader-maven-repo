/**
 *
 */
package com.dakshata.trading.model.platform;

import static com.dakshata.constants.data.model.ICommon.MINI_VARCHAR_LENGTH;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;
import javax.persistence.Version;

import com.dakshata.constants.trading.TradingPlatform;
import com.dakshata.tools.comparator.LiteralComparator;
import com.dakshata.trading.model.instrument.Instrument;
import com.dakshata.trading.model.trade.PseudoAccount;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.opencsv.bean.CsvIgnore;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Platform holding.
 *
 * @author PRITESH
 *
 */
@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class PlatformHolding implements IPlatformHolding {

	private static final long serialVersionUID = 410813330961283887L;

	@CsvIgnore
	private static final String[] CSV_ORDER = { "PSEUDOACCOUNT", "TRADINGACCOUNT", "ID", "EXCHANGE", "SYMBOL", "ISIN",
			"QUANTITY", "T1QTY", "PNL", "PRODUCT", "COLLATERALTYPE", "COLLATERALQTY", "HAIRCUT", "AVGPRICE",
			"INSTRUMENTTOKEN", "DAY", "PLATFORM", "STOCKBROKER", "INDEPENDENTSYMBOLNSE", "INDEPENDENTSYMBOLBSE", "LTP",
			"CURRENTVALUE" };

	@CsvIgnore
	public static final HeaderColumnNameMappingStrategy<PlatformHolding> HOLDING_CSV_STRATEGY = new HeaderColumnNameMappingStrategy<>();

	static {
		HOLDING_CSV_STRATEGY.setType(PlatformHolding.class);
		HOLDING_CSV_STRATEGY.setColumnOrderOnWrite(new LiteralComparator<String>(CSV_ORDER));
	}

	@Id
	@GeneratedValue
	private Long id;

	@CsvIgnore
	@EqualsAndHashCode.Include
	@ManyToOne
	@Id
	private PseudoAccount account;

	@Column(length = MINI_VARCHAR_LENGTH)
	private String isin, collateralType, instrumentToken;

	@Column(length = MINI_VARCHAR_LENGTH)
	@EqualsAndHashCode.Include
	private String product;

	@Builder.Default
	private Integer quantity = 0, collateralQty = 0, t1Qty = 0;

	private Float pnl, haircut, avgPrice;

	@Transient
	@EqualsAndHashCode.Include
	private String pseudoAccount, tradingAccount, stockBroker;

	@Column(length = 10)
	@EqualsAndHashCode.Include
	private String exchange;

	@Column(length = 100, nullable = false)
	@EqualsAndHashCode.Include
	private String symbol;

	@Enumerated(EnumType.STRING)
	@Column(length = 21)
	@EqualsAndHashCode.Include
	private TradingPlatform platform;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@EqualsAndHashCode.Include
	@Builder.Default
	private LocalDate day = LocalDate.now();

	@CsvIgnore
	@Version
	private Integer version;

	@CsvIgnore
	@ManyToOne
	private Instrument instrumentNSE, instrumentBSE;

	@Transient
	private String independentSymbolNSE, independentSymbolBSE;

	private Float ltp, currentValue;
	
	public final Integer getTotalQty() {
		int a = (quantity == null) ? 0 : quantity;
		int b = (t1Qty == null) ? 0 : t1Qty;
		return a + b;
	}
	
}

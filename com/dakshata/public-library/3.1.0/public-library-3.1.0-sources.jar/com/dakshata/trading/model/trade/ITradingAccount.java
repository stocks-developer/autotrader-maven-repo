/**
 *
 */
package com.dakshata.trading.model.trade;

import static com.dakshata.tools.trading.KeyBuilder.makeTradingAccKey;

import com.dakshata.constants.trading.TradingPlatform;
import com.dakshata.data.model.activity.ISupportsModelActivity;
import com.dakshata.data.model.billing.ILedger;

/**
 * Represents a trading account.
 *
 * @author PRITESH
 *
 */
public interface ITradingAccount extends ILedger, ISupportsModelActivity {

	@Override
	int hashCode();

	@Override
	boolean equals(Object obj);

	/**
	 * A unique key for account.
	 */
	default String getKey() {
		return makeTradingAccKey(this.getBroker(), this.getLoginId());
	}

	Long getId();

	StockBroker getBroker();

	TradingPlatform getPlatform();

	String getLoginId();

	String getPassword();

	String getSecurityAnswer();

	String getTransactionPassword();

	String getUsername();

	String getApiKey();

	String getApiAppName();

	String getApiUserId();

	Integer getApiAppSource();

	String getApiPassword();

	String getApiEncryptionKey();

	String getEmail();

	String getPhone();

	String getToken();

	boolean equalsBusiness(ITradingAccount other);

}

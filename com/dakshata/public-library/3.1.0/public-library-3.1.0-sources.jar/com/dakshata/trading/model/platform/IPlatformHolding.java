/**
 *
 */
package com.dakshata.trading.model.platform;

import java.time.LocalDate;

import com.dakshata.constants.trading.TradingPlatform;
import com.dakshata.trading.model.instrument.IInstrument;
import com.dakshata.trading.model.portfolio.IPortfolioPart;
import com.dakshata.trading.model.trade.PseudoAccount;

/**
 * Represents a platform holding.
 *
 * @author PRITESH
 *
 */
public interface IPlatformHolding extends IPortfolioPart {

	Long getId();

	PseudoAccount getAccount();

	String getIsin();

	String getCollateralType();

	String getInstrumentToken();

	String getProduct();

	Integer getQuantity();

	Integer getCollateralQty();

	Integer getT1Qty();

	Float getPnl();

	Float getHaircut();

	Float getAvgPrice();

	String getExchange();

	String getSymbol();

	LocalDate getDay();

	/**
	 * Represents the trading platform to which this position belongs.
	 */
	TradingPlatform getPlatform();

	IInstrument getInstrumentNSE();

	String getIndependentSymbolNSE();

	IInstrument getInstrumentBSE();

	String getIndependentSymbolBSE();

	Float getLtp();

	Float getCurrentValue();

	Integer getTotalQty();

}

/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.io.Serializable;
import java.time.LocalTime;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Positions summary.
 *
 * @author PRITESH
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class PositionsSummary implements Serializable  {

	private static final long serialVersionUID = -3354089420666017276L;

	@JsonDeserialize(using = LocalTimeDeserializer.class)
	@JsonSerialize(using = LocalTimeSerializer.class)	
	private LocalTime updateTime;

	private int totalCount, openCount, closedCount;

	private float totalMtm, totalPnl, totalAtPnl;

}

/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.io.Serializable;

import com.dakshata.trading.model.trade.PseudoAccount;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Margin Id class.
 *
 * @author PRITESH
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class MarginId implements Serializable  {

	private static final long serialVersionUID = 6666733535564576709L;

	@EqualsAndHashCode.Include
	private String category;

	@EqualsAndHashCode.Include
	private PseudoAccount account;

}

package com.dakshata.trading.model.platform;

import java.sql.Timestamp;

import com.dakshata.constants.trading.OrderStatus;
import com.dakshata.constants.trading.TradingPlatform;
import com.dakshata.trading.model.portfolio.ICoreOrder;

public interface IPlatformOrder extends ICoreOrder {

	/**
	 * Parent order id. This is only present for child orders, which are placed by
	 * stock broker when a bracket order executes.
	 */
	String getParentOrderId();

	/**
	 * Some platforms provide order id in different format, so it must be extracted
	 * before use. Example, ANT gives it in {order_id}|{sequence} format.
	 *
	 * @param p platform
	 * @return parent order id
	 */
	String calculateParentOrderId(final TradingPlatform p);

	/**
	 * Exchange order id
	 */
	String getExchangeOrderId();

	/**
	 * Order status (as returned by stock broker)
	 */
	String getRawStatus();

	/**
	 * Order timestamp given by trading platform
	 */
	Timestamp getPlatformTime();

	/**
	 * Order timestamp given by exchange
	 */
	Timestamp getExchangeTime();

	/**
	 * Pending quantity
	 */
	Integer getPendingQuantity();

	/**
	 * Filled quantity
	 */
	Integer getFilledQuantity();

	/**
	 * Order average price (the average price at which order was traded)
	 */
	Float getAveragePrice();

	/**
	 * Trading platform
	 */
	TradingPlatform getPlatform();

	/**
	 * Account (client) id (as returned by broker)
	 */
	String getClientId();

	/**
	 * Order status (broker independent)
	 */
	OrderStatus getStatus();

	/**
	 * Returns true if order is open
	 */
	boolean isOpen();

	/**
	 * Returns true if order is trigger pending
	 */
	boolean isTriggerPending();

	/**
	 * Returns true if order is open or trigger pending
	 */
	boolean isOpenOrTriggerPending();

	/**
	 * Returns true if order is cancelled
	 */
	boolean isCancelled();

	/**
	 * Returns true if order is rejected
	 */
	boolean isRejected();

	/**
	 * Represents number of times order was modified. Specific to AliceBlue ANT, but
	 * we need it in order modification.
	 */
	String getNestRequestId();

	/**
	 * Returns this order as it was received from broker. It is sometimes needed as
	 * we might need some properties of this object which we may not save in our
	 * standard format. This can be seen in Shoonya (cancel order) operation.
	 */
	Object getBrokerFormat();
}

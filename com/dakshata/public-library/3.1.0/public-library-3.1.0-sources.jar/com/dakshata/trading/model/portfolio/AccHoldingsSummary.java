/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Holdings summary.
 *
 * @author PRITESH
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class AccHoldingsSummary implements Serializable {

	private static final long serialVersionUID = 3754070222933030278L;

	private int total, totalQty, quantity, t1Qty;

	private float pnl, currentVal;

}

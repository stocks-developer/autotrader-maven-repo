/**
 *
 */
package com.dakshata.trading.model.tv.position;

import com.dakshata.constants.trading.PositionCategory;
import com.dakshata.constants.trading.PositionType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Trading view position square-off request.
 *
 * @author PRITESH
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class TvPosSqOff {

	private String account;

	@Builder.Default
	private boolean group = Boolean.FALSE;

	private PositionCategory category;

	private PositionType type;

	private String exchange;

	private String symbol;

	private String commandId;

	@Builder.Default
	private boolean cancelOpenOrders = Boolean.TRUE;

}

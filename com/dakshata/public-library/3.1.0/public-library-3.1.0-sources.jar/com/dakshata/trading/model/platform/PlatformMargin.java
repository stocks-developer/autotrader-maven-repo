/**
 *
 */
package com.dakshata.trading.model.platform;

import java.time.LocalDate;
import java.util.Comparator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;
import javax.persistence.Version;

import com.dakshata.constants.trading.MarginCategory;
import com.dakshata.tools.comparator.LiteralComparator;
import com.dakshata.trading.model.portfolio.IMargin;
import com.dakshata.trading.model.portfolio.MarginId;
import com.dakshata.trading.model.trade.PseudoAccount;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.opencsv.bean.CsvIgnore;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Represents a margin record.
 *
 * @author PRITESH
 *
 */
@Entity
@IdClass(MarginId.class)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class PlatformMargin implements IPlatformMargin {

	private static final long serialVersionUID = 6958246687083167804L;

	/**
	 * TreeMap uses compareTo() for equality check and hence we it was considering
	 * objects duplicate of their platform time matches
	 */
	@CsvIgnore
	public static final Comparator<PlatformMargin> COMPARE_BY_CATEGORY = Comparator
			.comparing(PlatformMargin::getCategory, Comparator.nullsFirst(MarginCategory::compareTo))
			.thenComparing(PlatformMargin::getPseudoAccount, Comparator.nullsFirst(String::compareTo))
			.thenComparing(PlatformMargin::getDay, Comparator.nullsFirst(LocalDate::compareTo));

	@CsvIgnore
	private static final String[] CSV_ORDER = { "PSEUDOACCOUNT", "TRADINGACCOUNT", "CATEGORY", "FUNDS", "UTILIZED",
			"AVAILABLE", "DAY", "STOCKBROKER", "TOTAL", "NET", "SPAN", "EXPOSURE", "COLLATERAL", "PAYIN", "PAYOUT",
			"ADHOC", "REALISEDMTM", "UNREALISEDMTM" };

	@CsvIgnore
	public static final HeaderColumnNameMappingStrategy<PlatformMargin> MARGIN_CSV_STRATEGY = new HeaderColumnNameMappingStrategy<>();

	static {
		MARGIN_CSV_STRATEGY.setType(PlatformMargin.class);
		MARGIN_CSV_STRATEGY.setColumnOrderOnWrite(new LiteralComparator<String>(CSV_ORDER));
	}

	@CsvIgnore
	@EqualsAndHashCode.Include
	@ManyToOne
	@Id
	private PseudoAccount account;

	@Id
	@EqualsAndHashCode.Include
	@Column(length = 21, nullable = false)
	@Enumerated(EnumType.STRING)
	private MarginCategory category;

	@Builder.Default
	private Float funds = 0f, utilized = 0f, available = 0f, total = 0f;

	@Builder.Default
	private Float net = 0f, span = 0f, exposure = 0f, collateral = 0f, payin = 0f, payout = 0f, adhoc = 0f;

	@Builder.Default
	private Float realisedMtm = 0f, unrealisedMtm = 0f;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@EqualsAndHashCode.Include
	@Builder.Default
	private LocalDate day = LocalDate.now();

	@Transient
	@EqualsAndHashCode.Include
	private String pseudoAccount, tradingAccount, stockBroker;

	@CsvIgnore
	@Version
	private Integer version;

	@Override
	public PlatformMargin plus(final IMargin b, final MarginCategory category) {
		return PlatformMargin.builder().account(this.account).category(category).total(this.total + b.getTotal())
				.funds(this.funds + b.getFunds()).net(this.net + b.getNet()).span(this.span + b.getSpan())
				.exposure(this.exposure + b.getExposure()).collateral(this.collateral + b.getCollateral())
				.payin(this.payin + b.getPayin()).payout(this.payout + b.getPayout()).adhoc(this.adhoc + b.getAdhoc())
				.realisedMtm(this.realisedMtm + b.getRealisedMtm())
				.unrealisedMtm(this.unrealisedMtm + b.getUnrealisedMtm()).utilized(this.utilized + b.getUtilized())
				.available(this.available + b.getAvailable()).day(this.day).pseudoAccount(this.pseudoAccount)
				.tradingAccount(this.tradingAccount).stockBroker(this.stockBroker).build();
	}

	@Override
	public PlatformMargin copy(final MarginCategory category) {
		return PlatformMargin.builder().account(this.account).category(category).total(this.total).funds(this.funds)
				.utilized(this.utilized).available(this.available).day(this.day).pseudoAccount(this.pseudoAccount)
				.tradingAccount(this.tradingAccount).stockBroker(this.stockBroker).net(this.net).span(this.span)
				.exposure(this.exposure).collateral(this.collateral).payin(this.payin).payout(this.payout)
				.adhoc(this.adhoc).realisedMtm(this.realisedMtm).unrealisedMtm(this.unrealisedMtm).build();
	}

	@Override
	public String toString() {
		String pa = pseudoAccount;
		String ta = tradingAccount;
		String sb = stockBroker;

		if (this.account != null) {
			pa = this.account.getKey();
			ta = this.account.getAccount().getLoginId();
			sb = this.account.getAccount().getBroker().getId();
		}

		return "PlatformMargin [pseudoAccount=" + pa + ", tradingAccount=" + ta + ", stockBroker=" + sb + ", category="
				+ category + ", funds=" + funds + ", utilized=" + utilized + ", available=" + available + "]";
	}

}

/**
 *
 */
package com.dakshata.trading.model.instrument;

import static com.dakshata.constants.data.model.ICommon.DEFAULT_VARCHAR_LENGTH;
import static com.dakshata.constants.data.model.ICommon.SHORT_VARCHAR_LENGTH;
import static com.dakshata.tools.string.StringUtil.truncate;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Comparator;
import java.util.Objects;

import javax.persistence.*;

import com.dakshata.constants.instrument.InstrumentType;
import com.dakshata.constants.instrument.OptionType;
import com.dakshata.constants.instrument.Segment;
import com.dakshata.constants.instrument.Source;

import lombok.Getter;
import lombok.Setter;

/**
 * Represents an instrument (stock, derivative). We are not using lombok builder
 * here as we are performing some logic in constructor.<b>
 *
 * <b>Note: </b>In composite indexes, place more selective columns first, unless
 * a less selective column is always used and must be part of the index. Hence,
 * source column is kept last in the indices here.
 *
 * @author PRITESH
 *
 */
@Entity
@Table(indexes = { @Index(columnList = "source", name = "inst_idx_source"),
		@Index(columnList = "ind_symbol,source", name = "inst_idx_ind_symbol_source"),
		@Index(columnList = "symbol,source", name = "inst_idx_symbol_source"),
		@Index(columnList = "token,source", name = "inst_idx_token_source"),
		@Index(columnList = "key_part,source", name = "inst_idx_key_part_source") })
@Getter
@Setter
public class Instrument implements IInstrument {

	private static final long serialVersionUID = 5355940810496199224L;

	public static final Comparator<Instrument> LATEST_COMPARE = Comparator
			.comparing(Instrument::getLastModified, Comparator.nullsFirst(Timestamp::compareTo))
			.thenComparing(Instrument::getCreatedTime, Comparator.nullsFirst(Timestamp::compareTo))
			.thenComparing(Instrument::getId, Comparator.nullsFirst(Long::compareTo));

	@Id
	@GeneratedValue
	private Long id;

	private String name;

	private Date expiry;

	private Float strikePrice, tickSize;

	private Integer lotSize, multiplier;

	@Column(length = 100, nullable = false)
	private String symbol;

	@Column(length = 100, name = "under_symbol")
	private String underlyingSymbol;

	@Column(name = "ind_symbol")
	private Long independentSymbol;

	@Column(name = "ind_under_symbol")
	private Long independentUnderSymbol;

	@Column(length = 10, nullable = false)
	private String exchange;

	@Enumerated(EnumType.STRING)
	@Column(length = 2)
	private OptionType optionType;

	@Enumerated(EnumType.STRING)
	@Column(length = 20, nullable = false)
	private Segment segment;

	@Enumerated(EnumType.STRING)
	@Column(length = SHORT_VARCHAR_LENGTH, nullable = false)
	private Source source;

	@Enumerated(EnumType.STRING)
	@Column(length = 10, name = "inst_type")
	private InstrumentType instrumentType;

	@Column(length = SHORT_VARCHAR_LENGTH, name = "key_part")
	private String keyPart;

	@Column(length = SHORT_VARCHAR_LENGTH)
	private String token, exchangeToken;

	@Column(name = "is_index")
	private Boolean index;

	@Column(updatable = false)
	private Timestamp createdTime;

	private Timestamp lastModified;

	private Float lowerCircuit, upperCircuit;

	@Column(length = 2)
	private String series;

	public Instrument() {
	}

	public Instrument(final Source source, final String name, final String exchange, final String symbol,
			final String underlyingSymbol, final InstrumentType instrumentType, final String keyPart,
			final OptionType optionType, final Date expiry, final Float strikePrice, final Integer lotSize,
			final Float tickSize, final String token, final String exchangeToken, final Boolean index,
			final Segment segment) {
		this.source = source;
		this.name = (name == null) ? null : truncate(name.trim(), DEFAULT_VARCHAR_LENGTH);
		this.exchange = exchange.trim();
		// Symbols are purposely kept upper case to avoid two similar symbols being
		// inserted (Ex. NIFTY, Nifty)
		this.symbol = symbol.trim().toUpperCase();
		this.underlyingSymbol = (underlyingSymbol == null) ? null : underlyingSymbol.trim().toUpperCase();
		this.instrumentType = instrumentType;
		this.keyPart = (keyPart == null) ? null : keyPart.trim().toUpperCase();
		this.optionType = optionType;
		this.expiry = expiry;
		this.strikePrice = strikePrice;
		this.lotSize = lotSize;
		this.tickSize = tickSize;
		this.token = token;
		this.exchangeToken = exchangeToken;
		this.index = index;
		this.segment = segment;
	}

	public Instrument(final Source source, final String name, final String exchange, final String symbol,
			final InstrumentType instrumentType, final String keyPart, final Float tickSize, final String token,
			final String exchangeToken, final Boolean index, final Segment segment) {
		this(source, name, exchange, symbol, null, instrumentType, keyPart, null, null, null, null, tickSize, token,
				exchangeToken, index, segment);
	}

	@PrePersist
	void onCreate() {
		this.createdTime = new Timestamp(System.currentTimeMillis());
	}

	@PreUpdate
	void onPersist() {
		this.lastModified = new Timestamp(System.currentTimeMillis());
	}

	@Override
	public String toString() {
		return "Instrument [id=" + this.id + ", source=" + this.source + ", name=" + this.name + ", exchange="
				+ this.exchange + ", symbol=" + this.symbol + ", underlyingSymbol=" + this.underlyingSymbol
				+ ", instrumentType=" + this.instrumentType + ", keyPart=" + this.keyPart + ", optionType="
				+ this.optionType + ", expiry=" + this.expiry + ", strikePrice=" + this.strikePrice + "]";
	}

	@Override
	public int hashCode() {
		// Expiry was added as upstox weekly currency future have same symbol
		return Objects.hash(this.source, this.exchange, this.symbol, this.keyPart, this.expiry, this.series);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final Instrument other = (Instrument) obj;

		// Expiry was added as upstox weekly currency future have same symbol
		return Objects.equals(this.source, other.source) && Objects.equals(this.exchange, other.exchange)
				&& Objects.equals(this.symbol, other.symbol) && Objects.equals(this.keyPart, other.keyPart)
				&& Objects.equals(this.expiry, other.expiry) && Objects.equals(this.series, other.series);
	}

	public void setName(final String name) {
		this.name = truncate(name, DEFAULT_VARCHAR_LENGTH);
	}

	public void updateCircuitLimits(final Float lowerCircuit, final Float upperCircuit) {
		if ((lowerCircuit != null) && !lowerCircuit.isNaN()) {
			this.lowerCircuit = lowerCircuit;
		}
		if ((upperCircuit != null) && !upperCircuit.isNaN()) {
			this.upperCircuit = upperCircuit;
		}
	}

	public void updateLotSize(final Integer lotSize) {
		if (lotSize != null) {
			this.lotSize = lotSize;
		}
	}

	/**
	 * This method is used to identify whether the instrument received from source
	 * is different that the instrument present in our database.
	 */
	public final boolean matchesWithSource(final Instrument b) {
		if (!this.equals(b)) {
			return false;
		}

		return Objects.equals(this.token, b.token) && Objects.equals(this.exchangeToken, b.exchangeToken);
	}

}

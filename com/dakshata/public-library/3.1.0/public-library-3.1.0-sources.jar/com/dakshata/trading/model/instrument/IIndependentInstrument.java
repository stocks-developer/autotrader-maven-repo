/**
 *
 */
package com.dakshata.trading.model.instrument;

import com.dakshata.constants.instrument.Exchange;

/**
 * These are broker independent instruments.
 *
 * @author PRITESH
 *
 */
public interface IIndependentInstrument extends IBaseInstrument {

	/**
	 * A short code for the exchange on which the instrument is traded.
	 *
	 * @return exchange
	 */
	Exchange getExchange();

	/**
	 * Symbol of the underlying for a derivative contract.
	 *
	 * @return underlying symbol
	 */
	Long getUnderlyingSymbol();

}

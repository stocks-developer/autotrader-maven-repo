package com.dakshata.trading.model.platform;

import com.dakshata.constants.trading.PositionDirection;
import com.dakshata.constants.trading.PositionState;
import com.dakshata.constants.trading.TradingPlatform;
import com.dakshata.trading.model.portfolio.IPosition;

public interface IPlatformPosition extends IPosition {

	/**
	 * Some platforms return multiple sets of positions. For example, see below
	 * response format from Zerodha:<br>
	 * <br>
	 * The positions API returns two sets of positions, net and day. net is the
	 * actual, current net position portfolio, while day is a snapshot of the buying
	 * and selling activity for that particular day.
	 */
	String getCategory();

	/**
	 * Raw trading account id
	 */
	String getAccountId();

	/**
	 * LTP isn't really a part of position, but many platforms return it inside
	 * position object.
	 */
	Float getLtp();

	/**
	 * Represents the trading platform to which this position belongs.
	 */
	TradingPlatform getPlatform();

	/**
	 * Quantity held previously and carried forward over night
	 *
	 */
	Integer getOvernightQuantity();

	/**
	 * The quantity/lot size multiplier used for calculating P&Ls
	 */
	Integer getMultiplier();

	/**
	 * Realised intraday returns
	 */
	Float getRealisedPnl();

	/**
	 * Unrealised intraday returns
	 */
	Float getUnrealisedPnl();

	/**
	 * Position state OPEN or CLOSED.
	 */
	PositionState getState();

	/**
	 * Position direction (LONG, SHORT, NEUTRAL).
	 */
	PositionDirection getDirection();

}

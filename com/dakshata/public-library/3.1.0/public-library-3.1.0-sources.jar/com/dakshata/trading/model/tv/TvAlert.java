/**
 *
 */
package com.dakshata.trading.model.tv;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Trading view alert model.
 *
 * @author PRITESH
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public abstract class TvAlert {

	private String command;

	private String apiKey;

	private Map<String, String> analysis = new HashMap<>();

	@JsonAnySetter
	public void setAnalysis(final String name, final String value) {
		this.analysis.put(name, value);
	}

}

/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.io.Serializable;

/**
 * Represents a part of portfolio.
 *
 * @author PRITESH
 *
 */
public interface IPortfolioPart extends Serializable {

	/**
	 * Pseudo account id
	 */
	String getPseudoAccount();

	/**
	 * Trading account id
	 */
	String getTradingAccount();

	/**
	 * Stock broker
	 */
	String getStockBroker();

}

/**
 *
 */
package com.dakshata.trading.error;

/**
 * Indicates that the pseudo account is not live.
 *
 * @author PRITESH
 *
 */
public class AccountNotLiveException extends Exception {

	private static final long serialVersionUID = -5985251467887792928L;

	public AccountNotLiveException(final String message) {
		super(message);
	}

}

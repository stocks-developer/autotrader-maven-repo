/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.io.Serializable;

import com.dakshata.constants.instrument.Exchange;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Positions summary by symbol.
 *
 * @author PRITESH
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class SymbolPositionSummary implements Serializable {

	private static final long serialVersionUID = -1426041291576661646L;

	private Exchange exchange;

	private String symbol;

	private int buyQuantity, sellQuantity, netQuantity;

	private float pnl, atPnl, mtm, buyValue, sellValue, netValue, buyAvgPrice, sellAvgPrice;

}

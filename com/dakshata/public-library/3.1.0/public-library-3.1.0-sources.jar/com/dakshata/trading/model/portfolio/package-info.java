/**
 * Portfolio core classes here. These model may have additional attributes
 * specific to trading platform or algorithmic system. They have been given
 * packages <code>platform</code> and <code>algo</code> respectively.
 */
package com.dakshata.trading.model.portfolio;
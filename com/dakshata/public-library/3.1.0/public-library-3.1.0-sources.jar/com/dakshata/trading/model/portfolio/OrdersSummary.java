/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.io.Serializable;
import java.time.LocalTime;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Orders summary.
 *
 * @author PRITESH
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class OrdersSummary implements Serializable  {

	private static final long serialVersionUID = 6320821578635912570L;

	@JsonDeserialize(using = LocalTimeDeserializer.class)
	@JsonSerialize(using = LocalTimeSerializer.class)	
	private LocalTime updateTime;

	private int totalCount, openCount, completeCount, rejectedCount, cancelledCount, triggerPendingCount;

}

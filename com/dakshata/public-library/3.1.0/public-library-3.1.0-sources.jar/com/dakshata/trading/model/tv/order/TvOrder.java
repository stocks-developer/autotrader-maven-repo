/**
 *
 */
package com.dakshata.trading.model.tv.order;

import com.dakshata.constants.trading.OrderType;
import com.dakshata.constants.trading.ProductType;
import com.dakshata.constants.trading.Validity;
import com.dakshata.constants.trading.Variety;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * An order received from Trading View.
 *
 * @author PRITESH
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class TvOrder {

	// Pseudo or group account number
	private String account;

	@Builder.Default
	private boolean group = Boolean.FALSE;

	@Builder.Default
	private Variety variety = Variety.REGULAR;
	
	@Builder.Default
	private Validity validity = Validity.DAY;

	private String exchange, symbol;

	private String tradeType;

	private OrderType orderType;

	private ProductType productType;

	private int quantity, disclosedQuantity;

	private float price, triggerPrice;

	private float target, stoploss, trailingStoploss;
	
	private boolean amo;

	private String commandId;
	
}

/**
 *
 */
package com.dakshata.trading.model.portfolio;

import static com.dakshata.constants.IGeneral.COMMA;
import static java.lang.String.valueOf;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import javax.persistence.Version;

import com.dakshata.constants.trading.PositionType;
import com.dakshata.trading.model.instrument.Instrument;
import com.dakshata.trading.model.trade.PseudoAccount;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.opencsv.bean.CsvIgnore;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

/**
 * Represens a position.
 *
 * @author PRITESH
 *
 */
@MappedSuperclass
@Getter
@Setter
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Position implements IPosition {

	private static final long serialVersionUID = -2633277504395352116L;

	@Id
	@GeneratedValue
	private Long id;

	@CsvIgnore
	@ManyToOne
	@EqualsAndHashCode.Include
	private Instrument instrument;

	private Integer buyQuantity, sellQuantity, netQuantity;

	@Enumerated(EnumType.STRING)
	@Column(length = 21)
	@EqualsAndHashCode.Include
	private PositionType type;

	/**
	 * atPnl is calculated by AutoTrader.
	 */
	private Float pnl, mtm, buyValue, sellValue, netValue, buyAvgPrice, sellAvgPrice, atPnl;

	@CsvIgnore
	@ManyToOne
	@EqualsAndHashCode.Include
	private PseudoAccount account;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@Builder.Default
	@EqualsAndHashCode.Include
	private LocalDate day = LocalDate.now();

	@Transient
	@EqualsAndHashCode.Include
	private String pseudoAccount, tradingAccount, stockBroker;

	@Transient
	@EqualsAndHashCode.Include
	private String exchange, symbol;

	@Transient
	@EqualsAndHashCode.Include
	private String independentExchange, independentSymbol;

	@CsvIgnore
	@Version
	private Integer version;

	@Override
	public String toString() {
		String key = "EMPTY";
		if (this.getAccount() != null) {
			key = this.getAccount().getKey();
		}
		String exchange = this.getIndependentExchange();
		String symbol = this.getIndependentSymbol();
		if (this.instrument != null) {
			exchange = instrument.getExchange();
			symbol = instrument.getSymbol();
		}

		String csv = String.join(COMMA, key, valueOf(this.type), exchange, symbol, valueOf(netQuantity), valueOf(pnl),
				valueOf(mtm));
		return "Position [" + csv + "]";
	}

}

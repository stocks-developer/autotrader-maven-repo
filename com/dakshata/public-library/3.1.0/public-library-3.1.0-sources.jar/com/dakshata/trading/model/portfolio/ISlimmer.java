/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.util.Set;

import com.dakshata.data.model.common.IOperationResponse;
import com.dakshata.trading.model.platform.IPlatformHolding;
import com.dakshata.trading.model.platform.IPlatformMargin;
import com.dakshata.trading.model.platform.IPlatformOrder;
import com.dakshata.trading.model.platform.IPlatformPosition;

/**
 * Used to slim down portfolio.
 *
 * @author PRITESH
 *
 */
public interface ISlimmer {

	Set<IPlatformOrder> slimOrders(Set<IPlatformOrder> orders);

	IOperationResponse<Set<IPlatformOrder>> slimOrders(IOperationResponse<Set<IPlatformOrder>> orders);

	Set<IPlatformPosition> slimPositions(Set<IPlatformPosition> positions);

	IOperationResponse<Set<IPlatformPosition>> slimPositions(IOperationResponse<Set<IPlatformPosition>> positions);

	Set<IPlatformMargin> slimMargins(Set<IPlatformMargin> margins);

	IOperationResponse<Set<IPlatformMargin>> slimMargins(IOperationResponse<Set<IPlatformMargin>> margins);

	Set<IPlatformHolding> slimHoldings(Set<IPlatformHolding> holdings);

	IOperationResponse<Set<IPlatformHolding>> slimHoldings(IOperationResponse<Set<IPlatformHolding>> holdings);

}

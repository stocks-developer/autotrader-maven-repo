package com.dakshata.trading.model.portfolio;

import java.time.LocalDate;

import com.dakshata.constants.trading.PositionType;
import com.dakshata.trading.model.instrument.IInstrument;
import com.dakshata.trading.model.trade.PseudoAccount;

public interface IPosition extends IPortfolioPart {

	Long getId();

	/**
	 * Broker specific instrument<br>
	 * Not available for API users, please use {@link #getExchange()} and
	 * {@link #getSymbol()}
	 */
	IInstrument getInstrument();

	/**
	 * Broker specific exchange
	 */
	String getExchange();

	/**
	 * Broker specific symbol
	 */
	String getSymbol();

	/**
	 * Broker independent exchange
	 */
	String getIndependentExchange();

	/**
	 * Broker independent symbol
	 */
	String getIndependentSymbol();

	/**
	 * Buy quantity
	 */
	Integer getBuyQuantity();

	/**
	 * Sell quantity
	 */
	Integer getSellQuantity();

	/**
	 * Net quantity
	 */
	Integer getNetQuantity();

	/**
	 * Position type {@link com.dakshata.constants.trading.PositionType}
	 */
	PositionType getType();

	/**
	 * Net returns on the position
	 */
	Float getPnl();

	/**
	 * Pnl calculated by AutoTrader Web.
	 */
	Float getAtPnl();

	/**
	 * Mark to market returns (computed based on the last close and the last traded
	 * price)
	 */
	Float getMtm();

	/**
	 * Total value of the bought quantities
	 */
	Float getBuyValue();

	/**
	 * Total value of the sold quantities
	 */
	Float getSellValue();

	/**
	 * Net value
	 */
	Float getNetValue();

	/**
	 * Average price at which quantities were bought
	 */
	Float getBuyAvgPrice();

	/**
	 * Average price at which quantities were sold
	 */
	Float getSellAvgPrice();

	/**
	 * Pseudo account<br>
	 * Not available for API users, please use
	 * {@link IPortfolioPart#getPseudoAccount()}
	 */
	PseudoAccount getAccount();

	/**
	 * Day
	 */
	LocalDate getDay();

}

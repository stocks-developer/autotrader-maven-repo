package com.dakshata.trading.model.portfolio;

import java.io.Serializable;

import com.dakshata.constants.instrument.Exchange;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Symbol level portfolio summary.
 *
 * @author PRITESH
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class SymbolSummary implements Serializable {

	private static final long serialVersionUID = 3520940016365016217L;

	private Exchange exchange;

	private String symbol;

	private SymbolPositionSummary net, day;

	private SymbolHoldingSummary holding;

	private boolean hasPosition;

}

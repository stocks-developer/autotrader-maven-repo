/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.io.Serializable;

import com.dakshata.constants.instrument.Exchange;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Positions summary by symbol.
 *
 * @author PRITESH
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class SymbolHoldingSummary implements Serializable {

	private static final long serialVersionUID = -4311264536928024602L;

	private Exchange exchange;

	private String symbol;

	private int totalQty, quantity, t1Qty;

	private float pnl, currentVal;

}

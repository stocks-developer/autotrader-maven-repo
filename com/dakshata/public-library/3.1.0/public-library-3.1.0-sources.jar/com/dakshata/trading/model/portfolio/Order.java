/**
 *
 */
package com.dakshata.trading.model.portfolio;

import static com.dakshata.constants.data.model.ICommon.SHORT_VARCHAR_LENGTH;
import static java.lang.String.valueOf;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.IdClass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import com.dakshata.constants.trading.GttTriggerType;
import com.dakshata.constants.trading.OrderStatusInternal;
import com.dakshata.constants.trading.Variety;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

/**
 * Represents an order.
 *
 * @author PRITESH
 *
 */
@Entity
@Table(name = "at_order")
@IdClass(OrderId.class)
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
public class Order extends CoreOrder implements IOrder {

	private static final long serialVersionUID = 2021841535249944753L;

	@Builder.Default
	private Float target = 0f;

	@Builder.Default
	private Float stoploss = 0f;

	@Builder.Default
	private Float trailingStoploss = 0f;

	/**
	 * GTT (Good Till Triggered) fields. leg1 reuses the flat
	 * triggerPrice/price/quantity (single GTT order, or OCO target leg). The
	 * gttLeg2* fields hold the OCO stop leg. All nullable / defaulted so existing
	 * non-GTT rows are unaffected. See gtt-implementation-plan.md §1.3.
	 */
	@Enumerated(EnumType.STRING)
	@Column(length = 8)
	private GttTriggerType gttTriggerType; // SINGLE | OCO; null for non-GTT

	@Builder.Default
	private Float gttLeg2Price = 0f; // OCO stop-leg limit price

	@Builder.Default
	private Float gttLeg2TriggerPrice = 0f; // OCO stop-leg trigger

	@Builder.Default
	private Integer gttLeg2Quantity = 0; // OCO stop-leg qty (may differ from leg1)

	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonDeserialize(using = LocalDateDeserializer.class)
	private LocalDate gttValidTill; // Angel: timeperiod days; Zerodha/Fyers: ~1yr; Dhan: ignored

	@Enumerated(EnumType.STRING)
	@Column(length = SHORT_VARCHAR_LENGTH)
	private OrderStatusInternal statusInternal;

	@Column(length = SHORT_VARCHAR_LENGTH)
	private String platformId;

	@PrePersist
	void onCreate() {
		this.createdTime = new Timestamp(System.currentTimeMillis());
	}

	@PreUpdate
	void onPersist() {
		this.modifiedTime = new Timestamp(System.currentTimeMillis());
	}

	/**
	 * Appends GTT (Good Till Triggered) details to the base order line so logs do
	 * not misleadingly render a GTT order as a plain LIMIT order. leg1 reuses the
	 * flat trigger/price/quantity; OCO also shows the gttLeg2* stop leg.
	 */
	@Override
	public String toString() {
		final String base = super.toString();
		if (Variety.GTT != super.getVariety()) {
			return base;
		}

		final StringBuilder gtt = new StringBuilder(" [GTT ");
		gtt.append(this.gttTriggerType != null ? this.gttTriggerType : "?");
		if (GttTriggerType.OCO == this.gttTriggerType) {
			gtt.append(" leg1(trig=").append(valueOf(super.getTriggerPrice())).append(" @")
					.append(valueOf(super.getPrice())).append(" x").append(valueOf(super.getQuantity())).append(')');
			gtt.append(" leg2(trig=").append(valueOf(this.gttLeg2TriggerPrice)).append(" @")
					.append(valueOf(this.gttLeg2Price)).append(" x").append(valueOf(this.gttLeg2Quantity)).append(')');
		} else {
			gtt.append(" trig=").append(valueOf(super.getTriggerPrice()));
		}
		gtt.append(" validTill=").append(valueOf(this.gttValidTill));
		gtt.append(" refLtp=").append(valueOf(super.getReferenceLtp()));
		gtt.append(']');

		return base + gtt;
	}

	protected List<String> toStringCols() {
		List<String> r = super.toStringCols();

		if (super.getVariety() != null && Variety.BO == super.getVariety()) {
			r.add("T: " + valueOf(this.target));
			r.add("Sl: " + valueOf(this.stoploss));
			r.add("Trail. Sl: " + valueOf(this.trailingStoploss));
		}
		r.add("ID: " + valueOf(super.getId()));

		return r;
	}
}

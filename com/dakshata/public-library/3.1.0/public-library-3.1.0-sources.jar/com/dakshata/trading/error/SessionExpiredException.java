/**
 *
 */
package com.dakshata.trading.error;

/**
 * Throw this error to indicate that the session has expired. Primarily used
 * when session expires on broker's server.
 *
 * @author PRITESH
 *
 */
public class SessionExpiredException extends Exception {

	private static final long serialVersionUID = 520646682047943389L;

	public SessionExpiredException(final String message, final Throwable cause) {
		super(message, cause);
	}

	public SessionExpiredException(final String message) {
		super(message);
	}

}

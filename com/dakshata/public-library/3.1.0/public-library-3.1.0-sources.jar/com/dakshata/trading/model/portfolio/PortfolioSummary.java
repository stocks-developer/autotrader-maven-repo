/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.io.Serializable;
import java.util.Collection;

import com.dakshata.data.model.common.OperationResponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Portfolio Summary.
 *
 * @author PRITESH
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class PortfolioSummary implements Serializable {

	private static final long serialVersionUID = 1462044357731037474L;

	@EqualsAndHashCode.Include
	private String username;

	private OrdersSummary ordersSummary;

	private PositionsSummary positionsSummaryDay, positionsSummaryNet;

	private MarginsSummary marginsSummary;

	private OperationResponse<Collection<AccountSummary>> accountSummaries;

	private OperationResponse<Collection<SymbolSummary>> symbolSummaries;

}

/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.util.Set;

import com.dakshata.trading.model.platform.IPlatformHolding;
import com.dakshata.trading.model.platform.IPlatformOrder;
import com.dakshata.trading.model.platform.IPlatformPosition;
import com.dakshata.trading.model.trade.PseudoAccount;

/**
 * Used to slim down portfolio.
 *
 * @author PRITESH
 *
 */
public interface IEnrichment {

	void enrichPlatformOrder(PseudoAccount account, Set<IPlatformOrder> orders);

	void enrichPosition(PseudoAccount pa, Set<IPlatformPosition> positions);

	void enrichHolding(PseudoAccount pa, Set<IPlatformHolding> holdings);

}

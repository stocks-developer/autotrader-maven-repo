/**
 *
 */
package com.dakshata.trading.model.platform;

import static com.dakshata.constants.data.model.ICommon.SHORT_VARCHAR_LENGTH;

import java.time.LocalDate;
import java.util.Comparator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.dakshata.constants.trading.PositionDirection;
import com.dakshata.constants.trading.PositionState;
import com.dakshata.constants.trading.PositionType;
import com.dakshata.constants.trading.TradingPlatform;
import com.dakshata.tools.comparator.LiteralComparator;
import com.dakshata.trading.model.portfolio.Position;
import com.opencsv.bean.CsvIgnore;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

/**
 * Represents a position record from trading platform.
 *
 * @author PRITESH
 *
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = true)
public class PlatformPosition extends Position implements IPlatformPosition {

	private static final long serialVersionUID = -2342824612058285182L;

	/**
	 * TreeMap uses compareTo() for equality check and hence we it was considering
	 * objects duplicate of their platform time matches
	 */
	@CsvIgnore
	public static final Comparator<PlatformPosition> COMPARE_BY_CAT_EX_SYB_TYPE = Comparator
			.comparing(PlatformPosition::getCategory, Comparator.nullsFirst(String::compareTo))
			.thenComparing(PlatformPosition::getIndependentExchange, Comparator.nullsFirst(String::compareTo))
			.thenComparing(PlatformPosition::getIndependentSymbol, Comparator.nullsFirst(String::compareTo))
			.thenComparing(PlatformPosition::getType, Comparator.nullsFirst(PositionType::compareTo))
			.thenComparing(PlatformPosition::getPseudoAccount, Comparator.nullsFirst(String::compareTo))
			.thenComparing(PlatformPosition::getDay, Comparator.nullsFirst(LocalDate::compareTo))
			.thenComparing(PlatformPosition::getId, Comparator.nullsFirst(Long::compareTo));

	@CsvIgnore
	private static final String[] CSV_ORDER = { "PSEUDOACCOUNT", "TRADINGACCOUNT", "TYPE", "CATEGORY",
			"INDEPENDENTEXCHANGE", "INDEPENDENTSYMBOL", "MTM", "PNL", "BUYQUANTITY", "SELLQUANTITY", "NETQUANTITY",
			"BUYVALUE", "SELLVALUE", "NETVALUE", "BUYAVGPRICE", "SELLAVGPRICE", "REALISEDPNL", "UNREALISEDPNL",
			"OVERNIGHTQUANTITY", "MULTIPLIER", "LTP", "EXCHANGE", "SYMBOL", "DAY", "PLATFORM", "ACCOUNTID", "ID",
			"STOCKBROKER", "STATE", "DIRECTION", "ATPNL" };

	@CsvIgnore
	public static final HeaderColumnNameMappingStrategy<PlatformPosition> PLATFORM_CSV_STRATEGY = new HeaderColumnNameMappingStrategy<>();

	static {
		PLATFORM_CSV_STRATEGY.setType(PlatformPosition.class);
		PLATFORM_CSV_STRATEGY.setColumnOrderOnWrite(new LiteralComparator<String>(CSV_ORDER));
	}

	@Column(length = SHORT_VARCHAR_LENGTH)
	@EqualsAndHashCode.Include
	private String category;

	private Float ltp;

	@Enumerated(EnumType.STRING)
	@Column(length = 21)
	@EqualsAndHashCode.Include
	private TradingPlatform platform;

	@Column(name = "acc_id", length = SHORT_VARCHAR_LENGTH)
	@EqualsAndHashCode.Include
	private String accountId;

	private Integer overnightQuantity;

	private Integer multiplier;

	private Float realisedPnl, unrealisedPnl;

	private PositionState state;

	private PositionDirection direction;

}

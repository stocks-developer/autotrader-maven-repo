package com.dakshata.trading.model.platform;

import java.sql.Timestamp;
import java.time.LocalDate;

import com.dakshata.constants.trading.GttStatus;
import com.dakshata.constants.trading.GttTriggerType;
import com.dakshata.constants.trading.ProductType;
import com.dakshata.constants.trading.TradeType;
import com.dakshata.constants.trading.TradingPlatform;
import com.dakshata.trading.model.trade.PseudoAccount;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;

import lombok.Builder;

/**
 * A broker-independent view of a resting GTT (Good Till Triggered) order, as
 * returned by the GTT management list. This is a read-through model: unlike
 * {@link PlatformOrder} it is NOT persisted (GTT triggers do not live in the
 * {@code at_order} table), so it is modelled as a record rather than an entity.
 *
 * <p>
 * Both the broker-specific identity ({@code exchange}/{@code symbol}/
 * {@code token}) and the broker-independent identity
 * ({@code independentExchange}/{@code independentSymbol}) are carried so the
 * management view can round-trip the row back for modify/cancel without a broker
 * re-fetch: Angel modify/cancel need {@code symboltoken}+{@code exchange}, while
 * modify re-enrichment keys off the independent instrument.
 *
 * @author PRITESH
 *
 */
@Builder
public record PlatformGttOrder(String id, PseudoAccount account, TradingPlatform platform, String exchange,
		String symbol, String independentExchange, String independentSymbol, String token, TradeType tradeType,
		ProductType productType, GttTriggerType gttTriggerType, GttStatus status, String rawStatus, GttOrderLeg leg1,
		GttOrderLeg leg2,
		@JsonSerialize(using = LocalDateSerializer.class) @JsonDeserialize(using = LocalDateDeserializer.class) LocalDate validTill,
		Timestamp createdTime, Timestamp updatedTime) {
}

/**
 *
 */
package com.dakshata.trading.model.portfolio;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Account level position summary.
 *
 * @author PRITESH
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class AccPosSummary {

	private int total, open, closed;

	private float mtm, pnl, atPnl;

}

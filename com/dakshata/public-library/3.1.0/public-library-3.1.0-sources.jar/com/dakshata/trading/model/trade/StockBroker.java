/**
 *
 */
package com.dakshata.trading.model.trade;

import static com.dakshata.constants.data.model.ICommon.SHORT_VARCHAR_LENGTH;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.dakshata.constants.trading.TradingPlatform;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Represents a stock broker.
 *
 * @author PRITESH
 *
 */
@Entity
@Table(schema = "trading", catalog = "trading")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class StockBroker implements Serializable {

	private static final long serialVersionUID = -574572007964265192L;

	@Id
	@EqualsAndHashCode.Include
	@Column(length = SHORT_VARCHAR_LENGTH)
	private String id;

	private String name;

	private String url;

	private String description;

	@ElementCollection(targetClass = TradingPlatform.class, fetch = FetchType.EAGER)
	@Enumerated(EnumType.STRING)
	@Column(length = SHORT_VARCHAR_LENGTH)
	private Set<TradingPlatform> platforms;

	@Override
	public String toString() {
		return "Stock Broker [" + this.id + "]";
	}

}

/**
 *
 */
package com.dakshata.trading.model.tv.order;

import java.util.List;
import java.util.Map;

import com.dakshata.trading.model.tv.TvAlert;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Represents an order alert.
 *
 * @author PRITESH
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
@NoArgsConstructor
@Getter
@Setter
public class TvOrderAlert extends TvAlert {

	private List<TvOrder> orders;

	@Builder
	public TvOrderAlert(String command, String apiKey, Map<String, String> analysis, List<TvOrder> orders) {
		super(command, apiKey, analysis);
		this.orders = orders;
	}

}

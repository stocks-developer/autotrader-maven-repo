/**
 *
 */
package com.dakshata.trading.model.tv.position;

import java.util.List;
import java.util.Map;

import com.dakshata.trading.model.tv.TvAlert;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Represents a position square-off alert.
 *
 * @author PRITESH
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
@NoArgsConstructor
@Getter
@Setter
public class TvPosSqOffAlert extends TvAlert {

	private List<TvPosSqOff> positions;

	@Builder
	public TvPosSqOffAlert(String command, String apiKey, Map<String, String> analysis, List<TvPosSqOff> positions) {
		super(command, apiKey, analysis);
		this.positions = positions;
	}

}

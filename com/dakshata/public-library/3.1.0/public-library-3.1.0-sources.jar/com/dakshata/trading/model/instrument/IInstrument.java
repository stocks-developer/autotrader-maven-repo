package com.dakshata.trading.model.instrument;

import com.dakshata.constants.instrument.Source;

/**
 * Represents an instrument (stock, derivative).
 *
 * @author PRITESH
 *
 */
public interface IInstrument extends IBaseInstrument {

	/**
	 * The source where the symbol has come from.<br>
	 * Example: A symbol like SBIN can come with different attributes from different
	 * sources like NSE, ZERODHA, UPSTOX etc.
	 *
	 * @return source
	 */
	Source getSource();

	/**
	 * A short code for the exchange on which the instrument is traded.
	 *
	 * @return exchange
	 */
	String getExchange();

	/**
	 * Unique symbol used to identify the actual traded contract (source
	 * independent).
	 *
	 * @return independent symbol
	 */
	Long getIndependentSymbol();

	/**
	 * Symbol of the underlying for a derivative contract (as received from source).
	 *
	 * @return underlying symbol
	 */
	String getUnderlyingSymbol();

	/**
	 * Symbol of the underlying for a derivative contract (source independent).
	 *
	 * @return independent underlying symbol
	 */
	Long getIndependentUnderSymbol();

	/**
	 * Token (given by stock broker)
	 *
	 * @return token
	 */
	String getToken();

	/**
	 * Token (given by exchange)
	 *
	 * @return exchange token
	 */
	String getExchangeToken();

	/**
	 * A value that helps build unique key, when multiple broker instruments are
	 * present with similar values. But they have a unique column value that we do
	 * not store in our database.
	 *
	 * @return keyPart
	 */
	String getKeyPart();

}

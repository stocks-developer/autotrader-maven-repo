/**
 *
 */
package com.dakshata.trading.error;

/**
 * Represents an error occurred during trading.
 *
 * @author PRITESH
 *
 */
public class TradingException extends Exception {

	private static final long serialVersionUID = -1002591785881609949L;

	public TradingException(final String message, final Throwable cause) {
		super(message, cause);
	}

	public TradingException(final String message) {
		super(message);
	}

	public TradingException() {
	}

	public TradingException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public TradingException(Throwable cause) {
		super(cause);
	}

}

/**
 *
 */
package com.dakshata.trading.model.trade;

import com.dakshata.data.model.activity.ISupportsModelActivity;

/**
 * A pseudo account.
 *
 * @author PRITESH
 *
 */
public interface IPseudoAccount extends ISupportsModelActivity {

	@Override
	int hashCode();

	@Override
	boolean equals(Object obj);

	Long getId();

	String getKey();

	ITradingAccount getAccount();

	String getUsername();

	Boolean getLive();

	Boolean getDeleted();

	/**
	 * Indicates whether order placement copying is ON.
	 */
	Boolean getCopy();

	/**
	 * Indicates whether order cancellation copying is ON.
	 */
	Boolean getCopyCancel();

	/**
	 * Indicates whether order modification copying is ON.
	 */
	Boolean getCopyModify();

	String getCopyStartTime();

	String getCopyEndTime();

	/**
	 * Indicates whether copying operation has to be carried out in parallel.
	 */
	Boolean getCopyParallel();

}

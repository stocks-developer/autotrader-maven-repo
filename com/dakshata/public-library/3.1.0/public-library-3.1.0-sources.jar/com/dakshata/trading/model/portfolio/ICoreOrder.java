/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.sql.Timestamp;
import java.time.LocalDate;

import com.dakshata.constants.trading.OrderType;
import com.dakshata.constants.trading.ProductType;
import com.dakshata.constants.trading.TradeType;
import com.dakshata.constants.trading.Validity;
import com.dakshata.constants.trading.Variety;
import com.dakshata.trading.model.instrument.IIndependentInstrument;
import com.dakshata.trading.model.instrument.IInstrument;
import com.dakshata.trading.model.trade.PseudoAccount;

/**
 * Most basic order attributes.
 *
 * @author PRITESH
 *
 */
public interface ICoreOrder extends IPortfolioPart {

	/**
	 * For platform orders, it is the order id given by your trading platform.<br>
	 * For system orders, it is a unique GUID given by AutoTrader Web.
	 */
	String getId();

	/**
	 * Broker independent instrument<br>
	 * Not available for API users, please use {@link #getIndependentExchange()} and
	 * {@link #getIndependentSymbol()}
	 */
	IIndependentInstrument getIndependentInstrument();

	/**
	 * Broker specific instrument<br>
	 * Not available for API users, please use {@link #getExchange()} and
	 * {@link #getSymbol()}
	 */
	IInstrument getInstrument();

	/**
	 * Broker specific exchange
	 */
	String getExchange();

	/**
	 * Broker specific symbol
	 */
	String getSymbol();

	/**
	 * Broker independent exchange
	 */
	String getIndependentExchange();

	/**
	 * Broker independent symbol
	 */
	String getIndependentSymbol();

	/**
	 * Trade type {@link com.dakshata.constants.trading.TradeType}
	 */
	TradeType getTradeType();

	/**
	 * Order type {@link com.dakshata.constants.trading.OrderType}
	 */
	OrderType getOrderType();

	/**
	 * Product type {@link com.dakshata.constants.trading.ProductType}
	 */
	ProductType getProductType();

	/**
	 * Variety {@link com.dakshata.constants.trading.Variety}
	 */
	Variety getVariety();

	/**
	 * Validity {@link com.dakshata.constants.trading.Validity}
	 */
	Validity getValidity();

	/**
	 * Quantity
	 */
	Integer getQuantity();

	/**
	 * Disclosed quantity
	 */
	Integer getDisclosedQuantity();

	/**
	 * Order price (the one which is entered while placing an order)
	 */
	Float getPrice();

	/**
	 * Trigger price
	 */
	Float getTriggerPrice();

	/**
	 * Comments
	 */
	String getComments();

	/**
	 * Pseudo account<br>
	 * Not available for API users, please use
	 * {@link IPortfolioPart#getPseudoAccount()}
	 */
	PseudoAccount getAccount();

	/**
	 * A flag that indicates whether the order is an After Market Order
	 */
	Boolean getAmo();

	/**
	 * Status message or rejection reason
	 */
	String getStatusMessage();

	/**
	 * Modified time
	 */
	Timestamp getModifiedTime();

	/**
	 * Created time
	 */
	Timestamp getCreatedTime();

	/**
	 * Day
	 */
	LocalDate getDay();

	/**
	 * Publisher id (id given by amibroker, metatrader, excel etc.
	 * 
	 * @see <a href=
	 *      "https://stocksdeveloper.in/documentation/api/api-parameters#order-id">Publisher
	 *      Id</a>
	 */
	String getPublisherId();

	/**
	 * Reference last-traded-price for GTT placement (transient, not persisted).
	 * Used by Zerodha GTT which requires condition.last_price.
	 */
	Float getReferenceLtp();

	/**
	 * Correlation id for end-to-end timing instrumentation (transient, not
	 * persisted). Carried on the placement request so the trading app can key the
	 * broker-call timing of this order to its timing unit. {@code null} when timing
	 * is not being tracked for this order.
	 */
	String getTraceId();

}

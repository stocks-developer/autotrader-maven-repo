package com.dakshata.trading.model.portfolio;

import static com.dakshata.constants.data.model.ICommon.DEFAULT_VARCHAR_LENGTH;
import static com.dakshata.constants.data.model.ICommon.SHORT_VARCHAR_LENGTH;
import static com.dakshata.constants.trading.ProductType.INTRADAY;
import static com.dakshata.constants.trading.Validity.DAY;
import static com.dakshata.constants.trading.Variety.REGULAR;
import static com.dakshata.tools.string.StringUtil.replaceComma;
import static com.dakshata.tools.string.StringUtil.truncate;
import static java.lang.String.valueOf;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.*;

import com.dakshata.constants.trading.*;
import com.dakshata.tools.string.StringUtil;
import com.dakshata.trading.model.instrument.IndependentInstrument;
import com.dakshata.trading.model.instrument.Instrument;
import com.dakshata.trading.model.trade.PseudoAccount;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.opencsv.bean.CsvIgnore;

import lombok.*;
import lombok.experimental.SuperBuilder;

@IdClass(OrderId.class)
@MappedSuperclass
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class CoreOrder implements ICoreOrder {

	private static final long serialVersionUID = -5468105086796017235L;

	/**
	 * For system orders, this represents a unique id. For platform orders, this
	 * represents id given by trading platform. We have given default uuid, which
	 * can be changed at the time creation (if required).<br>
	 * <b>Important: </b>While persisting PlatformOrder in database, we cannot use
	 * id as object. This is because two orders can have same id in Shoonya.
	 */
	@EqualsAndHashCode.Include
	@Column(length = SHORT_VARCHAR_LENGTH, nullable = false)
	@Builder.Default
	@Id
	private final String id = UUID.randomUUID().toString();

	@EqualsAndHashCode.Include
	@CsvIgnore
	@ManyToOne
	private Instrument instrument;

	@EqualsAndHashCode.Include
	@CsvIgnore
	@ManyToOne
	private IndependentInstrument independentInstrument;

	@Enumerated(EnumType.STRING)
	@Column(length = 4, nullable = false)
	private TradeType tradeType;

	@Enumerated(EnumType.STRING)
	@Column(length = 15, nullable = false)
	private OrderType orderType;

	@Builder.Default
	@Enumerated(EnumType.STRING)
	@Column(length = 15, nullable = false)
	private ProductType productType = INTRADAY;

	@Builder.Default
	@Enumerated(EnumType.STRING)
	@Column(length = 15, nullable = false)
	private Variety variety = REGULAR;

	@Builder.Default
	@Enumerated(EnumType.STRING)
	@Column(length = 3)
	private Validity validity = DAY;

	private Integer quantity;

	@Builder.Default
	private Integer disclosedQuantity = 0;

	@Builder.Default
	private Float price = 0f;

	@Builder.Default
	private Float triggerPrice = 0f;

	private String comments;

	@CsvIgnore
	@Builder.Default
	protected Timestamp modifiedTime = new Timestamp(System.currentTimeMillis());

	@CsvIgnore
	@Builder.Default
	@Column(updatable = false)
	protected Timestamp createdTime = new Timestamp(System.currentTimeMillis());

	@CsvIgnore
	@EqualsAndHashCode.Include
	@ManyToOne
	@Id
	private PseudoAccount account;

	@Builder.Default
	private Boolean amo = Boolean.FALSE;

	@CsvIgnore
	@Version
	private Integer version;

	/**
	 * Following two attribute is applicable to system order as well, hence it is
	 * moved to this class.
	 */
	private String statusMessage;

	/**
	 * Publisher id is common to both system order and platform order as it is
	 * required for lookup in csv files.
	 */
	@Column(length = SHORT_VARCHAR_LENGTH)
	private String publisherId;

	@Transient
	@EqualsAndHashCode.Include
	private String pseudoAccount, tradingAccount, stockBroker;

	@Transient
	@EqualsAndHashCode.Include
	private String exchange, symbol;

	@Transient
	@EqualsAndHashCode.Include
	private String independentExchange, independentSymbol;

	/**
	 * Reference last-traded-price for GTT placement. Not persisted; carried only on
	 * the placement request. Zerodha's GTT create requires condition.last_price; the
	 * at-web Trade tab supplies it (gCurrentLtp) and the Kite GTT builder reads it.
	 */
	@Transient
	private Float referenceLtp;

	/**
	 * Correlation id for end-to-end timing instrumentation. Not persisted; carried
	 * only on the placement request so the trading app can key the broker-call timing
	 * events (sent/ack) of this order to its timing unit. For copy orders all child
	 * legs of one master order share the same traceId; for manual UI orders all
	 * slices of one submission share it. The unique per-leg key remains publisherId.
	 */
	@Transient
	private String traceId;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@EqualsAndHashCode.Include
	@Builder.Default
	private LocalDate day = LocalDate.now();

	public void setComments(final String comments) {
		// Comma is replaced with semi-colon to avoid conflicts during csv conversion
		this.comments = replaceComma(truncate(comments, DEFAULT_VARCHAR_LENGTH));
	}

	public void setStatusMessage(final String statusMessage) {
		// Comma is replaced with semi-colon to avoid conflicts during csv conversion
		this.statusMessage = replaceComma(truncate(statusMessage, DEFAULT_VARCHAR_LENGTH));
	}

	@Override
	public String toString() {
		// --- 1. Resolve Symbol (Precedence: IndependentInst -> Instrument -> String)
		// ---
		String resolvedSymbol = null;

		if ((this.independentInstrument != null) && !StringUtil.isEmpty(this.independentInstrument.getSymbol())) {
			resolvedSymbol = this.independentInstrument.getSymbol();
		} else if ((this.instrument != null) && !StringUtil.isEmpty(this.instrument.getSymbol())) {
			resolvedSymbol = this.instrument.getSymbol();
		} else if (!StringUtil.isEmpty(this.symbol)) {
			resolvedSymbol = this.symbol;
		}

		// Fallback if all are empty
		if (resolvedSymbol == null) {
			resolvedSymbol = "UNKNOWN";
		}

		// --- 2. Resolve other fields safely ---
		final String type = (this.tradeType != null) ? String.valueOf(this.tradeType) : "UNKNOWN";
		final String qty = (this.quantity != null) ? String.valueOf(this.quantity) : "0";
		final String prc = (this.price != null) ? String.valueOf(this.price) : "0.0";
		final String oType = (this.orderType != null) ? String.valueOf(this.orderType) : "REGULAR";

		// --- 3. Format: Order [BUY 1 SBIN @ 990.0 (LIMIT)] ---
		return String.format("Order [%s %s Qty (%s) @ %s (%s)]", type, qty, resolvedSymbol, prc, oType);
	}

	protected List<String> toStringCols() {
		String key = "EMPTY";
		if (this.getAccount() != null) {
			key = this.getAccount().getKey();
		}
		String exchange = this.getIndependentExchange();
		String symbol = this.getIndependentSymbol();
		if (this.instrument != null) {
			exchange = this.instrument.getExchange();
			symbol = this.instrument.getSymbol();
		}

		final List<String> r = new ArrayList<>(18);
		r.add(key);
		r.add(valueOf(this.variety));
		if ((this.amo != null) && this.amo) {
			r.add("AMO");
		}
		r.add(exchange);
		r.add(symbol);
		r.add(valueOf(this.productType));
		r.add(valueOf(this.tradeType));
		r.add(valueOf(this.orderType));
		r.add("Qty: " + valueOf(this.quantity));
		r.add("Prc: " + valueOf(this.price));
		r.add("Trig Prc: " + valueOf(this.triggerPrice));

		return r;
	}

}

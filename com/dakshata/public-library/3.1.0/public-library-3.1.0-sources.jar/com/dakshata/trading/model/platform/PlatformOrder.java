package com.dakshata.trading.model.platform;

import static com.dakshata.constants.data.model.ICommon.SHORT_VARCHAR_LENGTH;
import static com.dakshata.constants.trading.OrderStatus.CANCELLED;
import static com.dakshata.constants.trading.OrderStatus.OPEN;
import static com.dakshata.constants.trading.OrderStatus.REJECTED;
import static com.dakshata.constants.trading.OrderStatus.TRIGGER_PENDING;
import static java.lang.String.valueOf;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

import javax.persistence.*;

import com.dakshata.constants.trading.OrderStatus;
import com.dakshata.constants.trading.TradingPlatform;
import com.dakshata.tools.comparator.LiteralComparator;
import com.dakshata.trading.model.portfolio.CoreOrder;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.opencsv.bean.CsvIgnore;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;

import lombok.*;
import lombok.experimental.SuperBuilder;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = true)
public class PlatformOrder extends CoreOrder implements IPlatformOrder {

	private static final long serialVersionUID = 2681423907100364751L;

	/**
	 * Bug fix: TreeMap uses compareTo() for equality check and hence we it was
	 * considering objects duplicate of their platform time matches
	 */
	@CsvIgnore
	public static final Comparator<PlatformOrder> COMPARE_BY_PLATFORM_TIME = Comparator
			.comparing(PlatformOrder::getPlatformTime, Comparator.nullsFirst(Timestamp::compareTo))
			.thenComparing(PlatformOrder::getPseudoAccount, Comparator.nullsFirst(String::compareTo))
			.thenComparing(PlatformOrder::getId, Comparator.nullsFirst(String::compareTo))
			.thenComparing(PlatformOrder::getDay, Comparator.nullsFirst(LocalDate::compareTo));

	@CsvIgnore
	private static final String[] CSV_ORDER = { "PSEUDOACCOUNT", "TRADINGACCOUNT", "PUBLISHERID", "ID",
			"EXCHANGEORDERID", "VARIETY", "INDEPENDENTEXCHANGE", "INDEPENDENTSYMBOL", "TRADETYPE", "ORDERTYPE",
			"PRODUCTTYPE", "QUANTITY", "PRICE", "TRIGGERPRICE", "FILLEDQUANTITY", "PENDINGQUANTITY", "STATUS",
			"STATUSMESSAGE", "VALIDITY", "AVERAGEPRICE", "PARENTORDERID", "DISCLOSEDQUANTITY", "EXCHANGETIME",
			"PLATFORMTIME", "AMO", "COMMENTS", "RAWSTATUS", "EXCHANGE", "SYMBOL", "DAY", "PLATFORM", "CLIENTID",
			"STOCKBROKER" };

	@CsvIgnore
	public static final HeaderColumnNameMappingStrategy<PlatformOrder> ORDER_CSV_STRATEGY = new HeaderColumnNameMappingStrategy<>();

	static {
		ORDER_CSV_STRATEGY.setType(PlatformOrder.class);
		ORDER_CSV_STRATEGY.setColumnOrderOnWrite(new LiteralComparator<String>(CSV_ORDER));
	}

	@Column(length = SHORT_VARCHAR_LENGTH)
	private String parentOrderId;

	/*
	 * Included as part of equality check because Shoonya has same order id in case
	 * of cover order for initial order as well as stoploss order.
	 */
	@EqualsAndHashCode.Include
	@Column(length = SHORT_VARCHAR_LENGTH)
	private String exchangeOrderId;

	private Float averagePrice;

	/**
	 * Here a client id is needed, as we do not have PseudoAccount in the responses
	 * received from trading platform.
	 */
	@Column(length = SHORT_VARCHAR_LENGTH)
	private String clientId;

	@Column(length = SHORT_VARCHAR_LENGTH)
	private String rawStatus;

	private Timestamp platformTime;

	private Timestamp exchangeTime;

	private Integer pendingQuantity;

	private Integer filledQuantity;

	@Enumerated(EnumType.STRING)
	@Column(length = 21)
	private TradingPlatform platform;

	@Enumerated(EnumType.STRING)
	@Column(length = SHORT_VARCHAR_LENGTH)
	private OrderStatus status;

	@CsvIgnore
	private String nestRequestId;

	@Transient
	@JsonIgnore
	@CsvIgnore
	private Object brokerFormat;

	@Override
	public boolean isCancelled() {
		return this.status == CANCELLED;
	}

	@Override
	public boolean isOpen() {
		return this.status == OPEN;
	}

	@Override
	public boolean isTriggerPending() {
		return this.status == TRIGGER_PENDING;
	}

	@Override
	public boolean isOpenOrTriggerPending() {
		return this.isOpen() || this.isTriggerPending();
	}

	@Override
	public boolean isRejected() {
		return this.status == REJECTED;
	}

	@PrePersist
	void onCreate() {
		this.createdTime = new Timestamp(System.currentTimeMillis());
	}

	@PreUpdate
	void onPersist() {
		this.modifiedTime = new Timestamp(System.currentTimeMillis());
	}

	@Override
	public String calculateParentOrderId(final TradingPlatform p) {
		return this.getParentOrderId();
	}

	@Override
	protected List<String> toStringCols() {
		final List<String> r = super.toStringCols();
		r.add("Broker. ID: " + valueOf(super.getId()));
		r.add("Exch. ID: " + valueOf(this.exchangeOrderId));
		return r;
	}

	@Override
	public String toString() {
		return String.format("%s Id [%s]", super.toString(), super.getId());
	}

}

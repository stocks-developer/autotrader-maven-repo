/**
 *
 */
package com.dakshata.trading.model.portfolio;

import java.io.Serializable;

import com.dakshata.trading.model.trade.PseudoAccount;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Id for orders.
 *
 * @author PRITESH
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class OrderId implements Serializable {

	private static final long serialVersionUID = 7451302062220757542L;

	@EqualsAndHashCode.Include
	private String id;

	@EqualsAndHashCode.Include
	private PseudoAccount account;

}

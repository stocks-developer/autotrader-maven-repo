package com.dakshata.trading.model.instrument;

import java.io.Serializable;

import lombok.Value;

/**
 * Holds the daily price bands for a symbol. Uses Lombok @Value for immutability
 * (similar to Java 17 records).
 */
@Value
public class CircuitLimits implements Serializable {

	private static final long serialVersionUID = 1L;

	// @Value makes these private and final automatically
	double lowerCircuit;
	double upperCircuit;

	/**
	 * Manual constructor is required here because we need Custom Validation. Lombok
	 * detects this constructor and will NOT generate a duplicate one, but will
	 * still handle Getters, ToString, EqualsAndHashCode.
	 */
	public CircuitLimits(double lowerCircuit, double upperCircuit) {
		if ((lowerCircuit < 0) || (upperCircuit < lowerCircuit)) {
			throw new IllegalArgumentException(
					String.format("Invalid circuit limits: LC=%s, UC=%s", lowerCircuit, upperCircuit));
		}
		this.lowerCircuit = lowerCircuit;
		this.upperCircuit = upperCircuit;
	}
}
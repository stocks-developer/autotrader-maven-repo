package com.dakshata.trading.model.instrument;

import static com.dakshata.constants.data.model.ICommon.DEFAULT_VARCHAR_LENGTH;
import static com.dakshata.tools.string.StringUtil.truncate;
import static com.dakshata.tools.trading.PriceFormatter.removeTrailingDecimalZeros;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Objects;

import javax.persistence.*;

import com.dakshata.constants.instrument.Exchange;
import com.dakshata.constants.instrument.InstrumentType;
import com.dakshata.constants.instrument.OptionType;
import com.dakshata.constants.instrument.Segment;

import lombok.Getter;
import lombok.Setter;

/**
 * These are broker independent instruments.<br>
 * <b>Note: </b> In below index (ind_inst_symb_exchange_idx), the column symbol
 * has high selectivity (i.e. few rows match a value); hence it is kept first.
 *
 * @author PRITESH
 *
 */
@Entity
@Table(indexes = { @Index(columnList = "symbol,exchange", name = "ind_inst_symbol_exchange_idx", unique = true),
		@Index(columnList = "expiry", name = "inst_expiry_idx") })
@Getter
@Setter
public class IndependentInstrument implements IIndependentInstrument {

	private static final String STAR = "*";

	private static final long serialVersionUID = -6691841534893799886L;

	@Id
	@GeneratedValue
	private Long id;

	private String name;

	private Date expiry;

	private Float strikePrice, tickSize;

	private Integer lotSize;

	@Column(length = 100, nullable = false)
	private String symbol;

	@Column(name = "under_symbol")
	private Long underlyingSymbol;

	@Enumerated(EnumType.STRING)
	@Column(length = 10, nullable = false)
	private Exchange exchange;

	@Enumerated(EnumType.STRING)
	@Column(length = 20, nullable = false)
	private Segment segment;

	@Enumerated(EnumType.STRING)
	@Column(length = 2)
	private OptionType optionType;

	@Enumerated(EnumType.STRING)
	@Column(length = 10, name = "inst_type")
	private InstrumentType instrumentType;

	@Column(updatable = false)
	private Timestamp createdTime;

	private Timestamp lastModified;

	private Float lowerCircuit, upperCircuit;

	public IndependentInstrument() {
	}

	public IndependentInstrument(final Instrument i) {
		this.name = i.getName();
		this.exchange = Exchange.of(i.getExchange());
		this.symbol = i.getSymbol();
		this.instrumentType = i.getInstrumentType();
		this.optionType = i.getOptionType();
		this.expiry = i.getExpiry();
		this.strikePrice = i.getStrikePrice();
		this.lotSize = i.getLotSize();
		this.tickSize = i.getTickSize();
		this.segment = i.getSegment();
		this.lowerCircuit = i.getLowerCircuit();
		this.upperCircuit = i.getUpperCircuit();
	}

	@PrePersist
	void onCreate() {
		this.createdTime = new Timestamp(System.currentTimeMillis());
	}

	@PreUpdate
	void onPersist() {
		this.lastModified = new Timestamp(System.currentTimeMillis());
	}

	@Override
	public String toString() {
		return "Instrument [id=" + this.id + ", name=" + this.name + ", exchange=" + this.exchange + ", symbol="
				+ this.symbol + ", underlyingSymbol=" + this.underlyingSymbol + ", instrumentType="
				+ this.instrumentType + ", optionType=" + this.optionType + ", expiry=" + this.expiry + ", strikePrice="
				+ this.strikePrice + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.exchange, this.symbol);
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		final IndependentInstrument other = (IndependentInstrument) obj;
		if (this.exchange == null) {
			if (other.exchange != null) {
				return false;
			}
		} else if (!this.exchange.equals(other.exchange)) {
			return false;
		}
		if (this.symbol == null) {
			if (other.symbol != null) {
				return false;
			}
		} else if (!this.symbol.equals(other.symbol)) {
			return false;
		}
		return true;
	}

	public void setExchange(final String exchange) {
		this.exchange = Exchange.of(exchange);
	}

	public void setName(final String name) {
		this.name = truncate(name, DEFAULT_VARCHAR_LENGTH);
	}

	public void updatePriceBands(final Float lowerCircuit, final Float upperCircuit) {
		if ((lowerCircuit != null) && !lowerCircuit.isNaN()) {
			this.lowerCircuit = lowerCircuit;
		}
		if ((upperCircuit != null) && !upperCircuit.isNaN()) {
			this.upperCircuit = upperCircuit;
		}
	}

	public void updateLotSize(final Integer lotSize) {
		if (lotSize != null) {
			this.lotSize = lotSize;
		}
	}

	public final String toShoonyaSearchString() {
		if (this.expiry == null) {
			return this.symbol + STAR;
		} else {
			final String syb = this.symbol.split("_")[0];

			// There are so many different derivative symbol format that we use search
			// string instead of a perfect format
			if (this.optionType == null) {
				// Future
				return syb + STAR + " " + STAR + "FUT" + STAR;
			} else {
				// Option
				final String strike = removeTrailingDecimalZeros(this.strikePrice);
				return syb + STAR + " " + STAR + strike + STAR + " " + STAR + this.optionType.name() + STAR;
			}
		}
	}

	/**
	 * Determines the trading segment based on the exchange and expiry. Returns null
	 * if the exchange is unrecognized or missing.
	 */
	public String calcExchangeSegment() {
		if (this.getExchange() == null) {
			return null;
		}

		final boolean isFno = this.getExpiry() != null;

		switch (this.getExchange()) {
		case NSE:
			return isFno ? "NSE_FNO" : "NSE_CASH";
		case BSE:
			return isFno ? "BSE_FNO" : "BSE_CASH";
		case MCX:
			return "MCX";
		default:
			return null;
		}
	}

}

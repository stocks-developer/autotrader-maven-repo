/**
 *
 */
package com.dakshata.trading.model.portfolio;

import static com.dakshata.constants.trading.Variety.REGULAR;

import com.dakshata.constants.trading.OrderType;
import com.dakshata.constants.trading.ProductType;
import com.dakshata.constants.trading.TradeType;
import com.dakshata.trading.model.instrument.Instrument;
import com.dakshata.trading.model.portfolio.Order.OrderBuilder;
import com.dakshata.trading.model.trade.PseudoAccount;

/**
 * A factory for creating orders.
 *
 * @author PRITESH
 *
 */
public final class OrderFactory {

	public static Order createRegularLimitOrder(final PseudoAccount account, final Instrument instrument,
			final TradeType tradeType, final ProductType productType, final Integer quantity, final Float price) {
		final OrderBuilder<?, ?> builder = Order.builder();

		builder.variety(REGULAR).orderType(OrderType.LIMIT);

		builder.account(account).tradeType(tradeType).productType(productType).quantity(quantity).price(price)
				.instrument(instrument);

		return builder.build();
	}

}

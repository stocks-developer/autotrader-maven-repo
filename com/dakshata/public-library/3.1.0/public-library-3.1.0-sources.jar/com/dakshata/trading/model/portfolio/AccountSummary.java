/**
 *
 */
package com.dakshata.trading.model.portfolio;

import lombok.*;

/**
 * Account level summary.
 *
 * @author PRITESH
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class AccountSummary {

	@EqualsAndHashCode.Include
	private String pseudoAccount;

	@EqualsAndHashCode.Include
	private String tradingAccount;

	/** Orders */
	private int ordersTotal, ordersOpen, ordersTriggerPending, ordersComplete, ordersRejected, ordersCancelled;

	/** Positions Day */
	private AccPosSummary positionsDay;

	/** Positions Net */
	private AccPosSummary positionsNet;

	/** Margins */
	private float marginTotal, marginUtilized, marginAvailable;

	/** Holdings */
	private AccHoldingsSummary holdings;

}